
<?php
 //&& isset($_POST['txtpassword'])
if(isset($_POST['uname'])){ 

include "config/koneksi.php";
function anti_injection($data){
  $filter = ((isset($GLOBALS) && is_object($GLOBALS)) ? mysqli_real_escape_string($GLOBALS, stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES)))) : ((trigger_error("[MySQLConverterToo] Fix the mysql_escape_string() call! This code does not work.", E_USER_ERROR)) ? "" : ""));
  return $filter;
}

$username = anti_injection($_POST['uname']);
$pass     = anti_injection(md5($_POST['upass']));

// pastikan username dan password adalah berupa huruf atau angka.
if (!ctype_alnum($username) OR !ctype_alnum($pass)){
  header('location:index.php?answer=wrong');
}
else{
$login=mysqli_query($GLOBALS, "SELECT * FROM m_login WHERE USER_LOG='$username' AND PASS_LOG='$pass' AND AKTIF_LOG='YA'");
$ketemu=mysqli_num_rows($login);
$r=mysqli_fetch_array($login);

// Apabila username dan password ditemukan
if ($ketemu > 0){
  
  session_start();
  $stat   = $r['STA_LOG'];
  $_SESSION['USER_LOG']     = $r['USER_LOG'];
  //$_SESSION['namalengkap']  = $r['NAMA_LENGKAP'];
  $_SESSION['PASS_LOG']     = $r['PASS_LOG'];
  $_SESSION['STA_LOG']      = $stat;
  //$_SESSION['emailuser']    = $r['EMAIL'];
  
	$sid_lama = session_id();
	
	session_regenerate_id();

	$sid_baru = session_id();
	$rgls = date("Y-m-d H:i:s");
	
  mysqli_query($GLOBALS, "UPDATE m_login SET ID_SESSION='$sid_baru',
  DATE_LOG='$rgls' WHERE USER_LOG='$username'");

  $_SESSION['idsession']    = $r['ID_SESSION'];

  //cek sta log admin,dosen,reviewer,mhs
  if($stat == '1'){ 

  header('location:home.html'); }

  elseif($stat == '2'){ //DOSEN

  header('location:home.html'); }

  elseif($stat == '3'){ //REVIEWER

  header('location:home.html'); }
	}

elseif($ketemu == 0){
  header('location:index.php?answer=wrong');
}
}
}else{
  header('location:index.php');
}

?>
