<?php
$server = "localhost";
$u_name = "root";
$u_pass = "root";
$u_db = "k_ss";

 
($GLOBALS = mysqli_connect($server, $u_name, $u_pass)) or die("Koneksi gagal");
((bool)mysqli_query($GLOBALS, "USE " . $u_db)) or die("Database tidak bisa dibuka");

//Set Tahun Ajaran Aktif

$qta = "SELECT * FROM m_tahun where AKTIF_THN = 'YA' ";
$hta = mysqli_query($GLOBALS,$qta); 
$rta = mysqli_fetch_array($hta); 
$numa = mysqli_num_rows($hta); 

$kd_thn = $rta['KD_THN'];
$nm_thn = $rta['NM_THN'];
$ket_thn = $rta['KET_THN'];
?>