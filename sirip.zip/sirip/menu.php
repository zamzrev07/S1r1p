<?php 
if($stat == '1'){

?>

<ul class="nav menu">
			<li class="active"><a href="home.html"><svg class="glyph stroked dashboard-dial"><use xlink:href="#stroked-dashboard-dial"></use></svg> Dashboard</a></li>
	<li class="parent ">
				<a href="#">
					<span data-toggle="collapse" href="#sub-item-2"><svg class="glyph stroked open folder"><use xlink:href="#stroked-open-folder"></use></svg><b>SUB MASTER DATA</b> </span>
				</a>
				<ul class="children collapse" id="sub-item-2">
					<li>
						<a class="" href="jafa.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Jabatan Fungsional
						</a>
					</li>
					<li>
						<a class="" href="pakar.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Kepakaran
						</a>
					</li>
					<li>
						<a class="" href="rumpun.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Ilmu Rumpun
						</a>
					</li>
					<li>
						<a class="" href="ta.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Set TA / Aktivasi
						</a>
					</li>
					<li>
						<a class="" href="kat.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Master Kategori
						</a>
					</li>
					<li>
						<a class="" href="skat.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Master Skim
						</a>
					</li>
					<li>
						<a class="" href="kel.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Master Kelompok
						</a>
					</li>
					<li>
						<a class="" href="prop.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Master Propinsi
						</a>
					</li>
					<li>
						<a class="" href="kab.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Master Kota/kab
						</a>
					</li>
					<li>
						<a class="" href="kec.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Master Kec / Desa
						</a>
					</li>
				</ul>
			</li>
			<li class="parent ">
				<a href="#">
					<span data-toggle="collapse" href="#sub-item-1"><svg class="glyph stroked open folder"><use xlink:href="#stroked-open-folder"></use></svg><b>MASTER DATA</b></span>  
				</a>
				<ul class="children collapse" id="sub-item-1">
					<li>
						<a class="" href="fakultas.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Master Fakultas
						</a>
					</li>
					<li>
						<a class="" href="progdi.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Master Progdi
						</a>
					</li>
					<li>
						<a class="" href="dosen.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Master Dosen
						</a>
					</li>
					<li>
						<a class="" href="mhs.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Master Mahasiswa
						</a>
					</li>
					<li>
						<a class="" href="users.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Master User
						</a>
					</li>
				</ul>
			</li>
			<li class="parent ">
				<a href="#">
					<span data-toggle="collapse" href="#sub-item-3"><svg class="glyph stroked open folder"><use xlink:href="#stroked-open-folder"></use></svg><b>PROPOSAL</b> </span> 
				</a>
				<ul class="children collapse" id="sub-item-3">
					<li>
						<a class="" href="penelitian.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Penelitian Baru
						</a>
					</li>
<li>
<a class="" href="penelitian.html">
<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Penelitian Lanjutan 
						</a>
					</li>
					<li>
						<a class="" href="dftrkkn.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Pendaftaran KKN
						</a>
					</li>
									</ul>
			</li>
<li class="parent ">
				<a href="#">
					<span data-toggle="collapse" href="#sub-item-4"><svg class="glyph stroked open folder"><use xlink:href="#stroked-open-folder"></use></svg><b>PLOTTING</b> </span> 
				</a>
				<ul class="children collapse" id="sub-item-4">
<li>
						<a class="" href="srev.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Set Reviewer
						</a>
					</li>				
<li>
						<a class="" href="prev.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Plotting Reviewer
						</a>
					</li>
					<li>
						<a class="" href="mhs.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Set DPL (KKN)
						</a>
					</li>
					<li>
						<a class="" href="progdi.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Plotting DPL
						</a>
					</li>
					
				</ul>
			</li>

			<li class="parent ">
				<a href="#">
					<span data-toggle="collapse" href="#sub-item-5"><svg class="glyph stroked open folder"><use xlink:href="#stroked-open-folder"></use></svg><b>LAPORAN</b></span>  
				</a>
				<ul class="children collapse" id="sub-item-5">
					<li>
						<a class="" href="fakultas.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Pendaftar Penelitian
						</a>
					</li>
					<li>
						<a class="" href="progdi.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Pendaftar KKN
						</a>
					</li>
					<li>
						<a class="" href="progdi.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Reviewer
						</a>
					</li>
					<li>
						<a class="" href="progdi.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> DPL
						</a>
					</li>
				</ul>
			</li>
		<li><a href="logout_check.php"><svg class="glyph stroked dashboard-dial"><use xlink:href="#stroked-dashboard-dial"></use></svg> <b>LOGOUT !!!</b></a></li>
<?php }  
// START MENU DOSEN
elseif($stat == '2'){  echo "Anda Login Sebagai Dosen"; ?>
<ul class="nav menu">
			<li class="active"><a href="home.html"><svg class="glyph stroked dashboard-dial"><use xlink:href="#stroked-dashboard-dial"></use></svg> Dashboard</a></li>
			<li><a href="profil.html"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg><b>PROFIL</b></a></li>
			<li class="parent ">
				<a href="#">
					<span data-toggle="collapse" href="#sub-item-3"><svg class="glyph stroked open folder"><use xlink:href="#stroked-open-folder"></use></svg><b>PROPOSAL</b> </span> 
				</a>
				<ul class="children collapse" id="sub-item-3">
					<li>
						<a class="" href="penelitian.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Penelitian Baru
						</a>
				</li>
				
<li>
<a class="" href="penelitian.html">
<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Penelitian Lanjutan 
						</a>
					</li>
<li>
						<a class="" href="penelitian.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> History Penelitian
						</a>
				</li>
					</ul>
<li><a href="dosen/logout_check.php"><svg class="glyph stroked dashboard-dial"><use xlink:href="#stroked-dashboard-dial"></use></svg> <b>LOGOUT !!!</b></a></li>
</ul>
<?php } // END MENU DOSEN

// START MENU REVIEWER
elseif($stat == '3'){ echo "Anda Login Sebagai Reviewer"; ?>
<ul class="nav menu">
			<li class="active"><a href="home.html"><svg class="glyph stroked dashboard-dial"><use xlink:href="#stroked-dashboard-dial"></use></svg> Dashboard</a></li>
			<li><a href="profil.html"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg><b>PROFIL</b></a></li>
			<li class="parent ">
				<a href="#">
					<span data-toggle="collapse" href="#sub-item-3"><svg class="glyph stroked open folder"><use xlink:href="#stroked-open-folder"></use></svg><b>PROPOSAL</b> </span> 
				</a>
				<ul class="children collapse" id="sub-item-3">
					<li>
						<a class="" href="propr.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Penelitian Baru
						</a>
				</li>
				
<li>
<a class="" href="penelitian.html">
<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Penelitian Lanjutan 
						</a>
					</li>
<li>
						<a class="" href="penelitian.html">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> History Penelitian
						</a>
				</li>
					</ul>
<li><a href="reviewer/logout_check.php"><svg class="glyph stroked dashboard-dial"><use xlink:href="#stroked-dashboard-dial"></use></svg> <b>LOGOUT !!!</b></a></li>
</ul>
<?php } //END MENU REVIEWER?>
		<li role="presentation" class="divider"></li>
			
		</ul>