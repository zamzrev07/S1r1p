

// JavaScript Document  
var xmlHttp;  
//-------------membuat objek xmlHttpRequest  
function GetXmlHttpObject()  
{  
try  
    {  
    //  firefox, opera 8.0+, safari  
    xmlHttp=new XMLHttpRequest();  
    }  
    catch (e)  
        {  
        // browser Internet Explorer  
        try  
            {  
            // IE 6.0+  
            xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");  
            }  
            catch (e)  
                {  
                // IE 5.0  
                xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");  
                }  
        }             
return xmlHttp;  
}  
  
function tampilkan_data(kode, jumlah)  
{  
    xmlHttp=GetXmlHttpObject()  
    if (xmlHttp==null)  
    {  
        alert ("Browser tidak support HTTP Request");  
    }  
    var url="venus/proses_kkn/cek_datakkn.php?kode="+kode  
    url = url+"&jumlah="+jumlah  
    xmlHttp.onreadystatechange=function()  
    {  
        if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")  
        {  
                xmldoc = xmlHttp.responseXML;
				   
                document.myForm.txtmhsname.value=xmldoc.getElementsByTagName("mhsname")[0].childNodes[0].nodeValue;  
                document.myForm.txtjur.value=xmldoc.getElementsByTagName("jur")[0].childNodes[0].nodeValue;  
        }  
    }  
    xmlHttp.open("GET",url,true);  
    xmlHttp.send(null);  
}  
