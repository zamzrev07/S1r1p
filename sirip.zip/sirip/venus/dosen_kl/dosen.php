<script>
function hapusdata(urltujuan){
		el=$(this);
		if(confirm("Do you want to delete the data ?."))
		{
            alert("Data Deleted!");
            
            window.location = (urltujuan);
        }
        else{
            alert("Failure to Delete");
        }
}
</script>
            
<?php
$aksi="venus/dosen_kl/aksi_dosen.php";

if($_GET['venus']=='dosenlog'){ 
$log = $_GET['id'];
$sid_baru = session_id();
$ds="ds";
  $paw=$ds.$log; 
 
  //autonumber m_login
 $query = "SELECT max(KD_LOG) as maxKode FROM m_login";
 $hasil = mysqli_query($GLOBALS,$query); 
 $data = mysqli_fetch_array($hasil); 
 $kodeBarang = $data['maxKode']; 
   $noUrut = (int) substr($kodeBarang, 1, 5); 
   $noUrut++; 
   $char="U";
    $newID = $char . sprintf("%05s", $noUrut);
  //selesai auto
  $idn=$newID;
  $ps=md5($paw);
$ins = "INSERT INTO m_login
  (KD_LOG,USER_LOG,PASS_LOG,ID_SESSION,STA_LOG,AKTIF_LOG) 
  VALUES 
 ('$idn','$log','$ps','$sid_baru','2','YA')";
 $sqln = mysqli_query($GLOBALS,$ins);

$upd = mysqli_query("UPDATE m_dosen SET KD_LOG='$idn' where NPT = '$log'");
$sqlm = mysqli_query($GLOBALS,$upd);
header('location:dosen.html');
}

  // Tampil Agenda
  if($_GET[venus] == "dosen"){
    $que = "select * from m_dosen a, m_progdi b, m_rumpun c,m_kepakaran d, m_jafa e
            where a.KD_JAFA=e.KD_JAFA and a.KD_PROGDI=b.KD_PROGDI and a.KD_RUMPUN=c.KD_RUMPUN and a.KD_PAKAR=d.KD_PAKAR";
	$result=mysqli_query($GLOBALS,$que);
	$jumrows = mysqli_num_rows($result);

?>
    
	<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>Data Master Dosen</div>
					<div class="panel-body">
                    <?php 
    //        menampilkan pesan jika ada pesan
            if (($_SESSION['pesan']) && $_SESSION['pesan'] <> '') {
                echo '<div class="alert bg-danger" role="alert">'.$_SESSION['pesan'].'<button type="button" class="close" data-dismiss="alert">×</button></div>';
            }

    //        mengatur session pesan menjadi kosong
            $_SESSION['pesan'] = '';
            ?> 
                    <a href="dosenadd.html" class="btn btn-primary">Tambah Data Dosen</a>
					<table data-toggle="table" data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
        <thead>
            <tr>
                <th data-sortable="true">NPT / NIDN</th>
                <!--
                <th data-sortable="true">Nama Rumpun</th>
                <th data-sortable="true">Kepakaran</th>
                <th data-sortable="true">NIDN</th>-->
                <th data-sortable="true">Nama Dosen</th>
                <th data-sortable="true">Progdi</th>
                <th data-sortable="true">JK</th>
                <th data-sortable="true">Email</th>
                <th data-sortable="true">Jafa</th>
                <th data-sortable="true">Login</th>
                <th data-sortable="true">Aktif Dosen</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
		<?php
		$iCnt=0;
		if ($jumrows>0) { 
			while ($row = mysqli_fetch_array($result)) {
        $iCnt++;
		?>
        
		  <tr <?php if ($iCnt%2==0) {?>class="odd gradeX" <?php } else {?>class="even gradeC"<?php }?> >
      <td><?php echo strip_tags(strtoupper($row[NPT])); ?> / <?php echo strip_tags(strtoupper($row[NIDN])); ?></td>
			<!--
            <td><?php echo strip_tags(strtoupper($row[NM_RUMPUN])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[NM_PAKAR])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[NIDN])); ?></td>-->
            <td><?php echo strip_tags(strtoupper($row[NM_DOSEN])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[NM_PROGDI])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[JK_DOSEN])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[EMAIL_DOSEN])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[NM_JAFA])); ?></td>
            <td><?php
$sqlku  = "select * from m_login where USER_LOG = '$row[NPT]'";
$resku  = mysqli_query($GLOBALS,$sqlku);
$numku = mysqli_num_rows($resku);

if($numku >= 1){
  echo "OK";
}elseif($numku == '0'){
  echo "<a href='dosenlog-$row[NPT].html'>Buat</a>";
}
            ?></td>
            <td><?php echo strip_tags(strtoupper($row[AKTIF_DOSEN])); ?></td>
            <td><a data-toggle="tooltip" data-placement="top" title="edit" href="<?php echo("dosenedit-$row[NPT].html")?>" class="btn btn-sm btn-warning">Edit</a></td>  
		  </tr>
		<?php
			}
		}else{
		?>
		<tr>
			<td colspan="6"><div class="alert bg-danger" role="alert">
					<svg class="glyph stroked cancel"><use xlink:href="#stroked-cancel"></use></svg> Data Tidak Ditemukan !!! <a href="#" class="pull-right"><span class="glyphicon glyphicon-remove"></span></a>
				</div></td>
		</tr>
        
		<?php
		}
		?>
        </tbody>
	</table>
    </div>
    </div>
    </div>
    </div>
	<?php
  }
elseif($_GET[venus]=="dosenadd"){

?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
             <svg class="glyph stroked plus sign"><use xlink:href="#stroked-plus-sign"/></svg> Tambah Data Master Dosen
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=dosen&act=input"?>" method="post" enctype="multipart/form-data">
                   <label>NPT</label>
                      <input class="form-control" name="txtnpt" id="txtnpt" />
                      <label>Progdi</label>
                      <select name="prog" class="form-control">
<?php 
$quer = "select * from m_progdi ";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_PROGDI']; ?>"><?php echo strtoupper($rot['NM_PROGDI']); ?></option> <?php } ?>
                      </select>
                      <label>Jabatan Fungsional</label>
                      <select name="jafa" class="form-control">
<?php 
$quer = "select * from m_jafa ";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_JAFA']; ?>"><?php echo strtoupper($rot['NM_JAFA']); ?></option> <?php } ?>
                      </select>
                      <label>Rumpun</label>
                      <select name="rump" class="form-control">
<?php 
$querr = "select * from m_rumpun ";
$resulttr=mysqli_query($GLOBALS,$querr);
while ($rot = mysqli_fetch_array($resulttr)) { ?>                      
                      <option value="<?php echo $rot['KD_RUMPUN']; ?>"><?php echo strtoupper($rot['NM_RUMPUN']); ?></option> <?php } ?>
                      </select>
                      <label>Kepakaran</label>
                      <select name="pakar" class="form-control">
<?php 
$quer = "select * from m_kepakaran ";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_PAKAR']; ?>"><?php echo strtoupper($rot['NM_PAKAR']); ?></option> <?php } ?>
                      </select>
                      <label>NIDN</label>
                      <input class="form-control" name="txtnidn" id="txtnidn" />
                       <label>Nama Dosen</label>
                      <input class="form-control" name="txtnamdos" id="txtnamdos" />
                      <label>JK</label>
                      <select name="jk" class="form-control">
                      <option value="L">Laki-Laki</option>
                      <option value="P">Perempuan</option>
                      </select>
                       <label>Email</label>
                      <input class="form-control" name="txtemail" id="txtemail" />
                      
                       <label>Jabatan </label>
                     <select name="txtjab" class="form-control">
<?php 
$quer = "select * from m_jafa ";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_JAFA']; ?>"><?php echo strtoupper($rot['NM_JAFA']); ?></option> <?php } ?>
                      </select>

                      
                      
                      <label>Aktif Dosen</label>
                      <select name="aktif" class="form-control">
                      <option value="YA">YA</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                      
                      <button type="reset" class="btn btn-default">Reset</button>

                  </form>
              </div>
    </div>  
<?php
}
elseif($_GET[venus]=="dosenedit"){
  	$que = "select * from m_dosen a, m_progdi b, m_rumpun c,m_kepakaran d, m_jafa e where a.KD_JAFA=e.KD_JAFA and a.KD_PROGDI=b.KD_PROGDI and a.KD_RUMPUN=c.KD_RUMPUN and a.KD_PAKAR=d.KD_PAKAR and a.NPT='$_GET[id]'";
    $result=mysqli_query($GLOBALS,$que);  
    $row = mysqli_fetch_array($result);
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
               <svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"/></svg>Ubah Data Master Dosen
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=dosen&act=edit"?>" method="post" enctype="multipart/form-data">
                      <label>NPT</label>
                      <input class="form-control" name="txtnpt" id="txtnpt" value="<?php echo($_GET[id]); ?>"/>
                      <label>Progdi</label>
                      <select name="prog" class="form-control">
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[KD_PROGDI]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo strtoupper($row[NM_PROGDI]); }else{echo 'Silahkan Pilih'; }?></option>
                      <?php 
$quer = "select * from m_progdi ";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_PROGDI']; ?>"><?php echo strtoupper($rot['NM_PROGDI']); ?></option> <?php } ?>
                      </select>

                      <label>Jabatan Fungsional</label>
                      <select name="jafa" class="form-control">
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[KD_JAFA]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo strtoupper($row[NM_JAFA]); }else{echo 'Silahkan Pilih'; }?></option>
                      <?php 
$quer = "select * from m_jafa ";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_JAFA']; ?>"><?php echo strtoupper($rot['NM_JAFA']); ?></option> <?php } ?>
                      </select>

                     <label>Rumpun</label>
                      <select name="rumpun" class="form-control">
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[KD_RUMPUN]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo strtoupper($row[NM_RUMPUN]); }else{echo 'Silahkan Pilih'; }?></option>
                      <?php 
$querp = "select * from m_rumpun ";
$resultp=mysqli_query($GLOBALS,$querp);
while ($rotp = mysqli_fetch_array($resultp)) { ?>                      
                      <option value="<?php echo $rotp['KD_RUMPUN']; ?>"><?php echo strtoupper($rotp['NM_RUMPUN']); ?></option> <?php } ?>
                      </select>
                      <label>Pakar</label>
                      <select name="pakar" class="form-control">
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[KD_PAKAR]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo strtoupper($row[NM_PAKAR]); }else{echo 'Silahkan Pilih'; }?></option>
                      <?php 
$querpk = "select * from m_kepakaran ";
$resultpk=mysqli_query($GLOBALS,$querpk);
while ($rotpk = mysqli_fetch_array($resultpk)) { ?>                      
                      <option value="<?php echo $rotpk['KD_PAKAR']; ?>"><?php echo strtoupper($rotpk['NM_PAKAR']); ?></option> <?php } ?>
                      </select>
                      <label>NIDN</label>
                      <input class="form-control" name="txtnidn" id="txtnidn" value="<?php echo($row[NIDN]);?>" />
                       <label>Nama Dosen</label>
                      <input class="form-control" name="txtnamdos" id="txtnamdos" value="<?php echo($row[NM_DOSEN]);?>" />
                      
                      <label>Jenis Kelamin</label>
                      <select name="jk" class="form-control">
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[JK_DOSEN]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo($row[JK_DOSEN]); }else{echo 'Silahkan Pilih'; }?></option>
                      <option value="L">Laki-Laki</option>
                      <option value="P">Perempuan</option>
                      </select>

<label>Pendidikan</label>
                      <select name="pend" class="form-control">
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[PENDIDIKAN]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo($row[PENDIDIKAN]); }else{echo 'Silahkan Pilih'; }?></option>
                      <option value="S-1">S1 (SARJANA)</option>
                      <option value="S-2">S2 (PASCA SARJANA MAGISTER)</option>
<option value="S-3">S3 (PASCA SARJANA DOKTOR)</option>
                      </select>

                       <label>Email</label>
                      <input class="form-control" name="txtemail" id="txtemail" value="<?php echo($row[EMAIL_DOSEN]);?>" />
                       <label>Jabatan Akademik</label>
                      <input class="form-control" name="txtjab" id="txtjab" value="<?php echo($row[JAB_AKADEMIK]);?>" />
                      <label>Status Dosen</label>
                      <select name="aktifdosen" class="form-control">                                            
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[AKTIF_DOSEN]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo($row[AKTIF_DOSEN]); }else{echo 'Silahkan Pilih'; }?></option>
                      <option value="YA">YA</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-default">Ubah</button>
                    
                      <button type="reset" class="btn btn-primary">Reset</button>
                      </form>
              </div>
  </div>    
<?php
}
?>