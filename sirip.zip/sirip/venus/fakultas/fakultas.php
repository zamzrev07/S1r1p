<script>
function hapusdata(urltujuan){
		el=$(this);
		if(confirm("Do you want to delete the data ?."))
		{
            alert("Data Deleted!");
            
            window.location = (urltujuan);
        }
        else{
            alert("Failure to Delete");
        }
}
</script>
            
<?php
$aksi="venus/fakultas/aksi_fak.php";

  // Tampil Agenda
  if($_GET[venus] == "fakultas"){
    $que = "select * from m_fakultas";
	$result=mysqli_query($GLOBALS,$que);
	$jumrows = mysqli_num_rows($result);
?>
    
	<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>Data Master Fakultas</div>
					<div class="panel-body">
                    <a href="fakadd.html" class="btn btn-primary">Tambah Fakultas</a>
					<table data-toggle="table" data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
        <thead>
            <tr>
                <th data-sortable="true">Kode Fakultas</th>
                <th data-sortable="true">Nama Fakultas</th>
                <th data-sortable="true">NIP Dekan</th>
                <th data-sortable="true">Nama Dekan</th>
                <th data-sortable="true">Status Aktif</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
		<?php
		$iCnt=0;
		if ($jumrows>0) { 
			while ($row = mysqli_fetch_array($result)) {
        $iCnt++;
		?>
        
		  <tr <?php if ($iCnt%2==0) {?>class="odd gradeX" <?php } else {?>class="even gradeC"<?php }?> >
			<td><?php echo strip_tags(strtoupper($row[0])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[1])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[4])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[3])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[2])); ?></td>
            <td><a data-toggle="tooltip" data-placement="top" title="edit" href="<?php echo("fakedit-$row[0].html")?>" class="btn btn-sm btn-warning">Edit</a></td>  
		  </tr>
		<?php
			}
		}else{
		?>
		<tr>
			<td colspan="6">Data tidak di temukan</td>
		</tr>
		<?php
		}
		?>
        </tbody>
	</table>
    </div>
    </div>
    </div>
    </div>
	<?php
  }
elseif($_GET[venus]=="fakadd"){

 $query = "SELECT max(KD_FAK) as maxKode FROM m_fakultas";
   $hasil = mysqli_query($GLOBALS,$query); 
  $data = mysqli_fetch_array($hasil); 
  $kodeBarang = $data['maxKode']; 
   $noUrut = (int) substr($kodeBarang, 1, 5); 
   $noUrut++; 
   $char="F";
    $newID = $char . sprintf("%05s", $noUrut);	
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
             <svg class="glyph stroked plus sign"><use xlink:href="#stroked-plus-sign"/></svg>   Tambah Data Master Fakultas
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=fakultas&act=input"?>" method="post" enctype="multipart/form-data">
                   <label>Kode Fakultas</label>
                      <input class="form-control" name="txtkdlog" id="txtkdlog" value="<?php echo $newID; ?>" readonly="readonly"/>
                      <label>Nama Fakultas</label>
                      <input class="form-control" name="txtusername" id="txtusername" />
                      <label>NIP Dekan</label>
                      <input class="form-control" name="txtnipdekan" id="txtnipdekan" />
                      <label>Nama Dekan</label>
                      <input class="form-control" name="txtnmdekan" id="txtnmdekan" />
                      <label>Status Fakultas</label>
                      <select name="aktifak" class="form-control">
                      <option value="YA">YA</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                      
                      <button type="reset" class="btn btn-default">Reset</button>

                  </form>
              </div>
    </div>  
<?php
}
elseif($_GET[venus]=="fakedit"){
  	$que = "select * from m_fakultas where KD_FAK='$_GET[id]'";
    $result=mysqli_query($GLOBALS,$que);  
    $row = mysqli_fetch_array($result);
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
               <svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"/></svg>Ubah Data Master Fakultas
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=fakultas&act=edit"?>" method="post" enctype="multipart/form-data">
                      <label>Kode Fakultas</label>
                      <input class="form-control" name="txtkdlog" id="txtkdlog" value="<?php echo($_GET[id]); ?>" readonly="readonly"/>
                      <label>Nama Fakultas</label>
                      <input class="form-control" name="txtusername" id="txtusername" value="<?php echo($row[1]);?>" />
                      <label>NIP Dekan</label>
                      <input class="form-control" name="txtnipdekan" id="txtnipdekan" value="<?php echo($row[4]);?>" />
                      <label>Nama Dekan</label>
                      <input class="form-control" name="txtnmdekan" id="txtnmdekan" value="<?php echo($row[3]);?>" />
                      <label>Status Fakultas</label>
                      <select name="aktifak" class="form-control">
                                            
                      <option value="<?php if($_GET[venus]=="fakedit"){ echo($row[2]); }else{echo '--'; }?>"><?php if($_GET[venus]=="fakedit"){ echo($row[2]); }else{echo 'Silahkan Pilih'; }?></option>
                      <option value="YA">YA</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-default">Ubah</button>
                    
                      <button type="reset" class="btn btn-primary">Reset</button>
                      </form>
              </div>
  </div>    
<?php
}
?>