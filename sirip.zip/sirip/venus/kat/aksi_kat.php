<?php session_start();

include "../../config/koneksi.php";
$module=$_GET['venus'];
$act=$_GET['act'];

$sid_lama = session_id();
	
session_regenerate_id();

$sid_baru = session_id();

if($module=='kat' AND $act=='input'){
  $kdkel  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdlog'],ENT_QUOTES))); 
  $nmkel  = stripslashes(strip_tags(htmlspecialchars($_POST['txtusername'],ENT_QUOTES))); 

  $sql =("INSERT INTO m_kategori
  (KD_KAT, NM_KAT) 
  VALUES  ('$kdkel','$nmkel')");

 if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../kat.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
  
 
}
elseif($module=='kat' AND $act=='edit'){

  $kdkel  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdlog'],ENT_QUOTES))); 
  $nmkel  = stripslashes(strip_tags(htmlspecialchars($_POST['txtusername'],ENT_QUOTES))); 

   $sql=("UPDATE m_kategori SET NM_KAT    = '$nmkel' WHERE KD_KAT   = '$kdkel'");
if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../kat.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
}/*
elseif($module=='users' AND $act=='delete'){
    mysql_query("DELETE FROM fakultas WHERE kd_fakultas = '$_REQUEST[sid]'");
    header('location:../../fakultas.html');
}*/
?>