<?php session_start();

include "../../config/koneksi.php";
$module=$_GET['venus'];
$act=$_GET['act'];

$sid_lama = session_id();
	
session_regenerate_id();

$sid_baru = session_id();

if($module=='kec' AND $act=='input'){
  $kdprogdi  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdlog'],ENT_QUOTES))); 
  $nmprogdi  = stripslashes(strip_tags(htmlspecialchars($_POST['txtusername'],ENT_QUOTES))); 
  $kdfak    = $_POST['fak']; 
  $aktiprogdi = $_POST['aktifprogdi']; 

  $sql =("INSERT INTO m_kec
  (KD_KEC, KD_KOTA,NM_KEC) 
  VALUES  ('$kdfak','$kdprogdi','$nmprogdi')");

 if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../kec.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
  
 
}
elseif($module=='kec' AND $act=='edit'){

  $kdprogdi  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdlog'],ENT_QUOTES))); 
  $nmprogdi  = stripslashes(strip_tags(htmlspecialchars($_POST['txtusername'],ENT_QUOTES))); 
  $kdfak    = $_POST['fak']; 
  $aktiprogdi = $_POST['aktifprogdi']; 

   $sql=("UPDATE m_kec SET KD_KOTA='$kdfak' , NM_KEC    = '$nmprogdi' WHERE KD_KEC   = '$kdprogdi'");
if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../kec.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
}/*
elseif($module=='users' AND $act=='delete'){
    mysql_query("DELETE FROM fakultas WHERE KD_KOTAultas = '$_REQUEST[sid]'");
    header('location:../../fakultas.html');
}*/
?>