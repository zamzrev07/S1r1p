<?php session_start();

include "../../config/koneksi.php";
$module=$_GET['venus'];
$act=$_GET['act'];

$sid_lama = session_id();
	
session_regenerate_id();

$sid_baru = session_id();

if($module=='mhs' AND $act=='input'){
  $npm  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnpm'],ENT_QUOTES))); 
  $mname  = stripslashes(strip_tags(htmlspecialchars($_POST['txtmname'],ENT_QUOTES))); 
  $email = stripslashes(strip_tags(htmlspecialchars($_POST['txtemail'],ENT_QUOTES))); 
  $kdpro    = $_POST['prog'];
   
  $jk = $_POST['jk'];
  $mh="mh";
  $paw=$mh.$npm; 
  //autonumber m_login
 $query = "SELECT max(kd_log) as maxKode FROM m_login";
   $hasil = mysqli_query($GLOBALS,$query); 
  $data = mysqli_fetch_array($hasil); 
  $kodeBarang = $data['maxKode']; 
   $noUrut = (int) substr($kodeBarang, 1, 5); 
   $noUrut++; 
   $char="U";
    $newID = $char . sprintf("%05s", $noUrut);
	//selesai auto
	$idn=$newID;
	$ps=md5($paw);
	
	$qin= "SELECT USER_LOG FROM m_login where USER_LOG='$npm'";
	   $hin = mysqli_query($GLOBALS,$qin); 
  $din = mysqli_fetch_array($hin);
 
  
  if ($din>0){
	  $_SESSION['pesan'] = 'Data Sudah Ada';
	  header('location:../../mhs.html');
  }else{
	
	$isl = ("INSERT INTO m_login
  (KD_LOG,USER_LOG,PASS_LOG,ID_SESSION,STA_LOG,AKTIF_LOG) 
  VALUES 
 ('$idn','$npm','$ps','$sid_baru','3','YA')");
 if (mysqli_query($GLOBALS,$isl)){
 		$sml="SELECT KD_LOG FROM M_LOGIN WHERE KD_LOG='$idn'";
 		$hs = mysqli_query($GLOBALS,$sml);
 		$dt = mysqli_fetch_array($hs);
 		$kdm = $dt['KD_LOG'];	 
 		$sql =("INSERT INTO m_mhs
  		(NPM,KD_LOG,KD_PROGDI,NM_MHS,JK_MHS,EMAIL_MHS) 
  		VALUES  ('$npm','$kdm','$kdpro','$mname','$jk','$email')");

		 if (mysqli_query($GLOBALS, $sql)) {
    		header('location:../../mhs.html');
		} else {
    		echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
		}	 
 
 }else{
	 echo "Error: " . $sml . "<br>" . mysqli_error($GLOBALS); 
	 
 }
  }
}
elseif($module=='mhs' AND $act=='edit'){

  $npms  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnpm'],ENT_QUOTES))); 
  $nmmhs  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnamam'],ENT_QUOTES))); 
  $em = stripslashes(strip_tags(htmlspecialchars($_POST['txtemail'],ENT_QUOTES))); 
  $kdprg    = $_POST['prog']; 
  $jk = $_POST['jk'];

   $sql=("UPDATE m_mhs SET NPM='$npms' , KD_PROGDI    = '$kdprg', NM_MHS    = '$nmmhs',JK_MHS = '$jk', EMAIL_MHS = '$em' WHERE NPM   = '$npms'");
if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../mhs.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
}/*
elseif($module=='users' AND $act=='delete'){
    mysql_query("DELETE FROM fakultas WHERE kd_fakultas = '$_REQUEST[sid]'");
    header('location:../../fakultas.html');
}*/
?>