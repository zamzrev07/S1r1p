<script>
function hapusdata(urltujuan){
		el=$(this);
		if(confirm("Do you want to delete the data ?."))
		{
            alert("Data Deleted!");
            
            window.location = (urltujuan);
        }
        else{
            alert("Failure to Delete");
        }
}
</script>
            
<?php
$aksi="venus/pakar/aksi_pakar.php";

  // Tampil Agenda
  if($_GET[venus] == "pakar"){
    $que = "select * from m_kepakaran ";
	$result=mysqli_query($GLOBALS,$que);
	$jumrows = mysqli_num_rows($result);
?>
    
	<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>Data Master Kepakaran</div>
					<div class="panel-body">
                    <a href="pakaradd.html" class="btn btn-primary">Tambah Master Kepakaran</a>
					<table data-toggle="table" data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
        <thead>
            <tr>
                <th data-sortable="true">Kode Kepakaran</th>
                <th data-sortable="true">Nama Kepakaran</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
		<?php
		$iCnt=0;
		if ($jumrows>0) { 
			while ($row = mysqli_fetch_array($result)) {
        $iCnt++;
		?>
        
		  <tr <?php if ($iCnt%2==0) {?>class="odd gradeX" <?php } else {?>class="even gradeC"<?php }?> >
      <td><?php echo strip_tags(strtoupper($row[KD_PAKAR])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[NM_PAKAR])); ?></td>
            <td><a data-toggle="tooltip" data-placement="top" title="edit" href="<?php echo("pakaredit-$row[KD_PAKAR].html")?>" class="btn btn-sm btn-warning">Edit</a></td>  
		  </tr>
		<?php
			}
		}else{
		?>
		<tr>
			<td colspan="6">Data tidak di temukan</td>
		</tr>
		<?php
		}
		?>
        </tbody>
	</table>
    </div>
    </div>
    </div>
    </div>
	<?php
  }
elseif($_GET[venus]=="pakaradd"){

 $query = "SELECT max(KD_PAKAR) as maxKode FROM m_kepakaran";
   $hasil = mysqli_query($GLOBALS,$query); 
  $data = mysqli_fetch_array($hasil); 
  $kodeBarang = $data['maxKode']; 
   $noUrut = (int) substr($kodeBarang, 2, 5); 
   $noUrut++; 
   $char="KP";
    $newID = $char . sprintf("%05s", $noUrut);	
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
             <svg class="glyph stroked plus sign"><use xlink:href="#stroked-plus-sign"/></svg> Tambah Data Master KEPAKARAN
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=pakar&act=input"?>" method="post" enctype="multipart/form-data">
                   <label>Kode KEPAKARAN</label>
                      <input class="form-control" name="txtkdlog" id="txtkdlog" value="<?php echo $newID; ?>" readonly="readonly"/>
                      <label>Nama KEPAKARAN</label>
                      <input class="form-control" name="txtusername" id="txtusername" /><!--
                      <label>Status Progdi</label>
                      <select name="aktifprogdi" class="form-control">
                      <option value="YA">YA</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>-->
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                      
                      <button type="reset" class="btn btn-default">Reset</button>

                  </form>
              </div>
    </div>  
<?php
}
elseif($_GET[venus]=="pakaredit"){
  	$que = "select * from m_kepakaran where KD_PAKAR='$_GET[id]'";
    $result=mysqli_query($GLOBALS,$que);  
    $row = mysqli_fetch_array($result);
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
               <svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"/></svg>Ubah Data Master KEPAKARAN
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=pakar&act=edit"?>" method="post" enctype="multipart/form-data">
                      <label>Kode KEPAKARAN</label>
                      <input class="form-control" name="txtkdlog" id="txtkdlog" value="<?php echo($_GET[id]); ?>" readonly="readonly"/>
                      <label>Nama KEPAKARAN</label>
                      <input class="form-control" name="txtusername" id="txtusername" value="<?php echo($row[NM_PAKAR]);?>" />
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-default">Ubah</button>
                    
                      <button type="reset" class="btn btn-primary">Reset</button>
                      </form>
              </div>
  </div>    
<?php
}
?>