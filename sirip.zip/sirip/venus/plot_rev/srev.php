<script>
function hapusdata(urltujuan){
		el=$(this);
		if(confirm("Do you want to delete the data ?."))
		{
            alert("Data Deleted!");
            
            window.location = (urltujuan);
        }
        else{
            alert("Failure to Delete");
        }
}
</script>
<script src="minerva/ajaxlit.js"></script>           
<?php
$aksi="venus/srev/aksi_srev.php";

  // Tampil Agenda
  if($_GET[venus] == "srev"){
    $que = "select * from m_dosen a, m_progdi b, m_rumpun c,m_kepakaran d, m_jafa e, set_reviewer f, m_subkat g where a.KD_JAFA=e.KD_JAFA and a.KD_PROGDI=b.KD_PROGDI and a.KD_RUMPUN=c.KD_RUMPUN and a.KD_PAKAR=d.KD_PAKAR and a.NPT = f.NPT and f.KD_SUBKAT=g.KD_SUBKAT";
	$result=mysqli_query($GLOBALS,$que);
	$jumrows = mysqli_num_rows($result);
?>
    
	<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>Data Reviewer</div>
					<div class="panel-body">
                    <?php 
    //        menampilkan pesan jika ada pesan
            if (($_SESSION['pesan']) && $_SESSION['pesan'] <> '') {
                echo '<div class="alert bg-danger" role="alert">'.$_SESSION['pesan'].'<button type="button" class="close" data-dismiss="alert">×</button></div>';
            }

    //        mengatur session pesan menjadi kosong
            $_SESSION['pesan'] = '';
            ?> 
                    <a href="srevadd.html" class="btn btn-primary">Tambah Data Reviwer</a>
					<table data-toggle="table" data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
        <thead>
            <tr>
                <th data-sortable="true">NPT / NIDN</th>
                <th data-sortable="true">Nama Dosen</th>
                <th data-sortable="true">Skim</th>
                <th data-sortable="true">Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
		<?php
		$iCnt=0;
		if ($jumrows>0) { 
			while ($row = mysqli_fetch_array($result)) {
        $iCnt++;
		?>
        
		  <tr <?php if ($iCnt%2==0) {?>class="odd gradeX" <?php } else {?>class="even gradeC"<?php }?> >
      <td><?php echo strip_tags(strtoupper($row[NPT])); ?> / <?php echo strip_tags(strtoupper($row[NIDN])); ?></td>
		<td><?php echo strip_tags(strtoupper($row[NM_DOSEN])); ?></td>
<td><?php echo strip_tags(strtoupper($row[NM_SUBKAT])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[AKTIF_DOSEN])); ?></td>
            <td><a data-toggle="tooltip" data-placement="top" title="edit" href="<?php echo("dosenedit-$row[KD_SETR].html")?>" class="btn btn-sm btn-warning">Edit</a></td>  
		  </tr>
		<?php
			}
		}else{
		?>
		<tr>
			<td colspan="6"><div class="alert bg-danger" role="alert">
					<svg class="glyph stroked cancel"><use xlink:href="#stroked-cancel"></use></svg> Data Tidak Ditemukan !!! <a href="#" class="pull-right"><span class="glyphicon glyphicon-remove"></span></a>
				</div></td>
		</tr>
        
		<?php
		}
		?>
        </tbody>
	</table>
    </div>
    </div>
    </div>
    </div>
	<?php
  }
elseif($_GET[venus]=="srevadd"){
$query = "SELECT max(KD_SETR) as maxKode FROM set_reviewer";
   $hasil = mysqli_query($GLOBALS,$query); 
  $data = mysqli_fetch_array($hasil); 
  $kodeBarang = $data['maxKode']; 
   $noUrut = (int) substr($kodeBarang, 2, 5); 
   $noUrut++; 
   $char="SR";
    $newID = $char . sprintf("%05s", $noUrut);	
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
             <svg class="glyph stroked plus sign"><use xlink:href="#stroked-plus-sign"/></svg> Tambah Data Reviewer
          </div>
              <div class="panel-body">
                  <form name="myForm" id="mainform" action="<?php echo"$aksi?venus=srev&act=input"?>" method="post" enctype="multipart/form-data">
<input class="form-control" type="hidden" name="txtkdlog" id="txtkdlog" value="<?php echo $newID; ?>" readonly="readonly"/>
<label>NPT REVIEWER</label>
<input type="hidden" class="form-control" name="thn" value="<?php echo $kd_thn; ?>" />                      
<input type="text" class="form-control" name="txtnpt1" id="txtnpt1" 
                      onkeyup     ="tampilkan_data(this.value,mainform.txtnpt1.value);"/>
                    
                      <label>NAMA REVIEWER</label>
                      <input type="text" class="form-control" name="txtpnls1" id="txtpnls1" readonly="readonly" />
                      <label>KELOMPOK SKIM</label>
                      <select name="skim" class="form-control">
<?php 
$quer = "select * from m_subkat ";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_SUBKAT']; ?>"><?php echo strtoupper($rot['NM_SUBKAT']); ?></option> <?php } ?>
                      </select>
                      
                      <label>Aktif Reviewer</label>
                      <select name="aktif" class="form-control">
                      <option value="YA">YA</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                      
                      <button type="reset" class="btn btn-default">Reset</button>

                  </form>
              </div>
    </div>  
<?php
}
elseif($_GET[venus]=="srevedit"){
  	$que = "select * from m_dosen a, m_progdi b, m_rumpun c,m_kepakaran d, m_jafa e where a.KD_JAFA=e.KD_JAFA and a.KD_PROGDI=b.KD_PROGDI and a.KD_RUMPUN=c.KD_RUMPUN and a.KD_PAKAR=d.KD_PAKAR and a.NPT='$_GET[id]'";
    $result=mysqli_query($GLOBALS,$que);  
    $row = mysqli_fetch_array($result);
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
               <svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"/></svg>Ubah Data Master Dosen
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=dosen&act=edit"?>" method="post" enctype="multipart/form-data">
                      <label>NPT</label>
                      <input class="form-control" name="txtnpt" id="txtnpt" value="<?php echo($_GET[id]); ?>"/>
                      <label>Progdi</label>
                      <select name="prog" class="form-control">
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[KD_PROGDI]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo strtoupper($row[NM_PROGDI]); }else{echo 'Silahkan Pilih'; }?></option>
                      <?php 
$quer = "select * from m_progdi ";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_PROGDI']; ?>"><?php echo strtoupper($rot['NM_PROGDI']); ?></option> <?php } ?>
                      </select>

                      <label>Jabatan Fungsional</label>
                      <select name="jafa" class="form-control">
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[KD_JAFA]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo strtoupper($row[NM_JAFA]); }else{echo 'Silahkan Pilih'; }?></option>
                      <?php 
$quer = "select * from m_jafa ";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_JAFA']; ?>"><?php echo strtoupper($rot['NM_JAFA']); ?></option> <?php } ?>
                      </select>

                     <label>Rumpun</label>
                      <select name="rumpun" class="form-control">
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[KD_RUMPUN]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo strtoupper($row[NM_RUMPUN]); }else{echo 'Silahkan Pilih'; }?></option>
                      <?php 
$querp = "select * from m_rumpun ";
$resultp=mysqli_query($GLOBALS,$querp);
while ($rotp = mysqli_fetch_array($resultp)) { ?>                      
                      <option value="<?php echo $rotp['KD_RUMPUN']; ?>"><?php echo strtoupper($rotp['NM_RUMPUN']); ?></option> <?php } ?>
                      </select>
                      <label>Pakar</label>
                      <select name="pakar" class="form-control">
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[KD_PAKAR]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo strtoupper($row[NM_PAKAR]); }else{echo 'Silahkan Pilih'; }?></option>
                      <?php 
$querpk = "select * from m_kepakaran ";
$resultpk=mysqli_query($GLOBALS,$querpk);
while ($rotpk = mysqli_fetch_array($resultpk)) { ?>                      
                      <option value="<?php echo $rotpk['KD_PAKAR']; ?>"><?php echo strtoupper($rotpk['NM_PAKAR']); ?></option> <?php } ?>
                      </select>
                      <label>NIDN</label>
                      <input class="form-control" name="txtnidn" id="txtnidn" value="<?php echo($row[NIDN]);?>" />
                       <label>Nama Dosen</label>
                      <input class="form-control" name="txtnamdos" id="txtnamdos" value="<?php echo($row[NM_DOSEN]);?>" />
                      
                      <label>Jenis Kelamin</label>
                      <select name="jk" class="form-control">
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[JK_DOSEN]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo($row[JK_DOSEN]); }else{echo 'Silahkan Pilih'; }?></option>
                      <option value="L">Laki-Laki</option>
                      <option value="P">Perempuan</option>
                      </select>

<label>Pendidikan</label>
                      <select name="pend" class="form-control">
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[PENDIDIKAN]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo($row[PENDIDIKAN]); }else{echo 'Silahkan Pilih'; }?></option>
                      <option value="S-1">S1 (SARJANA)</option>
                      <option value="S-2">S2 (PASCA SARJANA MAGISTER)</option>
<option value="S-3">S3 (PASCA SARJANA DOKTOR)</option>
                      </select>

                       <label>Email</label>
                      <input class="form-control" name="txtemail" id="txtemail" value="<?php echo($row[EMAIL_DOSEN]);?>" />
                       <label>Jabatan Akademik</label>
                      <input class="form-control" name="txtjab" id="txtjab" value="<?php echo($row[JAB_AKADEMIK]);?>" />
                      <label>Status Dosen</label>
                      <select name="aktifdosen" class="form-control">                                            
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[AKTIF_DOSEN]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo($row[AKTIF_DOSEN]); }else{echo 'Silahkan Pilih'; }?></option>
                      <option value="YA">YA</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-default">Ubah</button>
                    
                      <button type="reset" class="btn btn-primary">Reset</button>
                      </form>
              </div>
  </div>    
<?php
}
?>