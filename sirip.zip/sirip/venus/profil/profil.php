<script>
function hapusdata(urltujuan){
		el=$(this);
		if(confirm("Do you want to delete the data ?."))
		{
            alert("Data Deleted!");
            
            window.location = (urltujuan);
        }
        else{
            alert("Failure to Delete");
        }
}
</script>
            
<?php include "../../config/koneksi.php";
$aksi="venus/profil/aksi_profil.php";

if(isset($_POST['ubah'])){
  $namado = stripslashes(strip_tags(htmlspecialchars($_POST['txtusername'],ENT_QUOTES))); 
  $nidn   = stripslashes(strip_tags(htmlspecialchars($_POST['txtnidn'],ENT_QUOTES))); 
  $txtpasslama   = stripslashes(strip_tags(htmlspecialchars($_POST['txtpasslama'],ENT_QUOTES))); 
  $txtpassbaru   = stripslashes(strip_tags(htmlspecialchars($_POST['txtpassbaru'],ENT_QUOTES))); 
  $txtpassbarumd5 = md5($txtpassbaru);
  $fak    = $_POST['fak'];
  $jafa   = $_POST['jabfung'];
  $email  = $_POST['txtemail'];
  $jenjang = $_POST['jenjang'];
  $rumpun = $_POST['rumpun'];
  $pakar  = $_POST['pakar']; 
  $txtkdlog  = $_POST['txtkdlog']; 

$sql = "UPDATE m_dosen SET NM_DOSEN='$namado', NIDN='$nidn', KD_PROGDI='$fak', JAB_AKADEMIK='$jafa', 
        EMAIL_DOSEN = '$email', PENDIDIKAN='$jenjang',KD_RUMPUN='$rumpun', KD_PAKAR = '$pakar' where NPT='$txtkdlog'";
$sql2 = "UPDATE m_login PASS_LOG = '$txtpassbarumd5' where USER_LOG='$txtkdlog'"; 

$psn1 = "Pengubahan Data Gagal ... <a href='../../profil.html'>.Kembali</a>";
$psn2 = "Password yang dimasukkan TIDAK SAMA ... <a href='../../profil.html'>.Kembali</a>";

if(($txtpasslama != $txtpassbaru)&&($txtpassbaru != ''))
  { 
    echo "Error: " . $psn2 . "<br>" . mysqli_error($GLOBALS);
  }
  else {

 if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../profil.html');
}
 else {
    echo "Error: " . $psn1 . "<br>" . mysqli_error($GLOBALS);
}
}
}

  // Tampil Agenda
  if($_GET[venus] == "profil"){
  $que = "select * from m_login a, m_dosen b where a.USER_LOG = b.NPT and a.USER_LOG=$_SESSION[USER_LOG]";
	$result=mysqli_query($GLOBALS,$que);
	$jumrows = mysqli_num_rows($result);
  $row = mysqli_fetch_array($result);

?>
    
	<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>Profil <b><?php echo $_SESSION[USER_LOG]; ?></b> </div>
					<div class="panel-body"> 
					  
                  <form name="mainform" id="mainform" action="venus/profil/profil.php" method="post" enctype="multipart/form-data">
                   <label>NPT</label>
                      <input class="form-control" name="txtkdlog" id="txtkdlog" value="<?php echo $_SESSION[USER_LOG]; ?>" readonly="readonly"/><br>
                      <label>Nama Dosen</label>
                      <input class="form-control" name="txtusername" id="txtusername" value="<?php echo $row[NM_DOSEN]; ?>" /><br>
                      <label>NIDN Dosen</label>
                      <input class="form-control" name="txtnidn" id="txtnidn" value="<?php echo $row['NIDN'] ?>" readonly="readonly"/><br>
                      <label>Password Login</label>
                      <input class="form-control" type="password" name="txtpasslama" id="txtpasslama" value="<?php echo $row[PASS_LOG];?>" /><br>
                      <label>Co. Password Login</label>
                      <input class="form-control" type="password" name="txtpassbaru" id="txtpassbaru" value="" /><br>
                      <label>Satuan Kerja</label>
                      <select name="fak" class="form-control">
<?php 
$quer = "select * from m_fakultas a, m_dosen b, m_progdi c where  a.KD_FAK=c.KD_FAK and b.KD_PROGDI=c.KD_PROGDI and b.NPT=$_SESSION[USER_LOG]";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_PROGDI']; ?>"><?php echo strtoupper($rot['NM_FAK']); ?> - <?php echo strtoupper($rot['NM_PROGDI']); ?></option> <?php } ?>
                      <option value="--">--Silahkan Ubah Progdi--</option>
                      <?php 
$quer2 = "select * from m_fakultas a, m_progdi c where a.KD_FAK=c.KD_FAK";
$resultt2=mysqli_query($GLOBALS,$quer2);
while ($rot2 = mysqli_fetch_array($resultt2)) { ?>                      
                      <option value="<?php echo $rot2['KD_FAK']; ?>"><?php echo strtoupper($rot2['NM_FAK']); ?> - <?php echo strtoupper($rot2['NM_PROGDI']); ?></option> <?php } ?>
                      </select><br>
                      <label>Jabatan Fungsional</label>
                      <select name="jabfung" class="form-control">
<?php 
$quer = "select * from m_jafa a, m_dosen b where  a.KD_JAFA=b.KD_JAFA and b.NPT=$_SESSION[USER_LOG]";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_JAFA']; ?>"><b><?php echo strtoupper($rot['NM_JAFA']); ?></b></option> <?php } ?>
                      <option value="--">--SILAHKAN UBAH JABATAN FUNGSIONAL--</option>
                      <?php 
$quer2 = "select * from m_jafa";
$resultt2=mysqli_query($GLOBALS,$quer2);
while ($rot2 = mysqli_fetch_array($resultt2)) { ?>                      
                      <option value="<?php echo $rot2['KD_JAFA']; ?>"><?php echo strtoupper($rot2['NM_JAFA']); ?> </option> <?php } ?>
                      </select><br>
                       <label>Email</label>
                      <input class="form-control" type="email" name="txtemail" id="txtemail" value="<?php echo $row[EMAIL_DOSEN];?>" />
                      <br>
                       
                      <label>Jenjang Pendidikan</label>
                      <select name="jenjang" class="form-control">
                      <?php 
$quer2 = "select PENDIDIKAN from m_dosen where NPT=$_SESSION[USER_LOG] ";
$resultt2=mysqli_query($GLOBALS,$quer2);
while ($rot2 = mysqli_fetch_array($resultt2)) { ?>                      
                      <option value="<?php echo $rot2['PENDIDIKAN']; ?>"><?php echo strtoupper($rot2['PENDIDIKAN']); ?> </option> <?php } ?>
                      <option value="--">--SILAHKAN UBAH PENDIDIKAN AKHIR--</option>
                      <option value="D3">DIPLOMA 3</option>
                      <option value="D4">DIPLOMA 4</option>
                      <option value="S1">SARJANA</option>
                      <option value="S2">PASCA MAGISTER</option>
                      <option value="S3">PASCA DOKTOR</option>
                      </select><br>
                      <label>Rumpun Ilmu</label>
                      <select name="rumpun" class="form-control">
<?php 
$quer = "select * from m_rumpun a, m_dosen b where  a.KD_RUMPUN=b.KD_RUMPUN and b.NPT=$_SESSION[USER_LOG]";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_RUMPUN']; ?>"><?php echo strtoupper($rot['NM_RUMPUN']); ?></option> <?php } ?>
                      <option value="--">--SILAHKAN UBAH RUMPUN ILMU--</option>
                      <?php 
$quer2 = "select * from m_rumpun";
$resultt2=mysqli_query($GLOBALS,$quer2);
while ($rot2 = mysqli_fetch_array($resultt2)) { ?>                      
                      <option value="<?php echo $rot2['KD_RUMPUN']; ?>"><?php echo strtoupper($rot2['NM_RUMPUN']); ?> </option> <?php } ?>
                      </select>
<br>
                      <label>Kepakaran Ilmu</label>
                      <select name="pakar" class="form-control">
<?php 
$quer = "select * from m_kepakaran a, m_dosen b where  a.KD_PAKAR=b.KD_PAKAR and b.NPT=$_SESSION[USER_LOG]";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_PAKAR']; ?>"><b><?php echo strtoupper($rot['NM_PAKAR']); ?></b></option> <?php } ?>
                      <option value="--">--SILAHKAN UBAH KEPAKARAN ILMU--</option>
                      <?php 
$quer2 = "select * from m_kepakaran";
$resultt2=mysqli_query($GLOBALS,$quer2);
while ($rot2 = mysqli_fetch_array($resultt2)) { ?>                      
                      <option value="<?php echo $rot2['KD_PAKAR']; ?>"><?php echo strtoupper($rot2['NM_PAKAR']); ?> </option> <?php } ?>
                      </select><br>
                      <label>Status profil</label>
                      <select name="aktifprofil" class="form-control">
                      <option value="YA">YA</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>
                      <p>&nbsp;</p>
                      <button type="submit" name="ubah" class="btn btn-primary">Ubah</button>
                  </form>
    </div>
    </div>
    </div>
    </div>
	<?php
  }
?>
