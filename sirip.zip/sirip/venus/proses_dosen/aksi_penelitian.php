<?php session_start();

include "../../config/koneksi.php";
include "../../config/bytesf.php";
$module=$_GET['venus'];
$act=$_GET['act'];

$sid_lama = session_id();
	
session_regenerate_id();

$sid_baru = session_id();
$tanggal = date("Y-m-d");

if($module=='penelitian' AND $act=='input'){
	$allowed_ext	= array('doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'pdf', 'rar', 'zip');
	
				$file_name		= $_FILES['filezip']['name'];
				$file_ext		= strtolower(end(explode('.', $file_name)));
				$file_size		= $_FILES['filezip']['size'];
				$file_tmp		= $_FILES['filezip']['tmp_name'];
				
				$file_name1 	= $_FILES['filepdf']['name'];
				$file_ext1		= strtolower(end(explode('.', $file_name1)));
				$file_size1		= $_FILES['filepdf']['size'];
				$file_tmp1		= $_FILES['filepdf']['tmp_name'];
	
	
  $kdpn  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdpn'],ENT_QUOTES))); 
  $npt1  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnpt1'],ENT_QUOTES)));
   $npt2  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnpt2'],ENT_QUOTES)));
    $npt3  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnpt3'],ENT_QUOTES)));
$statp="PROPOSAL";
$statlt="TAHUN 1";
$jdlp  = stripslashes(strip_tags(htmlspecialchars($_POST['txtjdlp'],ENT_QUOTES)));
$subkat  = $_POST['subkat'];
$abstrak  = stripslashes(strip_tags(htmlspecialchars($_POST['abstrak'],ENT_QUOTES))); 
$dana  = stripslashes(strip_tags(htmlspecialchars($_POST['txtdana'],ENT_QUOTES))); 




if(in_array($file_ext,$allowed_ext) === true){
	if($file_size and $file_size1 < 2044070){
						$lokasi = '../../files/berkas/'.$npt1.'.'.$file_ext;
						$lokasi1= '../../files/abstrak/'.$npt1.'.'.$file_ext1;
						move_uploaded_file($file_tmp, $lokasi);
						move_uploaded_file($file_tmp1, $lokasi1);
/*  	$sql =("INSERT INTO prop_lit
  					(KD_LIT,NPT,KD_SUBKAT,KD_THN,WKT_LIT,JDL_PROPOSAL,UNGGAH_PROPOSAL,UNGGAH_ABSTRAK,ABSTRAK_TEXT,STATUS_PROPOSAL,NPT_ANGGOTA2,NPT_ANGGOTA3,STATUS_LIT) 
  					VALUES  ('$kdpn','$npt1','$subkat','$kd_thn','$tanggal','$jdlp','$lokasi','$lokasi1','$abstrak',$statp,$npt2,$npt3,$statlt)"); */
$sql =("INSERT INTO prop_lit
  					(KD_LIT,NPT,KD_SUBKAT,KD_THN,JDL_PROPOSAL,UNGGAH_PROPOSAL,UNGGAH_ABSTRAK,ABSTRAK_TEXT,STATUS_PROPOSAL,NPT_ANGGOTA2,NPT_ANGGOTA3,STATUS_LIT,DANA_LIT) 
  					VALUES  ('$kdpn','$npt1','$subkat','$kd_thn','$jdlp','$lokasi','$lokasi1','$abstrak','$statp','$npt2','$npt3','$statlt','$dana')");

 					if (mysqli_query($GLOBALS, $sql)) {
    				header('location:../../penelitian.html');
					} else {
    				echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
					}
	}else{
		$_SESSION['pesan'] = 'File Size terlalu Besar';
	  header('location:../../penelitian.html');
		}
}else{
	$_SESSION['pesan'] = 'Ekstensi File Tidak Diizinkan';
	  header('location:../../penelitian.html');
}
	
}

elseif($module=='penelitian' AND $act=='edit'){

 $allowed_ext	= array('doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'pdf', 'rar', 'zip');
	
				$file_name		= $_FILES['filezip']['name'];
				$file_ext		= strtolower(end(explode('.', $file_name)));
				$file_size		= $_FILES['filezip']['size'];
				$file_tmp		= $_FILES['filezip']['tmp_name'];
				
				$file_name1 	= $_FILES['filepdf']['name'];
				$file_ext1		= strtolower(end(explode('.', $file_name1)));
				$file_size1		= $_FILES['filepdf']['size'];
				$file_tmp1		= $_FILES['filepdf']['tmp_name'];
	
	
  $kdpn  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdpn'],ENT_QUOTES))); 
  $npt1  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnpt1'],ENT_QUOTES)));
   $npt2  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnpt2'],ENT_QUOTES)));
$dana  = stripslashes(strip_tags(htmlspecialchars($_POST['txtdana'],ENT_QUOTES))); 
    $npt3  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnpt3'],ENT_QUOTES)));
$statp="PROPOSAL";
$statlt="TAHUN 1";
$jdlp  = stripslashes(strip_tags(htmlspecialchars($_POST['txtjdlp'],ENT_QUOTES)));
$subkat  = $_POST['skim'];
$abstrak  = stripslashes(strip_tags(htmlspecialchars($_POST['abstrak'],ENT_QUOTES))); 


if (empty($file_tmp) and (empty($file_tmp1))){
	$sql =("UPDATE prop_lit SET 																								NPT='$npt1' , KD_SUBKAT = '$subkat', JDL_PROPOSAL = '$jdlp', ABSTRAK_TEXT = '$abstrak', NPT_ANGGOTA2 = '$npt2', NPT_ANGGOTA3 = '$npt3' WHERE KD_LIT   = '$kdpn'");
			
 					if (mysqli_query($GLOBALS, $sql)) {
    				header('location:../../penelitian.html');
					} else {
    				echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
					}
	
}else{
if(in_array($file_ext,$allowed_ext) === true){
	if($file_size and $file_size1 < 2044070){
						$lokasi = '../../files/berkas/'.$npt1.'.'.$file_ext;
						$lokasi1= '../../files/abstrak/'.$npt1.'.'.$file_ext1;
						move_uploaded_file($file_tmp, $lokasi);
						move_uploaded_file($file_tmp1, $lokasi1);
/*  	$sql =("INSERT INTO prop_lit
  					(KD_LIT,NPT,KD_SUBKAT,KD_THN,WKT_LIT,JDL_PROPOSAL,UNGGAH_PROPOSAL,UNGGAH_ABSTRAK,ABSTRAK_TEXT,STATUS_PROPOSAL,NPT_ANGGOTA2,NPT_ANGGOTA3,STATUS_LIT) 
  					VALUES  ('$kdpn','$npt1','$subkat','$kd_thn','$tanggal','$jdlp','$lokasi','$lokasi1','$abstrak',$statp,$npt2,$npt3,$statlt)"); */
								
					
					
			
			$sql =("UPDATE prop_lit SET 																				NPT='$npt1' , KD_SUBKAT = '$subkat', JDL_PROPOSAL = '$jdlp', UNGGAH_PROPOSAL = '$lokasi', UNGGAH_ABSTRAK = '$lokasi1', ABSTRAK_TEXT = '$abstrak', NPT_ANGGOTA2 = '$npt2', NPT_ANGGOTA3 = '$npt3', DANA_LIT='$dana' WHERE KD_LIT   = '$kdpn'");
			
 					if (mysqli_query($GLOBALS, $sql)) {
						unlink("sirip/sirip/$_POST[up]");
						unlink("sirip/sirip/$_POST[ua]");
						
    				header('location:../../penelitian.html');
					} else {
    				echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
					}
	
	}else{
		$_SESSION['pesan'] = 'File Size terlalu Besar';
	  header('location:../../penelitian.html');
		}
}else{
	$_SESSION['pesan'] = 'Ekstensi File Tidak Diizinkan';
	  header('location:../../penelitian.html');
}
}
}
?>