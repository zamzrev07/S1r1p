<?php  
header('content-type:text/xml');   
if($_SERVER["SERVER_PROTOCOL"]=="HTTP/1.0")  
    header("Pragma: no-cache");  
else  
    header("Cache-Control: no-cache, must-revalidate");  
$kode   =$_GET['kode'];  
$jumlah =$_GET['jumlah'];  
session_start();

include "../../config/koneksi.php"; 


$que ="select NPT, NIDN, NM_DOSEN from m_dosen where NPT='$kode'";
$sql = mysqli_query($GLOBALS,$que);
$r =mysqli_fetch_array($sql);
$ro =mysqli_num_rows($sql);
/*********=---Proses--=***********/  
// data dari mysql, 

$dsn1 = $r[2]; //nama  
/********************************************************/  
if($ro > 0 ){
echo"  
     <data>   
         <penulis1>".$dsn1."</penulis1>  
     </data>  
";  }
else {
echo"  
     <data>   
         <penulis1>Data Tidak Ditemukan</penulis1>  
     </data>  
";
}
?>  
