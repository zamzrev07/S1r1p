<script src="minerva/ajaxlit.js"></script>
<script language="javascript" src="minerva/ez.js"></script>
<script type="text/javascript" src="minerva/Autocomplete.js"></script>
 <script type="text/javascript">
			(function(window, document, undefined) {
				"use strict";
				
				var myAutocomplete = new Autocomplete("txtnpt1", "txtnpt2", "txtnpt3", {
				    	useNativeInterface : false, 
				    	srcType : "dom"
				    });
					
					
					
				
			})(this, this.document);
		</script>
        		
        
<link rel="stylesheet" type="text/css" href="css/pop.css"/>  
<?php
include "../../config/koneksi.php";
$aksi="venus/proses_dosen/aksi_penelitian.php";
$url = $_SERVER['REQUEST_URI'].''; 

  // Tampil Agenda
  if($_GET[venus] == "penelitian"){
  if($stat == '1'){
  $que = "select prop_lit.KD_LIT, 
	prop_lit.NPT, 
	m_dosen.NM_DOSEN, 
	m_progdi.NM_PROGDI, 
	m_subkat.NM_SUBKAT, 
	prop_lit.JDL_PROPOSAL, 
	m_tahun.KD_THN,m_dosen.NIDN,prop_lit.STATUS_PROPOSAL,prop_lit.UNGGAH_PROPOSAL,prop_lit.BATCH_LIT
	from prop_lit inner join m_dosen on prop_lit.NPT=m_dosen.NPT inner join m_progdi on m_dosen.KD_PROGDI=m_progdi.KD_PROGDI inner join m_subkat on prop_lit.KD_SUBKAT=m_subkat.KD_SUBKAT inner join m_tahun on prop_lit.KD_THN=m_tahun.KD_THN where m_tahun.KD_THN='$kd_thn' order by prop_lit.WKT_LIT desc"; }
  elseif($stat == '2'){ 
    $que = "select prop_lit.KD_LIT, 
  prop_lit.NPT, 
  m_dosen.NM_DOSEN, 
  m_progdi.NM_PROGDI, 
  m_subkat.NM_SUBKAT, 
  prop_lit.JDL_PROPOSAL, 
  m_tahun.KD_THN,m_dosen.NIDN,prop_lit.STATUS_PROPOSAL,prop_lit.UNGGAH_PROPOSAL,prop_lit.BATCH_LIT
  from prop_lit inner join m_dosen on prop_lit.NPT=m_dosen.NPT inner join m_progdi on m_dosen.KD_PROGDI=m_progdi.KD_PROGDI inner join m_subkat on prop_lit.KD_SUBKAT=m_subkat.KD_SUBKAT inner join m_tahun on prop_lit.KD_THN=m_tahun.KD_THN where m_tahun.KD_THN='$kd_thn' and prop_lit.NPT = '$nptku' OR NPT_ANGGOTA2='$nptku' OR NPT_ANGGOTA3 = '$nptku' order by prop_lit.WKT_LIT asc";
  }
  elseif($stat == '3'){
    $que = "select * from prop_lit a, m_reviewer b, m_dosen c, set_reviewer d 
            where a.KD_LIT = b.KD_LIT and a.NPT = c.NPT and b.KD_SETR = d.KD_SETR and d.NPT = $nptku"; 
  } //echo $que;
	$result=mysqli_query($GLOBALS,$que);
	$jumrows = mysqli_num_rows($result);
?>
<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>Data Peserta PENELITIAN</div>
					<div class="panel-body">
                    <?php 
    //        menampilkan pesan jika ada pesan
            if (($_SESSION['pesan']) && $_SESSION['pesan'] <> '') {
                echo '<div class="alert bg-danger" role="alert">'.$_SESSION['pesan'].'<button type="button" class="close" data-dismiss="alert">×</button></div>';
            }

    //        mengatur session pesan menjadi kosong
            $_SESSION['pesan'] = '';
            ?> 
           <a href="penelitianadd.html" class="btn btn-primary">Tambah Data Peserta Penelitian</a>
					<table data-toggle="table" data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
        <thead>
            <tr>
                <!--<th data-sortable="true">KD_PENELITIAN</th><th data-sortable="true">PROGDI</th>-->
                <th data-sortable="true">NO</th>
                <th data-sortable="true">DOSEN PENGUSUL</th>
                <th data-sortable="true">SKIM</th>
                <th data-sortable="true">JUDUL PROPOSAL</th>
                <th data-sortable="true">STATUS</th>
                <th>UNDUH</th
                ><th>Ubah / Detail</th>
				
            </tr>
        </thead>
        <tbody>
		<?php
		$iCnt=0;
		if ($jumrows>0) { 
			while ($row = mysqli_fetch_array($result)) {
		$uu = "sirip/$row[UNGGAH_PROPOSAL]";  
        $iCnt++;
   
		?>
        
		  <tr <?php if ($iCnt%2==0) {?>class="odd gradeX" <?php } else {?>class="even gradeC"<?php }?> >
      		<!--<td><?php echo strip_tags(strtoupper($row[0])); ?></td>-->
		    <?php 
       if($nptku == $row[NPT]){
            $warna = "<p style='background-color:yellow'>";
          }
        ?>
        <td><?php echo $iCnt; ?></td>   
            <td><b><u>Penulis 1</u></b> <br> <?=$warna;?>(<?php echo strip_tags(strtoupper($row[NPT])); ?> / <?php echo strip_tags(strtoupper($row[NIDN])); ?>)<br>
			<?php echo strip_tags(strtoupper($row[2]));//END PENULIS 1?></p> 
<b><u>Penulis 2</u></b> <br> <?php 
$que2 = "select prop_lit.KD_LIT, 
	prop_lit.NPT_ANGGOTA2, 
	m_dosen.NM_DOSEN, 
	m_progdi.NM_PROGDI, 
	m_subkat.NM_SUBKAT, 
	prop_lit.JDL_PROPOSAL, 
	m_tahun.KD_THN,m_dosen.NIDN,prop_lit.STATUS_PROPOSAL
	from prop_lit inner join m_dosen on prop_lit.NPT_ANGGOTA2=m_dosen.NPT inner join m_progdi on m_dosen.KD_PROGDI=m_progdi.KD_PROGDI inner join m_subkat on prop_lit.KD_SUBKAT=m_subkat.KD_SUBKAT inner join m_tahun on prop_lit.KD_THN=m_tahun.KD_THN where m_tahun.KD_THN='$kd_thn' and prop_lit.KD_LIT='$row[0]'";
	$result2=mysqli_query($GLOBALS,$que2);
	$row2=mysqli_fetch_array($result2); ?>
  <?php 
       if($nptku == $row2[1]){
            $warna2 = "<p style='background-color:yellow'>";
          }
echo $warna2; ?>
(<?php echo strip_tags(strtoupper($row2[1])); ?> / <?php echo strip_tags(strtoupper($row2[NIDN])); ?>)<br><?php echo strip_tags(strtoupper($row2[NM_DOSEN])); //END PENULIS 1?></p>
<b><u>Penulis 3</u></b> <br> <?php 
$que3 = "select prop_lit.KD_LIT, 
  prop_lit.NPT_ANGGOTA3, 
  m_dosen.NM_DOSEN, 
  m_progdi.NM_PROGDI, 
  m_subkat.NM_SUBKAT, 
  prop_lit.JDL_PROPOSAL, 
  m_tahun.KD_THN,m_dosen.NIDN,prop_lit.STATUS_PROPOSAL
  from prop_lit inner join m_dosen on prop_lit.NPT_ANGGOTA3=m_dosen.NPT inner join m_progdi on m_dosen.KD_PROGDI=m_progdi.KD_PROGDI inner join m_subkat on prop_lit.KD_SUBKAT=m_subkat.KD_SUBKAT inner join m_tahun on prop_lit.KD_THN=m_tahun.KD_THN where m_tahun.KD_THN='$kd_thn' and prop_lit.KD_LIT='$row[0]'";
	$result3=mysqli_query($GLOBALS,$que3);
	$row3=mysqli_fetch_array($result3); $npt3 = $row3[NPT_ANGGOTA3]; 
  if($nptku == $npt3){
            $warna3 = "<p style='background-color:yellow'>";
          } echo $warna3;?>
(<?php echo strip_tags(strtoupper($row3[NPT])); ?> / <?php echo strip_tags(strtoupper($row3[NIDN])); ?>)<br><?php echo strip_tags(strtoupper($row3[NM_DOSEN]));?></p></td>
          <!--  <td><?php echo strip_tags(strtoupper($row[3])); ?></td> -->
            <td><?php echo strip_tags(strtoupper($row[4])); ?><br> <?php echo strip_tags(strtoupper($row[BATCH_LIT])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[5])); ?></td>
<td><?php echo strip_tags(strtoupper($row[STATUS_PROPOSAL])); ?></td>
<td><center><a href="#" onclick='window.open("sirip/<?php echo $uu ?>")' target='_blank'><img src="img/pdfdown.gif" width='40'></a></center></td>
<td><a data-toggle="tooltip" data-placement="top" title="edit" href="<?php echo("penelitian-edit-$row[0].html")?>"><button class="btn btn-sm btn-warning">Edit</button></a>
<a href="#popup" id="<?php 
	$data['kd_m']=$row[0];
	echo $data['kd_m'] ?>" class="ubah"><button class="btn btn-sm btn-info">Detail</button></a></td>  
		  </tr>
		<?php
			}
		}else{
		?>
		<tr>
			<td><div class="alert alert-danger" role="alert">
					<svg class="glyph stroked cancel"><use xlink:href="#stroked-cancel"></use></svg> <strong>Data</strong> Tidak Ditemukan !!! <a href="#" class="pull-right"><span class="glyphicon glyphicon-remove"></span></a>
				</div></td>
		</tr>
        
		<?php
		}
		?>
        </tbody>
	</table>
     <!-- untuk detail pop up -->
	<div class="popup-wrapper" id="popup">
	<div class="popup-container">
   
		
		<a class="popup-close" href="#closed">X</a>
	</div>
</div> <!-- end pop up detail -->
    </div>
    </div>
    </div>
    </div>
	<?php
	
  }
  elseif($_GET[venus]=="penelitianadd"){
	  $query = "SELECT max(KD_LIT) as maxKode FROM prop_lit";
   $hasil = mysqli_query($GLOBALS,$query); 
  $data = mysqli_fetch_array($hasil); 
  $kodeBarang = $data['maxKode']; 
   $noUrut = (int) substr($kodeBarang, 3, 5); 
   $noUrut++; 
   $char="LIT";
    $newID = $char . sprintf("%05s", $noUrut);
	  
	  ?>
      <div class="col-md-12">
      <div class="panel panel-default">
					<div class="panel-body tabs">
					
						<ul class="nav nav-pills">
							<li class="active"><a href="#pilltab1" data-toggle="tab">DATA PENGUSUL</a></li>
							<li><a href="#pilltab2" data-toggle="tab">BERKAS USULAN</a></li>
              <li><a href="penelitian.html">LIST PROPOSAL</a></li>
						</ul>
          
            
                  <form name="myForm" id="mainform" action="<?php echo"$aksi?venus=penelitian&act=input"?>" method="post" enctype="multipart/form-data">
                  		<div class="tab-content">
							<div class="tab-pane fade in active" id="pilltab1">
                <div class="alert alert-success">
  <strong>Data Pengusul Penelitian</strong>
</div>

                   <label>KD_PENELITIAN</label>
                      <input class="form-control" name="txtkdpn" id="txtkdpn" value="<?php echo $newID ?>" readonly="readonly"/>
                   <label>NPT PENULIS 1</label>&nbsp;<font color="#FF0000"><span id="pesan"></span></font>
                      <input type="text" class="form-control" list="demoList" name="txtnpt1" id="txtnpt1" 
                      onkeyup     ="tampilkan_data(this.value,mainform.txtnpt1.value);" 
                      <?php if($stat == '2'){ echo "value = '$nptku' "; }?>/>
                     
					<div class="aListCon">
                    <datalist id="demoList">
                     <?php 
$auto = "select * from m_dosen ";
$resultau=mysqli_query($GLOBALS,$auto);
$rotau = mysql_num_rows($resultau);

	
while ($rotau = mysqli_fetch_array($resultau)) { ?>
						<!--[if IE 9]><select disabled><![endif]-->
                       <option value="<?php echo $rotau['NPT']; ?>"><?php } ?>
                      
                      
                      	<!--[if IE 9]></select><![endif]-->
					</datalist>
				</div>
                        
                    <?php if($stat != '2'){ ?>
                      <label>NAMA PENULIS 1</label>
                      <input type="text" class="form-control" name="txtpnls1" id="txtpnls1" readonly="readonly" />
                     <?php } ?>
                    <label>NPT PENULIS 2</label>&nbsp;<font color="#FF0000"><span id="pesan1"></span></font>
                      <input type="text" list="2List" class="form-control" name="txtnpt2" id="txtnpt2" />
                      <div class="aListCon">
                    <datalist id="2List">
                      <?php 
$auto2 = "select * from m_dosen ";
$resultau2=mysqli_query($GLOBALS,$auto2);
$rotau2 = mysql_num_rows($resultau2);

	
while ($rotau2 = mysqli_fetch_array($resultau2)) { ?>
						<!--[if IE 9]><select disabled><![endif]-->
                       <option value="<?php echo $rotau2['NPT']; ?>"><?php } ?>
                      
                      
                      
                      
                      </datalist>
				</div>
                      
                       <label>NPT PENULIS 3</label>&nbsp;<font color="#FF0000"><span id="pesan2"></span></font>
                      <input type="text" class="form-control" name="txtnpt3" id="txtnpt3" list="3List" />
                      <div class="aListCon">
                    <datalist id="3List">
                      <?php 
$auto3 = "select * from m_dosen ";
$resultau3=mysqli_query($GLOBALS,$auto3);
$rotau3 = mysql_num_rows($resultau3);

	
while ($rotau3 = mysqli_fetch_array($resultau3)) { ?>
						<!--[if IE 9]><select disabled><![endif]-->
                       <option value="<?php echo $rotau3['NPT']; ?>"><?php } ?>
                      
                      
                      
                      
                      </datalist>
				</div>
                      <p>&nbsp;</p>
                      </div>
                  <div class="tab-pane fade" id="pilltab2">
                          <div class="alert alert-success">
  <strong>Data Berkas Penelitian</strong>
</div>
                      <div class="form-group">
									<label>JUDUL PENELITIAN</label>
									<textarea name="txtjdlp" class="form-control" rows="3" required="required"></textarea>
                      </div>
           <div class="form-group">
                  <label>BATCH</label>
                  <select name="subkat" class="form-control" >
                  <option value="BATCH 1">BATCH 1</option>
                  <option value="BATCH 2">BATCH 2</option>
                  <option value="BATCH 3">BATCH 3</option>
                  <option value="BATCH 4">BATCH 4</option>
                  <option value="BATCH 5">BATCH 5</option>
                  </select>
                                    
          </div>
                  <div class="form-group">
									<label>SKIM</label>
									<select name="subkat" class="form-control" >
										<?php 
$quer = "select * from m_subkat ";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_SUBKAT']; ?>"><?php echo strtoupper($rot['NM_SUBKAT']); ?></option> <?php } ?>
									</select>
                                    
					</div>
          <div class="form-group">
                  <label>DANA PENGAJUAN PENELITIAN</label>
                  <input type="text" name="txtdana" id="txtdana" class="form-control" required="required" onkeypress='return isNumberKeyTrue(event)' onPaste='false' onkeyup="document.getElementById('format').innerHTML = formatCurrency(this.value);"/><span  id="format"></span>
                      </div>
                     <div class="form-group">
									<label>Upload File Proposal</label>
									<input type="file" name="filezip" required="required">
									 <p class="help-block">Upload proposal lengkap dengan format .zip</p>
								</div>
                       <div class="form-group">
									<label>Upload Abstrak</label>
									<input type="file" name="filepdf">
									 <p class="help-block">Upload Abstrak dengan format .pdf</p>
								</div>          
                       <div class="form-group">
									<label>ABSTRAK PENELITIAN</label>
									<textarea name="abstrak" class="form-control" rows="3"></textarea>
                      </div>
                      </div>

                      <button type="submit" class="btn btn-primary">Simpan</button>
                      
                      <button type="reset" class="btn btn-default">Reset</button>                      
</div>
                      

                  </form>
              </div>
    </div>
    </div>  
<?php
  }elseif($_GET[venus]=="penelitianedit"){
    $que = "select * from prop_lit a, m_dosen b, m_progdi c, m_subkat d, m_tahun e where a.NPT=b.NPT and b.KD_PROGDI=c.KD_PROGDI and a.KD_SUBKAT=d.KD_SUBKAT and a.KD_THN=e.KD_THN and a.KD_LIT='$_GET[id]'";
    $result=mysqli_query($GLOBALS,$que);  
    $row = mysqli_fetch_array($result);
?>  
<div class="col-md-12">
      <div class="panel panel-default">
          <div class="panel-body tabs">
          
            <ul class="nav nav-pills">
              <li class="active"><a href="#pilltab1" data-toggle="tab">DATA PENGUSUL</a></li>
              <li><a href="#pilltab2" data-toggle="tab">BERKAS USULAN</a></li>
            </ul>
          
            
                  <form name="myForm" id="mainform" action="<?php echo"$aksi?venus=penelitian&act=edit"?>" method="post" enctype="multipart/form-data">
                      <div class="tab-content">
              <div class="tab-pane fade in active" id="pilltab1">
                <div class="alert alert-success">
  <strong>Data Pengusul Penelitian</strong>
</div>
  <input type="hidden" class="form-control" name="txtup" id="txtup" value="<?php echo $row[UNGGAH_PROPOSAL]; ?>"/>
   <input type="hidden" class="form-control" name="txtua" id="txtua" value="<?php echo $row[UNGGAH_ABSTRAK]; ?>"/>

                   <label>KD_PENELITIAN</label>
                      <input class="form-control" name="txtkdpn" id="txtkdpn" value="<?php echo $_GET[id] ?>" readonly="readonly"/>
                   <label>NPT PENULIS 1</label>
                      <input type="text" class="form-control" name="txtnpt1" id="txtnpt1" value="<?php echo $row[NPT] ?>" onkeyup     ="tampilkan_data(this.value,mainform.txtnpt1.value);"/>
                    
                      <label>NAMA PENULIS 1</label>
                      <input type="text" class="form-control" name="txtpnls1" id="txtpnls1" readonly="readonly" value="<?php echo $row[NM_DOSEN] ?>" />
                     
                    <label>NPT PENULIS 2</label>
                      <input type="text" class="form-control" name="txtnpt2" id="txtnpt2" value="<?php echo $row[NPT_ANGGOTA2]; ?>" />
                       <label>NPT PENULIS 3</label>
                      <input type="text" class="form-control" name="txtnpt3" id="txtnpt3" value="<?php echo $row[NPT_ANGGOTA3]; ?>"/>
                      <p>&nbsp;</p>
                      </div>
                  <div class="tab-pane fade" id="pilltab2">
                          
<div class="alert alert-danger">
  Data Berkas Penelitian <strong>Jika Data Upload TIDAK Diubah Dikosongkan Saja !!!</strong>
</div>
                      <div class="form-group">
                  <label>JUDUL PENELITIAN</label>
                  <textarea name="txtjdlp" class="form-control" rows="3" required="required"><?php echo $row[JDL_PROPOSAL] ?></textarea>
                      </div>
                      <div class="form-group">
                  <label>SKIM</label>
                   <select name="skim" class="form-control">
                      <option value="<?php if($_GET[venus]=="penelitianedit"){ echo($row[KD_SUBKAT]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="penelitianedit"){ echo strtoupper($row[NM_SUBKAT]); }else{echo 'Silahkan Pilih'; }?></option>
                      <?php 
$quer = "select * from m_subkat ";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_SUBKAT']; ?>"><?php echo strtoupper($rot['NM_SUBKAT']); ?></option> <?php } ?>
                      </select>
                                    
          </div>
                     <div class="form-group">
                  <label>Upload File Proposal</label>
                                  
                  <input type="file" name="filezip"><span><?php echo $row[UNGGAH_PROPOSAL]; ?></span>
                   <p class="help-block">Upload proposal lengkap dengan format .zip</p>
                </div>
                       <div class="form-group">
                  <label>Upload Abstrak</label>
                  <input type="file" name="filepdf" ><span><?php echo $row[UNGGAH_ABSTRAK]; ?></span>
                   <p class="help-block">Upload Abstrak dengan format .pdf</p>
                </div>          
                       <div class="form-group">
                  <label>ABSTRAK PENELITIAN</label>
                  <textarea name="abstrak" class="form-control" rows="3"><?php echo $row[ABSTRAK_TEXT]; ?></textarea>
                      </div>
                     
                     
                     
                     
                      </div>

                      <button type="submit" class="btn btn-primary">Simpan</button>
                      
                      <button type="reset" class="btn btn-default">Reset</button>                      
</div>
                      

                  </form>
              </div>
    </div>
    </div>

<?php
  };
?>