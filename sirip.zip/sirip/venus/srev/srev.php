<script>
function hapusdata(urltujuan){
		el=$(this);
		if(confirm("Do you want to delete the data ?."))
		{
            alert("Data Deleted!");
            
            window.location = (urltujuan);
        }
        else{
            alert("Failure to Delete");
        }
}
</script>
<script src="minerva/ajaxlit.js"></script>           
<?php
$aksi="venus/srev/aksi_srev.php";

  // Tampil Agenda
  if($_GET[venus] == "srev"){
    $que = "select * from m_dosen a, m_progdi b, m_rumpun c,m_kepakaran d, m_jafa e, set_reviewer f, m_subkat g where a.KD_JAFA=e.KD_JAFA and a.KD_PROGDI=b.KD_PROGDI and a.KD_RUMPUN=c.KD_RUMPUN and a.KD_PAKAR=d.KD_PAKAR and a.NPT = f.NPT and f.KD_SUBKAT=g.KD_SUBKAT";
	$result=mysqli_query($GLOBALS,$que);
	$jumrows = mysqli_num_rows($result);
?>
    
	<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>Data Reviewer</div>
					<div class="panel-body">
                    <?php 
    //        menampilkan pesan jika ada pesan
            if (($_SESSION['pesan']) && $_SESSION['pesan'] <> '') {
                echo '<div class="alert bg-danger" role="alert">'.$_SESSION['pesan'].'<button type="button" class="close" data-dismiss="alert">×</button></div>';
            }

    //        mengatur session pesan menjadi kosong
            $_SESSION['pesan'] = '';
            ?> 
                    <a href="srevadd.html" class="btn btn-primary">Tambah Data Reviwer</a>
					<table data-toggle="table" data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
        <thead>
            <tr>
                <th data-sortable="true">NPT / NIDN</th>
                <th data-sortable="true">Nama Dosen</th>
                <th data-sortable="true">Skim</th>
                <th data-sortable="true">Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
		<?php
		$iCnt=0;
		if ($jumrows>0) { 
			while ($row = mysqli_fetch_array($result)) {
        $iCnt++;
		?>
        
		  <tr <?php if ($iCnt%2==0) {?>class="odd gradeX" <?php } else {?>class="even gradeC"<?php }?> >
      <td><?php echo strip_tags(strtoupper($row[NPT])); ?> / <?php echo strip_tags(strtoupper($row[NIDN])); ?></td>
		<td><?php echo strip_tags(strtoupper($row[NM_DOSEN])); ?></td>
<td><?php echo strip_tags(strtoupper($row[NM_SUBKAT])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[AKTIF_DOSEN])); ?></td>
            <td><a data-toggle="tooltip" data-placement="top" title="edit" href="<?php echo("srevedit-$row[KD_SETR].html")?>" class="btn btn-sm btn-warning">Edit</a></td>  
		  </tr>
		<?php
			}
		}else{
		?>
		<tr>
			<td colspan="6"><div class="alert bg-danger" role="alert">
					<svg class="glyph stroked cancel"><use xlink:href="#stroked-cancel"></use></svg> Data Tidak Ditemukan !!! <a href="#" class="pull-right"><span class="glyphicon glyphicon-remove"></span></a>
				</div></td>
		</tr>
        
		<?php
		}
		?>
        </tbody>
	</table>
    </div>
    </div>
    </div>
    </div>
	<?php
  }
elseif($_GET[venus]=="srevadd"){
$query = "SELECT max(KD_SETR) as maxKode FROM set_reviewer";
   $hasil = mysqli_query($GLOBALS,$query); 
  $data = mysqli_fetch_array($hasil); 
  $kodeBarang = $data['maxKode']; 
   $noUrut = (int) substr($kodeBarang, 2, 5); 
   $noUrut++; 
   $char="SR";
    $newID = $char . sprintf("%05s", $noUrut);	
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
             <svg class="glyph stroked plus sign"><use xlink:href="#stroked-plus-sign"/></svg> Tambah Data Reviewer
          </div>
              <div class="panel-body">
                  <form name="myForm" id="mainform" action="<?php echo"$aksi?venus=srev&act=input"?>" method="post" enctype="multipart/form-data">
<input class="form-control" type="hidden" name="txtkdlog" id="txtkdlog" value="<?php echo $newID; ?>" readonly="readonly"/>
<label>NPT REVIEWER</label>
<input type="hidden" class="form-control" name="thn" value="<?php echo $kd_thn; ?>" />                      
<input type="text" class="form-control" name="txtnpt1" id="txtnpt1" 
                      onkeyup     ="tampilkan_data(this.value,mainform.txtnpt1.value);"/>
                    
                      <label>NAMA REVIEWER</label>
                      <input type="text" class="form-control" name="txtpnls1" id="txtpnls1" readonly="readonly" />
                      <label>KELOMPOK SKIM</label>
                      <select name="skim" class="form-control">
<?php 
$quer = "select * from m_subkat ";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_SUBKAT']; ?>"><?php echo strtoupper($rot['NM_SUBKAT']); ?></option> <?php } ?>
                      </select>
                      
                      <label>Aktif Reviewer</label>
                      <select name="aktif" class="form-control">
                      <option value="AKTIF">AKTIF</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                      
                      <button type="reset" class="btn btn-default">Reset</button>

                  </form>
              </div>
    </div>  
<?php
}
elseif($_GET[venus]=="srevedit"){
  	$que = "select * from m_dosen a, m_progdi b, m_rumpun c,m_kepakaran d, m_jafa e, set_reviewer f, m_subkat g where a.KD_JAFA=e.KD_JAFA and a.KD_PROGDI=b.KD_PROGDI and a.KD_RUMPUN=c.KD_RUMPUN and a.KD_PAKAR=d.KD_PAKAR and a.NPT = f.NPT and f.KD_SUBKAT=g.KD_SUBKAT and f.KD_SETR='$_GET[id]'";
    $result=mysqli_query($GLOBALS,$que);  
    $row = mysqli_fetch_array($result);
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
               <svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"/></svg>Ubah Data Reviewer
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=srev&act=edit"?>" method="post" enctype="multipart/form-data">
                      <label>NPT</label>
<input class="form-control" type="hidden" name="txtkd" id="txtnpt" value="<?php echo($_GET[id]); ?>"/>                      
<input class="form-control" name="npt" id="txtnpt" value="<?php echo($row[NPT]); ?>"/>
                      <label>Skim</label>
                      <select name="skim" class="form-control">
                      <option value="<?php if($_GET[venus]=="srevedit"){ echo($row[KD_SUBKAT]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="srevedit"){ echo strtoupper($row[NM_SUBKAT]); }else{echo 'Silahkan Pilih'; }?></option>
                      <?php 
$quer = "select * from m_subkat ";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_SUBKAT']; ?>"><?php echo strtoupper($rot['NM_SUBKAT']); ?></option> <?php } ?>
                      </select>

           
                      <label>Status Reviewer</label>
                      <select name="aktif" class="form-control">                                            
                      <option value="<?php if($_GET[venus]=="srevedit"){ echo($row[AKTIF_DOSEN]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="srevedit"){ echo($row[AKTIF_DOSEN]); }else{echo 'Silahkan Pilih'; }?></option>
                      <option value="AKTIF">AKTIF</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-default">Ubah</button>
                    
                      <button type="reset" class="btn btn-primary">Reset</button>
                      </form>
              </div>
  </div>    
<?php
}
?>