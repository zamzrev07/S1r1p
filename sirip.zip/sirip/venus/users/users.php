<script>
function hapusdata(urltujuan){
		el=$(this);
		if(confirm("Do you want to delete the data ?."))
		{
            alert("Data Deleted!");
            
            window.location = (urltujuan);
        }
        else{
            alert("Failure to Delete");
        }
}
</script>
            
<?php
$aksi="venus/users/aksi_users.php";

  // Tampil Agenda
  if($_GET[venus] == "users"){
    $que = "select * from m_login";
	$result=mysqli_query($GLOBALS,$que);
	$jumrows = mysqli_num_rows($result);
?>
    
	<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>Users</div>
					<div class="panel-body">
                    <a href="users-add.html" class="btn btn-primary">TAMBAH USER LOGIN</a>
					<table data-toggle="table" data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
        <thead>
            <tr>
                <th data-sortable="true">KD_LOG</th>
                <th data-sortable="true">USERNAME</th>
                <th>HAK AKSES</th>
                <th data-sortable="true">AKTIF</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
		<?php
		$iCnt=0;
		if ($jumrows>0) { 
			while ($row = mysqli_fetch_array($result)) {
        $iCnt++;
		?>
        
		  <tr <?php if ($iCnt%2==0) {?>class="odd gradeX" <?php } else {?>class="even gradeC"<?php }?> >
			<td><?php echo strip_tags(strtoupper($row[0])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[1])); ?></td>
            <td><?php 
if($row[3]=='1'){$ku = "PENGELOLAH";} elseif($row[3]=='2'){$ku = "DOSEN";} if($row[3]=='3'){$ku = "MAHASISWA";} if($row[3]=='4'){$ku = "KA LPPM";}
elseif($row[3]=='5'){$ku = "REVIEWER";} elseif($row[3]=='6'){$ku = "DPL";}
            echo strip_tags($ku); ?></td>
            <td><?php echo strip_tags($row[4]); ?></td>
            <td><a data-toggle="tooltip" data-placement="top" title="edit" href="<?php echo("users-edit-$row[5].html")?>" class="btn btn-sm btn-warning">Edit</a></td>  
		  </tr>
		<?php
			}
		}else{
		?>
		<tr>
			<td colspan="6">Data tidak di temukan</td>
		</tr>
		<?php
		}
		?>
        </tbody>
	</table>
    </div>
    </div>
    </div>
    </div>
	<?php
  }
elseif($_GET[venus]=="usersadd"){

 $query = "SELECT max(kd_log) as maxKode FROM m_login";
   $hasil = mysqli_query($GLOBALS,$query); 
  $data = mysqli_fetch_array($hasil); 
  $kodeBarang = $data['maxKode']; 
   $noUrut = (int) substr($kodeBarang, 1, 5); 
   $noUrut++; 
   $char="U";
    $newID = $char . sprintf("%05s", $noUrut);	
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
             <svg class="glyph stroked plus sign"><use xlink:href="#stroked-plus-sign"/></svg>   TAMBAH USER LOGIN
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=users&act=input"?>" method="post" enctype="multipart/form-data">
                   <label>KODE_LOG</label>
                      <input class="form-control" name="txtkdlog" id="txtkdlog" value="<?php echo $newID; ?>" readonly="readonly"/>
                      <label>USERNAME</label>
                      <input class="form-control" name="txtusername" id="txtusername" />
                      <label>PASSWORD</label>
                      <div class="form-group has-warning">
                      <input class="form-control" name="txtpassword" id="txtpassword" placeholder="pass123"/></div>
                      <label>Hak Akses User</label>
                      <select name="hakakses" class="form-control">

                      <option value="1">Pengelolah</option>
                      <option value="2">Dosen</option>
                      <option value="3">Mahasiswa</option>
                      <option value="4">Ka LPPM</option>
                      <option value="5">Reviewer</option>
                      <option value="6">DPL</option>
                      </select>
                      <label>Status User</label>
                      <select name="aktifuser" class="form-control">
                      <option value="YA">YA</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>

                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                      
                      <button type="reset" class="btn btn-default">Reset</button>

                  </form>
              </div>
    </div>  
<?php
}
elseif($_GET[venus]=="usersedit"){
  	$que = "select * from m_login where ID_SESSION='$_GET[id]'";
    $result=mysqli_query($GLOBALS,$que);  
    $row = mysqli_fetch_array($result);
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
               <svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"/></svg>EDIT USER
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=users&act=edit"?>" method="post" enctype="multipart/form-data">
                      <label>KODE LOG</label>
                      <input hidden="" name="sid" id="sid" value="<?php echo($_GET[id]); ?>" />
                      <input class="form-control" name="txtkdlog2" id="txtusername" value="<?php echo($row[0]);?>" readonly="readonly" />
                      <label>USERNAME</label>
                      <input class="form-control" name="txtuname" id="txtuname"  value="<?php echo strip_tags($row[1]); ?>" />
                      <label>PASSWORD</label>
                      <input class="form-control" name="txtpass" id="txtpass" type="password" />
                      <label>Hak Akses User</label>
                      <select name="hakakses" class="form-control">
                      <option value="<?php 
if($row[STA_LOG]=='1'){$ku = "PENGELOLAH";} elseif($row[STA_LOG]=='2'){$ku = "DOSEN";} if($row[STA_LOG]=='3'){$ku = "MAHASISWA";} 
if($row[STA_LOG]=='4'){$ku = "KA LPPM";}
elseif($row[STA_LOG]=='5'){$ku = "REVIEWER";} elseif($row[STA_LOG]=='6'){$ku = "DPL";}
                      if($_GET[venus]=="usersedit"){ echo($row[STA_LOG]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="usersedit"){ echo $ku; }else{echo 'Silahkan Pilih'; }?></option>

                      <option value="1">Pengelolah</option>
                      <option value="2">Dosen</option>
                      <option value="3">Mahasiswa</option>
                      <option value="4">Ka LPPM</option>
                      <option value="5">Reviewer</option>
                      <option value="6">DPL</option>
                      </select>
                      <label>Status User</label>
                      <select name="aktifuser" class="form-control">
                      <option value="<?php if($_GET[venus]=="usersedit"){ echo($row[AKTIF_LOG]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="usersedit"){ echo($row[AKTIF_LOG]); }else{echo 'Silahkan Pilih'; }?></option>
                      <option value="YA">YA</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>
                                            <p>&nbsp;</p>
                      <button type="submit" class="btn btn-default">Ubah</button>
                    
                      <button type="reset" class="btn btn-primary">Reset</button>
                      </form>
              </div>
  </div>    
<?php
}
?>