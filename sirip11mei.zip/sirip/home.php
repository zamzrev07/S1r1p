<?php   session_start();
  error_reporting(0);
  ob_start();
  include "config/koneksi.php";
  $stat = $_SESSION['STA_LOG'];
  $nptku = $_SESSION['USER_LOG'];

$dos 	= "select * from m_dosen a, m_progdi b where a.KD_PROGDI=b.KD_PROGDI and a.NPT = '$nptku' ";
$resdos = mysqli_query($GLOBALS,$dos);
$rod 	= mysqli_fetch_array($resdos);

$kdbidang = $rod['KD_BIDANG'];

function buatrp($angka)
{
 $jadi = "Rp " . number_format($angka,2,".",".");
return $jadi;
}

  if(!$_SESSION['USER_LOG']){
  	 header('location:index.php');
  }

else { echo $numa;
if($numa == '0'){
  $note_ta = "TAHUN AJARAN BELUM DIAKTIFKAN, SILAHKAN AKTIFKAN TAHUN AJARAN SALAH SATU TERLEBIH DAHULU DI MENU SUB MASTER DATA >> TAHUN AJARAN / AKTIVASI"; 
    	}
    else {
$note_ta = "<center>Saat ini Tahun Ajaran $ket_thn </center>";
if($stat == '1'){ 
$stalog = "Anda Login Sebagai Administrator / Pengelolah";
} 
elseif($stat == '2'){ 
$stalog = "Anda Login Sebagai Dosen / Pengusul";
} 
elseif($stat == '3'){ 
$stalog = "Anda Login Sebagai Reviewer / Penilai";
} 
elseif($stat == '4'){ 
$stalog = "Anda Login Sebagai Ka LPPM";
}
elseif($stat == '5'){ 
$stalog = "Anda Login Sebagai Ka. LPPM";
}  

  	}

  ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" href="img/aa.png"/>
<title>SIRISET :: Back Office ::</title>

<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/datepicker3.css" rel="stylesheet">
<link href="css/bootstrap-table.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">
<link rel="shortcut icon" href="img/logoupn.png" />
<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
<script type="application/javascript">
  function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if ((charCode < 65) || (charCode == 32))
            return false;         
         return true;
      }
</script>
<script type="application/javascript">
  function isNumberKeyTrue(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 65)
            return false;         
         return true;
      }

function formatCurrency(num) {
num = num.toString().replace(/\$|\,/g,'');
if(isNaN(num))
num = "0";
sign = (num == (num = Math.abs(num)));
num = Math.floor(num*100+0.50000000001);
cents = num%100;
num = Math.floor(num/100).toString();
if(cents<10)
cents = "0" + cents;
for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
num = num.substring(0,num.length-(4*i+3))+'.'+
num.substring(num.length-(4*i+3));
return (((sign)?'':'-') + 'Rp' + num + ',' + cents);
}
</script>

</head>

<body>
	<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="#"><span>Sistem Informasi Riset & Penelitian LPPM UPN "VETERAN" Jawa Timur</span> - SIRIP</a>
				<ul class="user-menu">
					<li class="dropdown pull-right">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg> <?php echo($_SESSION['USER_LOG']);  ?> <span class="caret"></span></a>
						<ul class="dropdown-menu" role="menu">
							<li><a href="#"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg> Profile</a></li>
							<li><a href="#"><svg class="glyph stroked gear"><use xlink:href="#stroked-gear"></use></svg> Settings</a></li>
							
							<li><a href="<?php if($stat == '1'){ ?>logout_check.php <?php } ?><?php if($stat == '2'){ ?>dosen/logout_check.php <?php } ?> <?php if($stat == '3'){ ?>reviewer/logout_check.php <?php } ?>">
							<svg class="glyph stroked cancel"><use xlink:href="#stroked-cancel"></use></svg> Logout</a></li>
						</ul>
					</li>
				</ul>
			</div>
							
		</div><!-- /.container-fluid -->
	</nav>
		
	<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<form role="search">
			<div class="form-group">
				<input type="text" class="form-control" placeholder="Search">
			</div>
		</form>
<?php 
include "menu.php"; 
echo "<input type=hidden name=kd_thn value=$kd_thn> <input type=hidden name=nm_thn value=$nm_thn> <input type=hidden name=ket_thn value=$ket_thn>";
		?>

	</div><!--/.sidebar-->
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use>
				<?php echo "$note_ta - $stalog"; ?></svg></a></li>
			</ol>
		</div><!--/.row-->
		<?php include_once 'include_log/content.php'; ?>
		
		
		<div class="row"><!--/.col-->
			
			<!--/.col-->
		</div><!--/.row-->
	</div>	<!--/.main-->
<!--JavaScript Mulai-->
	<?php include_once 'include_log/jscontrol.php'; ?>
</body>

</html>

<?php } ?>
