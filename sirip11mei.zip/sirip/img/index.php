<img src="sirip/img/websiteservices.jpg">
<meta http-equiv="refresh" content="1;url=http://sirip.lppmupnjatim.ac.id/web">