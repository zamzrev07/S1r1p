<script type="text/javascript">

  /* Disable Right Click dengan fungsi tambahan. */
  document.oncontextmenu = new Function("Fungsi1();return(false)");
  function Fungsi1()
  {
   alert("disabled");
  }
 </script>
 <?php      
if ($_GET['venus']=='home'){
?> 
 <div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Dashboard</h1>
			</div>
		</div><!--/.row-->
<?php include_once 'venus/dashboard.php'; ?>        
<?php
}elseif ($_GET['venus']=='users'){    
    include "venus/users/users.php";
}elseif ($_GET['venus']=='usersadd'){    
    include "venus/users/users.php";    
}elseif ($_GET['venus']=='usersedit'){    
    include "venus/users/users.php";

	//fakultas
}elseif ($_GET['venus']=='fakultas'){    
    include "venus/fakultas/fakultas.php";
}elseif ($_GET['venus']=='fakadd'){    
    include "venus/fakultas/fakultas.php";    
}elseif ($_GET['venus']=='fakedit'){    
    include "venus/fakultas/fakultas.php";

    	//progdi
}elseif ($_GET['venus']=='progdi'){    
    include "venus/progdi/progdi.php";
}elseif ($_GET['venus']=='progdiadd'){    
    include "venus/progdi/progdi.php";    
}elseif ($_GET['venus']=='progdiedit'){    
    include "venus/progdi/progdi.php";

    //kelompok
}elseif ($_GET['venus']=='kel'){    
    include "venus/kel/kel.php";
}elseif ($_GET['venus']=='keladd'){    
    include "venus/kel/kel.php";    
}elseif ($_GET['venus']=='keledit'){    
    include "venus/kel/kel.php";

        //pakar
}elseif ($_GET['venus']=='pakar'){    
    include "venus/pakar/pakar.php";
}elseif ($_GET['venus']=='pakaradd'){    
    include "venus/pakar/pakar.php";    
}elseif ($_GET['venus']=='pakaredit'){    
    include "venus/pakar/pakar.php";

        //bidang
}elseif ($_GET['venus']=='bidang'){    
    include "venus/bidang/bidang.php";
}elseif ($_GET['venus']=='bidangadd'){    
    include "venus/bidang/bidang.php";    
}elseif ($_GET['venus']=='bidangedit'){    
    include "venus/bidang/bidang.php";

            //rumpun ilmu
}elseif ($_GET['venus']=='rumpun'){    
    include "venus/rumpun/rumpun.php";
}elseif ($_GET['venus']=='rumpunadd'){    
    include "venus/rumpun/rumpun.php";    
}elseif ($_GET['venus']=='rumpunedit'){    
    include "venus/rumpun/rumpun.php";

            //tahun ajaran
}elseif ($_GET['venus']=='ta'){    
    include "venus/ta/ta.php";
}elseif ($_GET['venus']=='taadd'){    
    include "venus/ta/ta.php";    
}elseif ($_GET['venus']=='taedit'){    
    include "venus/ta/ta.php";

            //propinsi
}elseif ($_GET['venus']=='prop'){    
    include "venus/prop/prop.php";
}elseif ($_GET['venus']=='propadd'){    
    include "venus/prop/prop.php";    
}elseif ($_GET['venus']=='propedit'){    
    include "venus/prop/prop.php";

            //kab
}elseif ($_GET['venus']=='kab'){    
    include "venus/kab/kab.php";
}elseif ($_GET['venus']=='kabadd'){    
    include "venus/kab/kab.php";    
}elseif ($_GET['venus']=='kabedit'){    
    include "venus/kab/kab.php";

}elseif ($_GET['venus']=='kec'){    
    include "venus/kec/kec.php";
}elseif ($_GET['venus']=='kecadd'){    
    include "venus/kec/kec.php";    
}elseif ($_GET['venus']=='kecedit'){    
    include "venus/kec/kec.php";    

//kategori
}elseif ($_GET['venus']=='kat'){    
    include "venus/kat/kat.php";
}elseif ($_GET['venus']=='katadd'){    
    include "venus/kat/kat.php";    
}elseif ($_GET['venus']=='katedit'){    
    include "venus/kat/kat.php";

//sub kategori
}elseif ($_GET['venus']=='skat'){    
    include "venus/skat/skat.php";
}elseif ($_GET['venus']=='skatadd'){    
    include "venus/skat/skat.php";    
}elseif ($_GET['venus']=='skatedit'){    
    include "venus/skat/skat.php";


	//mahasiswa
}elseif ($_GET['venus']=='mhs'){
	include "venus/mahasiswa_un/mahasiswa.php";
}elseif ($_GET['venus']=='mhsadd'){
	include "venus/mahasiswa_un/mahasiswa.php";
}elseif ($_GET['venus']=='mhsedit'){
	include "venus/mahasiswa_un/mahasiswa.php";
	
		//dosen
}elseif ($_GET['venus']=='dosen'){
	include "venus/dosen_kl/dosen.php";
}elseif ($_GET['venus']=='dosenadd'){
	include "venus/dosen_kl/dosen.php";
}elseif ($_GET['venus']=='dosenedit'){
	include "venus/dosen_kl/dosen.php";
}elseif ($_GET['venus']=='dosenlog'){
    include "venus/dosen_kl/dosen.php";
}elseif ($_GET['venus']=='laboran'){
    include "venus/dosen_kl/laboran.php";


//jafa
}elseif ($_GET['venus']=='jafa'){
	include "venus/jafa/jafa.php";
}elseif ($_GET['venus']=='jafaadd'){
	include "venus/jafa/jafa.php";
}elseif ($_GET['venus']=='jafaedit'){
	include "venus/jafa/jafa.php";
	
}elseif ($_GET['venus']=='kriteria'){
    include "venus/bidang/kriteria.php";
}elseif ($_GET['venus']=='kriteriaadd'){
    include "venus/bidang/kriteria.php";    


//modul prop kkn
}elseif ($_GET['venus']=='dftrkkn'){
	include "venus/proses_kkn/proses_kkn.php";	
}elseif ($_GET['venus']=='kknadd'){
	include "venus/proses_kkn/proses_kkn.php";	
	
//modul prop penelitian
}elseif ($_GET['venus']=='penelitian'){
	include "venus/proses_dosen/penelitian.php";	
}elseif ($_GET['venus']=='penelitianadd'){
	include "venus/proses_dosen/penelitian.php";
}elseif ($_GET['venus']=='penelitianedit'){
	include "venus/proses_dosen/penelitian.php";			

//Pemilihan Reviewer
}elseif ($_GET['venus']=='srev'){ 
	include "venus/srev/srev.php";
}elseif ($_GET['venus']=='srevadd'){
	include "venus/srev/srev.php";
}elseif ($_GET['venus']=='srevedit'){
	include "venus/srev/srev.php";
	
//ploting penelitian	
}elseif ($_GET['venus']=='prev'){ 
	include "venus/ploting_review/prev.php";
}elseif ($_GET['venus']=='plotrev'){
	include "venus/ploting_review/prev.php";
}elseif ($_GET['venus']=='nilaiplot'){
	include "venus/ploting_review/prev.php";
}elseif ($_GET['venus']=='publishx'){
    include "venus/ploting_review/prev.php";

/* MENU DOSEN */
//Ubah Profile
}elseif ($_GET['venus']=='profil'){ 
    include "venus/profil/profil.php";
}elseif ($_GET['venus']=='profiladd'){
    include "venus/profil/profil.php";
}elseif ($_GET['venus']=='profiledit'){
    include "venus/profil/profil.php";
/* END MENU DOSEN */

/* MENU REVIEWER */
//Ubah List Proposal yang di Nilai
}elseif ($_GET['venus']=='listr'){ 
    include "venus/listr/listr.php";
}elseif ($_GET['venus']=='listradd'){
    include "venus/listr/listr.php";
}elseif ($_GET['venus']=='listredit'){
    include "venus/listr/listr.php";

//Menu menampilkan proposal berdasarkan reviewer
}elseif ($_GET['venus']=='propr'){ 
    include "venus/propr/propr.php";
}elseif ($_GET['venus']=='nilai'){
    include "venus/propr/nilai.php";
}elseif ($_GET['venus']=='propredit'){
    include "venus/propr/propr.php";
/* END MENU REVIEWER */	
  }else{
    echo '<div class="alert bg-danger" role="alert">
					<svg class="glyph stroked cancel"><use xlink:href="#stroked-cancel"></use></svg> Content Not Found !!! <a href="#" class="pull-right"><span class="glyphicon glyphicon-remove"></span></a>
				</div>';
}
?>