<script type="text/javascript">
      $(document).ready(function() {
        // ketika input usia di isi, eksekusi bagian ini.
	      $("#txtnpt1").keypress(function (data)
		 
	      { 
	         // kalau data bukan berupa angka, tampilkan pesan error
	         if(data.which!=8 && data.which!=0 && (data.which<48 || data.which>57))
	         {
		          $("#pesan").html("Isikan Angka").show().fadeOut("slow"); 
	            return false;
           }	
	      });
      });
    </script>

    <script type="text/javascript">
      $(document).ready(function() {
        // ketika input usia di isi, eksekusi bagian ini.
	      $("#txtnpt2").keypress(function (data)
		 
	      { 
	         // kalau data bukan berupa angka, tampilkan pesan error
	         if(data.which!=8 && data.which!=0 && (data.which<48 || data.which>57))
	         {
		          $("#pesan1").html("Isikan Angka").show().fadeOut("slow"); 
	            return false;
           }	
	      });
      });
    </script>

    <script type="text/javascript">
      $(document).ready(function() {
        // ketika input usia di isi, eksekusi bagian ini.
	      $("#txtnpt3").keypress(function (data)
		 
	      { 
	         // kalau data bukan berupa angka, tampilkan pesan error
	         if(data.which!=8 && data.which!=0 && (data.which<48 || data.which>57))
	         {
		          $("#pesan2").html("Isikan Angka").show().fadeOut("slow"); 
	            return false;
           }	
	      });
      });
    </script>