

<meta http-equiv="refresh" content="3;url=http://sirip.lppmupnjatim.ac.id">