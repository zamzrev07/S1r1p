<?php session_start();
include  "../config/koneksi.php";
include  "../include_log/phpmailer/PHPMailerAutoload.php";
date_default_timezone_set('Etc/UTC');

if(isset($_POST['kirim'])){

$npt 	= $_POST['name'];
$email 	= $_POST['uname'];

$cekk = "select * from m_dosen where NPT='$npt' OR NIDN = '$npt'";
$sqlc = mysqli_query($GLOBALS, $cekk);
$numc = mysqli_num_rows($sqlc);

if($numc > 0){

$cekk2 = "select * from m_login where USER_LOG='$npt'";
$sqlc2 = mysqli_query($GLOBALS, $cekk2);
$numc2 = mysqli_num_rows($sqlc2);
$rw2 = mysqli_fetch_array($sqlc2);
$kd = $rw2['KD_LOG'];
$pass = "ds";
$gab = $pass.$npt;
$passr = md5($gab);

if($numc2 > 0){
$sett = "UPDATE m_login set PASS_LOG = '$passr' where KD_LOG='$kd'";
$proc = mysqli_query($GLOBALS, $sett);
}

elseif($numc2 == 0){
$query = "SELECT max(KD_LOG) as maxKode FROM m_login";
 $hasil = mysqli_query($GLOBALS,$query); 
 $data = mysqli_fetch_array($hasil); 
 $kodeBarang = $data['maxKode']; 
   $noUrut = (int) substr($kodeBarang, 1, 5); 
   $noUrut++; 
   $char="U";
   $newID = $char . sprintf("%05s", $noUrut);

$sett2 = "INSERT INTO m_login
  (KD_LOG,USER_LOG,PASS_LOG,ID_SESSION,STA_LOG,AKTIF_LOG) 
  VALUES 
 ('$newID','$npt','$passr','$sid_baru','2','YA')"; 

$proc2 = mysqli_query($GLOBALS, $sett2);
}
/*
$to = '$email';  
$subject = 'Konfirmasi Email dan Password SIRIP $npt';  
$message = '  
Berikut Username dan Password Anda ($npt)<br>
<b>
Username : $npt <br>
Password : $pass
</b><br>
Silahkan Klik Link Berikut untuk Login ke SIRIP sebagai Pengusul Dosen 
<a href="http://sirip.lppmupnjatim.ac.id/dosen" target="_blank">Login Dosen</a>
';  
//untuk mengirim html email, header Content-type harus diset  
$headers = 'MIME-Version: 1.0' . "\r\n";  
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";  
  
// Additional header  
$headers .= 'From: admin@lppmupnjatim.ac.id' . "\r\n";  
$headers .= 'Cc: email_cc' . "\r\n";  
$headers .= 'Bcc: email_bcc' . "\r\n";  
  
mail($to, $subject, $message, $headers);  

	$psn = "Username dan Password Berhasil dikirim ke Email $email (Cek Inbox dan Spam)";
	echo '<div class="alert bg-danger" role="alert">'.$psn.'<button type="button" class="close" data-dismiss="alert">×</button></div>'; */

//Create a new PHPMailer instance
$mail = new PHPMailer;

//Tell PHPMailer to use SMTP
$mail->isSMTP();

//Enable SMTP debugging
// 0 = off (for production use)
// 1 = client messages
// 2 = client and server messages
$mail->SMTPDebug = 2;

//Ask for HTML-friendly debug output
$mail->Debugoutput = 'html';

//Set the hostname of the mail server
$mail->Host = 'smtp.gmail.com';
// use
// $mail->Host = gethostbyname('smtp.gmail.com');
// if your network does not support SMTP over IPv6

//Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
$mail->Port = 587;

//Set the encryption system to use - ssl (deprecated) or tls
$mail->SMTPSecure = 'tls';

//Whether to use SMTP authentication
$mail->SMTPAuth = true;

//Username to use for SMTP authentication - use full email address for gmail
$mail->Username = "siripupnjatim@gmail.com";

//Password to use for SMTP authentication
$mail->Password = "s1r1pupnjatim";

//Set who the message is to be sent from
$mail->setFrom('admin@lppmupnjatim.ac.id', 'LPPM UPN V JATIM');

//Set an alternative reply-to address
//$mail->addReplyTo('replyto@example.com', 'First Last');
//
//Set who the message is to be sent to
$mail->addAddress($email, $npt);
//echo $npt; exit;
//Set the subject line
$mail->Subject = 'Konfirmasi Email dan Password SIRIP $npt';

//Read an HTML message body from an external file, convert referenced images to embedded,
//convert HTML into a basic plain-text alternative body
//$mail->msgHTML(file_get_contents('contents.html'), dirname(__FILE__));

//Replace the plain text body with one created manually
//$mail->Body = 'This is a plain-text message body From HEstia Server ';
$mail->msgHTML('Berikut Username dan Password Anda ($npt)<br>
<b>
Username : $npt <br>
Password : $pass
</b><br>
Silahkan Klik Link Berikut untuk Login ke SIRIP sebagai Pengusul Dosen 
<a href="http://sirip.lppmupnjatim.ac.id/dosen" target="_blank">Login Dosen</a>');

//Attach an image file
//$mail->addAttachment('images/phpmailer_mini.png');

//send the message, check for errors
if (!$mail->send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
    echo "Message sent!";
}


}
else { 

	$psn = "NPT atau NIDN Tidak Terdaftar dalam SIRIP <br> Silahkan Hubungi Pihak LPPM Terima Kasih";
	echo '<div class="alert bg-danger" role="alert">'.$psn.'<button type="button" class="close" data-dismiss="alert">×</button></div>';
	//header('location:?daftar');
}
//echo $message; exit;
}

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>LOGIN Ka LPPM :: Sistem Informasi Penelitian & Pengabdian Masyarakat ::</title>

<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/datepicker3.css" rel="stylesheet">
<link href="../css/styles.css" rel="stylesheet">
<link rel="shortcut icon" href="../img/logoupn.png" />	

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->
		<link href="../css/stylel.css" rel='stylesheet' type='text/css' />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
		<!--webfonts-->
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text.css'/>
		<!--//webfonts-->
</head>
<script language="javascript">
function validasi(form){
  if (form.uname.value == ""){
    alert("Anda belum mengisikan Username.");
    form.uname.focus();
    return (false);
  }
     
  if (form.upass.value == ""){
    alert("Anda belum mengisikan Password.");
    form.password.focus();
    return (false);
  }
  return (true);
}
function cekdata(nama,proses,urltujuan){
var prosesdata = urltujuan+"?cmd="+proses;
		$.ajax({
			type: 'POST',
			url: prosesdata,
			data: "id=" + nama,
			success: function(data) {
			$("#txtbagian").html(data);			
			}
		})
		return false;
};
</script>



<div class="main">
<?php  
if(isset($_GET['daftar'])){ 
	echo $psn;
	?>
<form action="" method="post"><h1><b><center>
Isikan NPT & Email terdaftar untuk mendapatkan Konfirmasi Username dan Password SIRIP</center></b></h1><br>
   <div id='name' class='outerDiv'>
	<label for="name">NPT / NIDN</label>
	<input type="text" name="name" placeholder="NPT / NIDN terdaftar" required  />
   </div>
   <p>
	<label for="email">EMAIL</label>
   	<input type="text" name="uname" placeholder="EMAIL terdaftar" required/>
	 </p>
   
   <div id='submit' class='outerDiv'>
        <input type="submit" name="kirim" value="D a f t a r" /> <a href=".">Kembali</a>
   </div><br>
 </form>
<?php exit;
} 
?>
		<form action="../log_ka.php" method="POST">
    		<h1><img src="../img/logoupn.png" width="65"><br>LOGIN Ka LPPM<br>Sistem Informasi <br>Riset dan Pengabdian Masyarakat <br>LPPM UPN "Veteran" Jatim<br>SIRIP</h1>
  			<div class="inset">
	  			<p>
	    		 <label for="email">USERNAME</label>
   	 			<input type="text" name="uname" placeholder="USERNAME / NPT / NIDN" required/>
				</p>
  				<p>
				    <label for="password">PASSWORD</label>
				    <input type="password" name="upass" placeholder="xxxxxx" required/>
  				</p>
				  <p>
				   <!-- <span><a href="?daftar">Pendaftaran / Forgot Password ?</a> </span> -->
				  </p>
 			 </div>
 	 
			  <p class="p-container">
			    <span>
			    <input type="submit" name="" value="Login"></span>
			  </p>
		</form>
	</div>  
			<!-----start-copyright--
   					<div class="copy-right">
					<p><b>LPPM UPN "Veteran" Jawa Timur</b></p> 
					</div>-->
				<!-----//end-copyright---->
	
		

	<script src="../js/jquery-1.11.1.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	<script src="../js/chart.min.js"></script>
	<script src="../js/chart-data.js"></script>
	<script src="../js/easypiechart.js"></script>
	<script src="../js/easypiechart-data.js"></script>
	<script src="../js/bootstrap-datepicker.js"></script>
	<script>
		!function ($) {
			$(document).on("click","ul.nav li.parent > a > span.icon", function(){		  
				$(this).find('em:first').toggleClass("glyphicon-minus");	  
			}); 
			$(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
