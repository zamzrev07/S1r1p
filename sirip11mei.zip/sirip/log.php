<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>LOGIN :: Sistem Informasi Penelitian & Pengabdian Masyarakat ::</title>

<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/datepicker3.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">
<link rel="shortcut icon" href="img/logoupn.png" />	

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->
		<link href="css/stylel.css" rel='stylesheet' type='text/css' />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
		<!--webfonts-->
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text.css'/>
		<!--//webfonts-->
</head>
<script language="javascript">
function validasi(form){
  if (form.uname.value == ""){
    alert("Anda belum mengisikan Username.");
    form.uname.focus();
    return (false);
  }
     
  if (form.upass.value == ""){
    alert("Anda belum mengisikan Password.");
    form.password.focus();
    return (false);
  }
  return (true);
}
function cekdata(nama,proses,urltujuan){
var prosesdata = urltujuan+"?cmd="+proses;
		$.ajax({
			type: 'POST',
			url: prosesdata,
			data: "id=" + nama,
			success: function(data) {
			$("#txtbagian").html(data);			
			}
		})
		return false;
};
</script>

<div class="main">

		<form action="cek_login.php" method="POST">
    		<h1><img src="img/logoupn.png" width="85"><br>LOGIN <br><br>Sistem Informasi <br>Riset dan Pengabdian Masyarakat <br>LPPM UPN "Veteran" Jatim<br>SIRIP</h1>
  			<div class="inset">
	  			<p>
	    		 <label for="email">USERNAME</label>
   	 			<input type="text" name="uname" placeholder="USERNAME / NPT / NIDN" required/>
				</p>
  				<p>
				    <label for="password">PASSWORD</label>
				    <input type="password" name="upass" placeholder="xxxxxx" required/>
  				</p>
				  <p>
				    <input type="checkbox" name="remember" id="remember">
				    <label for="remember">Remember me </label>
				  </p>
 			 </div>
 	 
			  <p class="p-container">
			    <span><a href="#">Forgot password ?</a> <br>
			    <a href="#">Sign UP </a></span>
			    <input type="submit" name="" value="Login">
			  </p>
		</form>
	</div>  
			<!-----start-copyright--
   					<div class="copy-right">
					<p><b>LPPM UPN "Veteran" Jawa Timur</b></p> 
					</div>-->
				<!-----//end-copyright---->
	
		

	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script>
		!function ($) {
			$(document).on("click","ul.nav li.parent > a > span.icon", function(){		  
				$(this).find('em:first').toggleClass("glyphicon-minus");	  
			}); 
			$(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
