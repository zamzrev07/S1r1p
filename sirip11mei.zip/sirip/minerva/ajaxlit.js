
// JavaScript Document  
var xmlHttp;  
//-------------membuat objek xmlHttpRequest  
function GetXmlHttpObject()  
{  
try  
    {  
    // ngecek buat browser firefox, opera 8.0+, safari  
    xmlHttp=new XMLHttpRequest();  
    }  
    catch (e)  
        {  
        // browser Internet Explorer  
        try  
            {  
            // IE 6.0+  
            xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");  
            }  
            catch (e)  
                {  
                // IE 5.0  
                xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");  
                }  
        }             
return xmlHttp;  
}  
  
function tampilkan_data(kode, jumlah)  
{  
    xmlHttp=GetXmlHttpObject()  
    if (xmlHttp==null)  
    {  
        alert ("Browser tidak support HTTP Request");  
    }  
    var url="venus/proses_dosen/cek_datap.php?kode="+kode  
    url = url+"&jumlah="+jumlah  
    xmlHttp.onreadystatechange=function()  
    {  
        if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")  
        {  
                xmldoc = xmlHttp.responseXML;
				    
                document.myForm.txtpnls1.value=xmldoc.getElementsByTagName("penulis1")[0].childNodes[0].nodeValue;  
        }  
    }  
    xmlHttp.open("GET",url,true);  
    xmlHttp.send(null);  
}  
