<script>
function hapusdata(urltujuan){
		el=$(this);
		if(confirm("Do you want to delete the data ?."))
		{
            alert("Data Deleted!");
            
            window.location = (urltujuan);
        }
        else{
            alert("Failure to Delete");
        }
}
</script>
            
<?php
$aksi="venus/bidang/aksi_kriteria.php";

  // Tampil Agenda
  if($_GET[venus] == "kriteria"){
    $que = "select * from mn_kriteria ";
	$result=mysqli_query($GLOBALS,$que);
	$jumrows = mysqli_num_rows($result);
?>
    
	<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>Data Master Kriteria Penilaian</div>
					<div class="panel-body">
                    <a href="kriteriaadd.html" class="btn btn-primary">+ Master Kriteria Penilaian</a>
					<table data-toggle="table" data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
        <thead>
            <tr>
                <th data-sortable="true">Kode Kriteria</th>
                <th data-sortable="true">Skim</th>
                <th data-sortable="true">Kriteria</th>
                <th data-sortable="true">Bobot</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
		<?php
		$iCnt=0;
		if ($jumrows>0) { 
			while ($row = mysqli_fetch_array($result)) {
        $iCnt++;
      $ex = explode(';',$row[NM_KRITERIA]);
      $exc = count($ex);
      
    ?>
        
		  <tr <?php if ($iCnt%2==0) {?>class="odd gradeX" <?php } else {?>class="even gradeC"<?php }?> >
      <td><?php echo strip_tags(strtoupper($row[KD_KRITERIA])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[SKIM_KRITERIA])); ?></td>
            <td><b><?php echo strip_tags(strtoupper($row[SUB_KRITERIA]));?></b><br><?php
for($e=0;$e < $exc;$e++){
        echo "$ex[$e]<br>";
        //echo "beda bung<br>aa<br>--";
      }
            //echo strip_tags(strtoupper($row[NM_KRITERIA])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[BOBOT_KRITERIA])); ?> %</td>
            <td><a data-toggle="tooltip" data-placement="top" title="edit" href="<?php echo("bidangedit-$row[KD_BIDANG].html")?>" class="btn btn-sm btn-warning">Edit</a></td>  
		  </tr>
		<?php
			}
		}else{
		?>
		<tr>
			<td colspan="6">Data tidak di temukan</td>
		</tr>
		<?php
		}
		?>
        </tbody>
	</table>
    </div>
    </div>
    </div>
    </div>
	<?php
  }
elseif($_GET[venus]=="kriteriaadd"){

 $query = "SELECT max(KD_BIDANG) as maxKode FROM m_bidang";
   $hasil = mysqli_query($GLOBALS,$query); 
  $data = mysqli_fetch_array($hasil); 
  $kodeBarang = $data['maxKode']; 
   $noUrut = (int) substr($kodeBarang, 2, 5); 
   $noUrut++; 
   $char="BD";
    $newID = $char . sprintf("%05s", $noUrut);	
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
             <svg class="glyph stroked plus sign"><use xlink:href="#stroked-plus-sign"/></svg> Tambah Data Master BIDANG
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=bidang&act=input"?>" method="post" enctype="multipart/form-data">
                   <label>Kode BIDANG</label>
                      <input class="form-control" name="txtkdlog" id="txtkdlog" value="<?php echo $newID; ?>" readonly="readonly"/>
                      <label>Nama BIDANG</label>
                      <input class="form-control" name="txtusername" id="txtusername" />
                      <label>Keterangan BIDANG</label>
                      <input class="form-control" name="txtket" id="txtket" /><!--
                      <label>Status Progdi</label>
                      <select name="aktifprogdi" class="form-control">
                      <option value="YA">YA</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>-->
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                      
                      <button type="reset" class="btn btn-default">Reset</button>

                  </form>
              </div>
    </div>  
<?php
}
elseif($_GET[venus]=="bidangedit"){
  	$que = "select * from m_bidang where KD_BIDANG='$_GET[id]'";
    $result=mysqli_query($GLOBALS,$que);  
    $row = mysqli_fetch_array($result);
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
               <svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"/></svg>Ubah Data Master BIDANG
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=bidang&act=edit"?>" method="post" enctype="multipart/form-data">
                      <label>Kode BIDANG</label>
                      <input class="form-control" name="txtkdlog" id="txtkdlog" value="<?php echo($_GET[id]); ?>" readonly="readonly"/>
                      <label>Nama BIDANG</label>
                      <input class="form-control" name="txtusername" id="txtusername" value="<?php echo($row[NM_BIDANG]);?>" />
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-default">Ubah</button>
                    
                      <button type="reset" class="btn btn-primary">Reset</button>
                      </form>
              </div>
  </div>    
<?php
}
?>