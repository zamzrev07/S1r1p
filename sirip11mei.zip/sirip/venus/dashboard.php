<?php
//perhitungan penelitian 
 $tliti = "select * from prop_lit";
    $result1=mysqli_query($GLOBALS,$tliti);  
	$rss1 =mysqli_num_rows($result1);

//total dosen penelitian	
$totdos = "select * from m_dosen";
$resdos = mysqli_query($GLOBALS,$totdos);
$rsdos1 =mysqli_num_rows($resdos);

//cari prosentase

$caripersen1 = ($rss1 / $rsdos1) * 100;

?>

<?php
//ambil data total users
$users1 = "select * from m_login";
$resuser = mysqli_query($GLOBALS,$users1);
$rss2 = mysqli_num_rows($resuser);

//ambil data total dosen dan total mahasiswa
$mhs = "select * from m_mhs";
$resmhs = mysqli_query($GLOBALS,$mhs);
$rsmhs1 =mysqli_num_rows($resmhs);

//menambahkan total dosen dan mahasiswa
$totmhds = $rsmhs1 + $rsdos1;

$caripersen2 = ($rss2 / $totmhds) * 100;


?>

<?php
//penelitian
$skpen = "select * from prop_lit a, m_kategori b, m_subkat c, m_tahun d where a.KD_SUBKAT=c.KD_SUBKAT and a.KD_THN=d.KD_THN and b.KD_KAT=c.KD_KAT and b.NM_KAT='PENELITIAN'";
$rskpen = mysqli_query($GLOBALS,$skpen);
$numskpen = mysqli_num_rows($rskpen);

$ambilskim1 = $rsdos1 - $numskmas;

$caripersen3 = ($numskpen / $ambilskim1) * 100; 

?>

<?php
//pengabdian masyarakat
$skmas = "select * from prop_lit a, m_kategori b, m_subkat c, m_tahun d where a.KD_SUBKAT=c.KD_SUBKAT and a.KD_THN=d.KD_THN and b.KD_KAT=c.KD_KAT and b.NM_KAT='PENGABDIAN MASYARAKAT'";
$rskmas = mysqli_query($GLOBALS,$skmas);
$numskmas = mysqli_num_rows($rskmas);

$ambilskim2 = $rsdos1 - $numskpen;

$caripersen4 = ($numskmas / $ambilskim2) * 100 ; 

?>
        
     <div class="row"> 

	<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-blue panel-widget ">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<svg class="glyph stroked clipboard with paper"><use xlink:href="#stroked-clipboard-with-paper"/></svg>

						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php echo $rss1; ?></div>
							<div class="text-muted">Total Penelitian</div>
							<br>

						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-orange panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<svg class="glyph stroked table"><use xlink:href="#stroked-table"></use></svg>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php echo "$numskpen"; ?></div>
							<div class="text-muted">SKIM Penelitian</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-teal panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php echo $rss2; ?></div>
							<div class="text-muted">Total Pengguna</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-red panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<svg class="glyph stroked table"><use xlink:href="#stroked-table"></use></svg>

						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php echo "$numskmas"; ?></div>
							<div class="text-muted">SKIM Pengabdian</div>
						</div>
					</div>
				</div>
			</div>        
            </div>
            
            
            <div class="row">
			<div class="col-xs-6 col-md-3">
				<div class="panel panel-default">
					<div class="panel-body easypiechart-panel">
						<h4>Prosentase</h4>
						<h6>Pengajuan Penelitian Dosen</h6>
						<div class="easypiechart" id="easypiechart-blue" data-percent="<?php echo ceil($caripersen1); ?>" ><span class="percent"><?php echo ceil($caripersen1); ?>%</span>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-6 col-md-3">
				<div class="panel panel-default">
					<div class="panel-body easypiechart-panel">
						<h4>Prosentase</h4>
						<h6>Total SKIM Penelitian</h6>
						<div class="easypiechart" id="easypiechart-orange" data-percent="<?php echo ceil($caripersen3); ?>" ><span class="percent"><?php echo ceil($caripersen3); ?>%</span>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-6 col-md-3">
				<div class="panel panel-default">
					<div class="panel-body easypiechart-panel">
						<h4>Prosentase</h4>
						<h6>Total User SIRIP</h6>
						<div class="easypiechart" id="easypiechart-teal" data-percent="<?php echo ceil($caripersen2); ?>" ><span class="percent"><?php echo ceil($caripersen2); ?>%</span>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-6 col-md-3">
				<div class="panel panel-default">
					<div class="panel-body easypiechart-panel">
						<h4>Prosentase</h4>
						<h6>Total SKIM Pengabdian Masyarakat</h6>
						<div class="easypiechart" id="easypiechart-red" data-percent="<?php echo ceil($caripersen4); ?>"><span class="percent"><?php echo ceil($caripersen4); ?>%</span>
						</div>
					</div>
				</div>
			</div>
		</div><!--/.row-->
