<?php session_start();

include "../../config/koneksi.php";
$module=$_GET['venus'];
$act=$_GET['act'];

$sid_lama = session_id();
	
session_regenerate_id();

$sid_baru = session_id();

if($module=='dosen' AND $act=='input'){
  $npt  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnpt'],ENT_QUOTES))); 
  $nidn  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnidn'],ENT_QUOTES))); 
  $email = stripslashes(strip_tags(htmlspecialchars($_POST['txtemail'],ENT_QUOTES)));
   $ndos = stripslashes(strip_tags(htmlspecialchars($_POST['txtnamdos'],ENT_QUOTES)));
    $jab = stripslashes(strip_tags(htmlspecialchars($_POST['txtjab'],ENT_QUOTES))); 
  $kdpro    = $_POST['prog'];
  $rump = $_POST['rump'];
  $pkr = $_POST['pakar'];
  $aktif = $_POST['aktif'];  
  $jk = $_POST['jk'];
$pend = $_POST['pend'];
$jafa = $_POST['jafa'];
$jnsp = $_POST['jnsp'];
  
  $ds="ds";
  $paw=$ds.$npt; 
  //autonumber m_login
 $query = "SELECT max(KD_LOG) as maxKode FROM m_login";
   $hasil = mysqli_query($GLOBALS,$query); 
  $data = mysqli_fetch_array($hasil); 
  $kodeBarang = $data['maxKode']; 
   $noUrut = (int) substr($kodeBarang, 1, 5); 
   $noUrut++; 
   $char="U";
    $newID = $char . sprintf("%05s", $noUrut);
	//selesai auto
	$idn=$newID;
	$ps=md5($paw);
	
	$qin= "SELECT USER_LOG FROM m_login where USER_LOG='$npt'";
	   $hin = mysqli_query($GLOBALS,$qin); 
  $din = mysqli_fetch_array($hin);

 if ($din>0){
	  $_SESSION['pesan'] = 'Data Sudah Ada';
	  header('location:../../dosen.html');
  }else{	
	$isl = ("INSERT INTO m_login
  (KD_LOG,USER_LOG,PASS_LOG,ID_SESSION,STA_LOG,AKTIF_LOG) 
  VALUES 
 ('$idn','$npt','$ps','$sid_baru','2','YA')");
 if (mysqli_query($GLOBALS,$isl)){
 		$sml="SELECT KD_LOG FROM M_LOGIN WHERE KD_LOG='$idn'";
 		$hs = mysqli_query($GLOBALS,$sml);
 		$dt = mysqli_fetch_array($hs);
 		$kdm = $dt['KD_LOG'];	 
 		$sql =("INSERT INTO m_dosen
  		(NPT,KD_JAFA,KD_PROGDI,KD_LOG,KD_RUMPUN,KD_PAKAR,NIDN,NM_DOSEN,JK_DOSEN,EMAIL_DOSEN,JAB_AKADEMIK,AKTIF_DOSEN, PENDIDIKAN,JNS_DOSEN) 
  		VALUES  ('$npt', '$jafa' ,'$kdpro','$kdm','$rump','$pkr','$nidn','$ndos','$jk','$email','$jab','$aktif','$pend','$jnsp')");

		 if (mysqli_query($GLOBALS, $sql)) {
    		header('location:../../dosen.html');
		} else {
    		echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
		}	 
 
 }else{
	 echo "Error: " . $sml . "<br>" . mysqli_error($GLOBALS); 
	 
 }
  }
}
elseif($module=='dosen' AND $act=='edit'){

  $npte     = stripslashes(strip_tags(htmlspecialchars($_POST['txtnpt'],ENT_QUOTES))); 
  $nidne    = stripslashes(strip_tags(htmlspecialchars($_POST['txtnidn'],ENT_QUOTES))); 
  $namdose  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnamdos'],ENT_QUOTES)));
  $eme      = stripslashes(strip_tags(htmlspecialchars($_POST['txtemail'],ENT_QUOTES)));
	$jabe     = stripslashes(strip_tags(htmlspecialchars($_POST['txtjab'],ENT_QUOTES)));   
  $kdprg    = $_POST['prog'];
  $rumpun   = $_POST['rumpun'];
  $pakar    = $_POST['pakar'];
  $jk       = $_POST['jk'];
  $ados     = $_POST['aktifdosen'];
	$pend = $_POST['pend'];
$jnsp = $_POST['jnsp'];
$jafa = $_POST['jafa'];

   $sql=("UPDATE m_dosen SET NPT='$npte' , KD_PROGDI = '$kdprg', KD_RUMPUN    = '$rumpun',KD_PAKAR = '$pakar',KD_JAFA='$jafa', NIDN = '$nidne', NM_DOSEN = '$namdose', JK_DOSEN = '$jk', EMAIL_DOSEN = '$eme', JAB_AKADEMIK = '$jabe',PENDIDIKAN='$pend', AKTIF_DOSEN = '$ados', JNS_DOSEN='$jnsp' WHERE NPT   = '$npte'");
if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../dosen.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
}/*
elseif($module=='users' AND $act=='delete'){
    mysql_query("DELETE FROM fakultas WHERE kd_fakultas = '$_REQUEST[sid]'");
    header('location:../../dosen.html');
}*/
?>