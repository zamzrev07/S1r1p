<?php session_start();

include "../../config/koneksi.php";
$module=$_GET['venus'];
$act=$_GET['act'];

$sid_lama = session_id();
	
session_regenerate_id();

$sid_baru = session_id();

if($module=='fakultas' AND $act=='input'){
  $kdfak  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdlog'],ENT_QUOTES))); 
  $nmfak  = stripslashes(strip_tags(htmlspecialchars($_POST['txtusername'],ENT_QUOTES))); 
  $nipdekan = stripslashes(strip_tags(htmlspecialchars($_POST['txtnipdekan'],ENT_QUOTES))); 
  $nmdekan  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnmdekan'],ENT_QUOTES))); 
  $aktifak = $_POST['aktifak']; 

  $sql =("INSERT INTO m_fakultas
  (KD_FAK,NM_FAK,AKTIF_FAK,NM_DEKAN,NIP_DEKAN) 
  VALUES  ('$kdfak','$nmfak','$aktifak','$nmdekan','$nipdekan')");

 if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../fakultas.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
  
 
}
elseif($module=='fakultas' AND $act=='edit'){

  $kdfak  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdlog'],ENT_QUOTES))); 
  $nmfak  = stripslashes(strip_tags(htmlspecialchars($_POST['txtusername'],ENT_QUOTES))); 
  $nipdekan = stripslashes(strip_tags(htmlspecialchars($_POST['txtnipdekan'],ENT_QUOTES))); 
  $nmdekan  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnmdekan'],ENT_QUOTES))); 
  $aktifak = $_POST['aktifak']; 

   $sql=("UPDATE m_fakultas SET NM_FAK    = '$nmfak', NIP_DEKAN    = '$nipdekan',NM_DEKAN    = '$nmdekan',
								 AKTIF_FAK = '$aktifak' WHERE KD_FAK   = '$kdfak'");
if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../fakultas.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
}/*
elseif($module=='users' AND $act=='delete'){
    mysql_query("DELETE FROM fakultas WHERE kd_fakultas = '$_REQUEST[sid]'");
    header('location:../../fakultas.html');
}*/
?>