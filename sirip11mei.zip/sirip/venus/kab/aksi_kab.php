<?php session_start();

include "../../config/koneksi.php";
$module=$_GET['venus'];
$act=$_GET['act'];

$sid_lama = session_id();
	
session_regenerate_id();

$sid_baru = session_id();

if($module=='kab' AND $act=='input'){
  $kdprogdi  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdlog'],ENT_QUOTES))); 
  $nmprogdi  = stripslashes(strip_tags(htmlspecialchars($_POST['txtusername'],ENT_QUOTES))); 
  $kdfak    = $_POST['fak']; 
  $aktiprogdi = $_POST['aktifprogdi']; 

  $sql =("INSERT INTO m_kota
  (KD_KOTA, KD_PROP,NM_KOTA) 
  VALUES  ('$kdfak','$kdprogdi','$nmprogdi')");

 if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../kab.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
  
 
}
elseif($module=='kab' AND $act=='edit'){

  $kdprogdi  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdlog'],ENT_QUOTES))); 
  $nmprogdi  = stripslashes(strip_tags(htmlspecialchars($_POST['txtusername'],ENT_QUOTES))); 
  $kdfak    = $_POST['fak']; 
  $aktiprogdi = $_POST['aktifprogdi']; 

   $sql=("UPDATE m_kota SET NM_KOTA = '$nmprogdi', KD_PROP='$kdfak' WHERE KD_KOTA   = '$kdprogdi'");
if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../kab.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
}/*
elseif($module=='users' AND $act=='delete'){
    mysql_query("DELETE FROM fakultas WHERE KD_KOTAultas = '$_REQUEST[sid]'");
    header('location:../../fakultas.html');
}*/
?>