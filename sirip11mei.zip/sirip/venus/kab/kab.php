<script>
function hapusdata(urltujuan){
		el=$(this);
		if(confirm("Do you want to delete the data ?."))
		{
            alert("Data Deleted!");
            
            window.location = (urltujuan);
        }
        else{
            alert("Failure to Delete");
        }
}
</script>
            
<?php
$aksi="venus/kab/aksi_kab.php";

  // Tampil Agenda
  if($_GET[venus] == "kab"){
    $que = "select * from m_kota a, m_propinsi b where a.KD_PROP=b.KD_PROP";
	$result=mysqli_query($GLOBALS,$que);
	$jumrows = mysqli_num_rows($result);
?>
    
	<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>Data Master Kota / Kabupaten</div>
					<div class="panel-body">
          <!--          <a href="kabadd.html" class="btn btn-primary">Tambah Sub Kategori</a> -->
					<table data-toggle="table" data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
        <thead>
            <tr>
                <th data-sortable="true">Propinsi</th>
                <th data-sortable="true">Nama Kota / Kab</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
		<?php
		$iCnt=0;
		if ($jumrows>0) { 
			while ($row = mysqli_fetch_array($result)) {
        $iCnt++;
		?>
        
		  <tr <?php if ($iCnt%2==0) {?>class="odd gradeX" <?php } else {?>class="even gradeC"<?php }?> >
      <td><?php echo strip_tags(strtoupper($row[NM_PROP])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[NM_KOTA])); ?></td>
            <td><a data-toggle="tooltip" data-placement="top" title="edit" href="<?php echo("kabedit-$row[KD_KOTA].html")?>" class="btn btn-sm btn-warning">Edit</a></td>  
		  </tr>
		<?php
			}
		}else{
		?>
		<tr>
			<td colspan="6">Data tidak di temukan</td>
		</tr>
		<?php
		}
		?>
        </tbody>
	</table>
    </div>
    </div>
    </div>
    </div>
	<?php
  }
elseif($_GET[venus]=="kabadd"){

 $query = "SELECT max(KD_SUBKAT) as maxKode FROM m_kota";
   $hasil = mysqli_query($GLOBALS,$query); 
  $data = mysqli_fetch_array($hasil); 
  $kodeBarang = $data['maxKode']; 
   $noUrut = (int) substr($kodeBarang, 1, 5); 
   $noUrut++; 
   $char="K";
    $newID = $char . sprintf("%05s", $noUrut);	
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
             <svg class="glyph stroked plus sign"><use xlink:href="#stroked-plus-sign"/></svg> Tambah Data Master Kota / Kabupaten
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=kab&act=input"?>" method="post" enctype="multipart/form-data">
                   <label>Kode Sub Kategori</label>
                      <input class="form-control" name="txtkdlog" id="txtkdlog" value="<?php echo $newID; ?>" readonly="readonly"/>
                      <label>Kategori</label>
                      <select name="fak" class="form-control">
<?php 
$quer = "select * from m_prop ";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_PROP']; ?>"><?php echo strtoupper($rot['NM_KAT']); ?></option> <?php } ?>
                      </select>
                      <label>Nama Sub Kategori</label>
                      <input class="form-control" name="txtusername" id="txtusername" />
                     
                      <label>Status Aktif Sub Kategori</label>
                      <select name="aktifprogdi" class="form-control">
                      <option value="YA">YA</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                      
                      <button type="reset" class="btn btn-default">Reset</button>

                  </form>
              </div>
    </div>  
<?php
}
elseif($_GET[venus]=="kabedit"){
  	$que = "select * from m_kota a, m_propinsi b where a.KD_PROP=b.KD_PROP and a.KD_KOTA='$_GET[id]'";
    $result=mysqli_query($GLOBALS,$que);  
    $row = mysqli_fetch_array($result);
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
               <svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"/></svg>Ubah Data Master Kota / Kabupaten
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=kab&act=edit"?>" method="post" enctype="multipart/form-data">
                      <label>No</label>
                      <input class="form-control" name="txtkdlog" id="txtkdlog" value="<?php echo($_GET[id]); ?>" readonly="readonly"/>
                      <label>Propinsi</label>
                      <select name="fak" class="form-control">
                      <option value="<?php if($_GET[venus]=="kabedit"){ echo($row[KD_PROP]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="kabedit"){ echo strtoupper($row[NM_PROP]); }else{echo 'Silahkan Pilih'; }?></option>
                      <?php 
$quer = "select * from m_propinsi order by NM_PROP asc";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_PROP']; ?>"><?php echo strtoupper($rot['NM_PROP']); ?></option> <?php } ?>
                      </select>

                     <label>Nama Kota / Kabupaten</label>
                      <input class="form-control" name="txtusername" id="txtusername" value="<?php echo($row[NM_KOTA]);?>" />
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-default">Ubah</button>
                    
                      <button type="reset" class="btn btn-primary">Reset</button>
                      </form>
              </div>
  </div>    
<?php
}
?>