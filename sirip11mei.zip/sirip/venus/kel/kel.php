<script>
function hapusdata(urltujuan){
		el=$(this);
		if(confirm("Do you want to delete the data ?."))
		{
            alert("Data Deleted!");
            
            window.location = (urltujuan);
        }
        else{
            alert("Failure to Delete");
        }
}
</script>
            
<?php
$aksi="venus/kel/aksi_kel.php";

  // Tampil Agenda
  if($_GET[venus] == "kel"){
    $que = "select * from m_kelompok ";
	$result=mysqli_query($GLOBALS,$que);
	$jumrows = mysqli_num_rows($result);
?>
    
	<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>Data Master Kelompok KKN</div>
					<div class="panel-body">
                    <a href="keladd.html" class="btn btn-primary">Tambah Master Kelompok KKN</a>
					<table data-toggle="table" data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
        <thead>
            <tr>
                <th data-sortable="true">Kode Kelompok</th>
                <th data-sortable="true">Nama Kelompok</th>
                <th data-sortable="true">Isi Kelompok</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
		<?php
		$iCnt=0;
		if ($jumrows>0) { 
			while ($row = mysqli_fetch_array($result)) {
        $iCnt++;
		?>
        
		  <tr <?php if ($iCnt%2==0) {?>class="odd gradeX" <?php } else {?>class="even gradeC"<?php }?> >
      <td><?php echo strip_tags(strtoupper($row[KD_KEL])); ?></td>
			<td><?php echo strip_tags(strtoupper($row[1])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[2])); ?></td>
            <td><a data-toggle="tooltip" data-placement="top" title="edit" href="<?php echo("keledit-$row[KD_KEL].html")?>" class="btn btn-sm btn-warning">Edit</a></td>  
		  </tr>
		<?php
			}
		}else{
		?>
		<tr>
			<td colspan="6">Data tidak di temukan</td>
		</tr>
		<?php
		}
		?>
        </tbody>
	</table>
    </div>
    </div>
    </div>
    </div>
	<?php
  }
elseif($_GET[venus]=="keladd"){

 $query = "SELECT max(KD_KEL) as maxKode FROM m_kelompok";
   $hasil = mysqli_query($GLOBALS,$query); 
  $data = mysqli_fetch_array($hasil); 
  $kodeBarang = $data['maxKode']; 
   $noUrut = (int) substr($kodeBarang, 2, 5); 
   $noUrut++; 
   $char="KL";
    $newID = $char . sprintf("%05s", $noUrut);	
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
             <svg class="glyph stroked plus sign"><use xlink:href="#stroked-plus-sign"/></svg> Tambah Data Master Kelompok KKN
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=kel&act=input"?>" method="post" enctype="multipart/form-data">
                   <label>Kode Kelompok</label>
                      <input class="form-control" name="txtkdlog" id="txtkdlog" value="<?php echo $newID; ?>" readonly="readonly"/>
                      <label>Nama Kelompok</label>
                      <input class="form-control" name="txtusername" id="txtusername" />
                      <label>Isi Kelompok</label>
                      <input class="form-control" type="number" name="txtisikel" id="txtisikel" /><!--
                      <label>Status Progdi</label>
                      <select name="aktifprogdi" class="form-control">
                      <option value="YA">YA</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>-->
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                      
                      <button type="reset" class="btn btn-default">Reset</button>

                  </form>
              </div>
    </div>  
<?php
}
elseif($_GET[venus]=="keledit"){
  	$que = "select * from m_kelompok where KD_KEL='$_GET[id]'";
    $result=mysqli_query($GLOBALS,$que);  
    $row = mysqli_fetch_array($result);
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
               <svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"/></svg>Ubah Data Master Kelompok
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=kel&act=edit"?>" method="post" enctype="multipart/form-data">
                      <label>Kode Kelompok</label>
                      <input class="form-control" name="txtkdlog" id="txtkdlog" value="<?php echo($_GET[id]); ?>" readonly="readonly"/>
                      <label>Nama Kelompok</label>
                      <input class="form-control" name="txtusername" id="txtusername" value="<?php echo($row[NM_KEL]);?>" />
                      <label>Isi Kelompok</label>
                      <input class="form-control" type="number" name="txtisikel" id="txtisikel" value="<?php echo($row[ISI_KEL]);?>" />
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-default">Ubah</button>
                    
                      <button type="reset" class="btn btn-primary">Reset</button>
                      </form>
              </div>
  </div>    
<?php
}
?>