<script>
function hapusdata(urltujuan){
		el=$(this);
		if(confirm("Do you want to delete the data ?."))
		{
            alert("Data Deleted!");
            
            window.location = (urltujuan);
        }
        else{
            alert("Failure to Delete");
        }
}
</script>
            
<?php
$aksi="venus/mahasiswa_un/aksi_mahasiswa.php";

  // Tampil Agenda
  if($_GET[venus] == "mhs"){
    $que = "select m_mhs.NPM, m_progdi.NM_PROGDI, m_mhs.NM_MHS, m_mhs.JK_MHS, m_mhs.EMAIL_MHS from m_mhs inner join m_progdi on m_mhs.KD_PROGDI=m_progdi.KD_PROGDI";
	$result=mysqli_query($GLOBALS,$que);
	$jumrows = mysqli_num_rows($result);
?>
    
	<div class="row">

<div class="col-sm-3">
				<div class="panel panel-info">
					
					<div class="panel-body">
						<table class="table table-bordered">
    <tr><td>Progdi<select name="fak" class="form-control">
<?php 
$quer = "select * from m_progdi";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_PROGDI']; ?>"><?php echo strtoupper($rot['NM_PROGDI']); ?></option> <?php } ?>
                      </select></td></tr>
    <tr><td> <a href="mhsadd.html" class="btn btn-primary">Input Data</a></td></tr>
    </table>

					</div>
				</div>
			</div>      
          
               
			<div class="col-sm-9">
                    <?php 
    //        menampilkan pesan jika ada pesan
            if (($_SESSION['pesan']) && $_SESSION['pesan'] <> '') {
                echo '<div class="alert bg-danger" role="alert">'.$_SESSION['pesan'].'<button type="button" class="close" data-dismiss="alert">×</button></div>';
            }

    //        mengatur session pesan menjadi kosong
            $_SESSION['pesan'] = '';
            ?> 
                <div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>Data Mahasiswa</div>
              
					<div class="panel-body">
                   
					<table data-toggle="table" data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
        <thead>
            <tr>
                <th data-sortable="true">NPM</th>
                <th data-sortable="true">Nama Progdi</th>
                <th data-sortable="true">Nama Mahasiswa</th>
                <th data-sortable="true">JK</th>
                <th data-sortable="true">Email</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
		<?php
		$iCnt=0;
		if ($jumrows>0) { 
			while ($row = mysqli_fetch_array($result)) {
        $iCnt++;
		?>
        
		  <tr <?php if ($iCnt%2==0) {?>class="odd gradeX" <?php } else {?>class="even gradeC"<?php }?> >
      <td><?php echo strip_tags(strtoupper($row[0])); ?></td>
			<td><?php echo strip_tags(strtoupper($row[1])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[2])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[3])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[4])); ?></td>
            <td><a data-toggle="tooltip" data-placement="top" title="edit" href="<?php echo("mhsedit-$row[0].html")?>" class="btn btn-sm btn-warning">Edit</a></td>  
		  </tr>
		<?php
			}
		}else{
		?>
		<tr>
			<td colspan="6">Data tidak di temukan</td>
		</tr>
		<?php
		}
		?>
        </tbody>
	</table>
    </div>
    </div>
    </div>
    </div>
	<?php
  }
elseif($_GET[venus]=="mhsadd"){
	
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
             <svg class="glyph stroked plus sign"><use xlink:href="#stroked-plus-sign"/></svg> Tambah Data Master Mahasiswa
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=mhs&act=input"?>" method="post" enctype="multipart/form-data">
                   <label>NPM</label>
                      <input class="form-control" name="txtnpm" id="txtnpm" />
                      <label>Nama Progdi</label>
                      <select name="prog" class="form-control">
<?php 
$quer = "select * from m_progdi ";
$resultts=mysqli_query($GLOBALS,$quer);
while ($rots = mysqli_fetch_array($resultts)) { ?>                      
                      <option value="<?php echo $rots['KD_PROGDI']; ?>"><?php echo strtoupper($rots['NM_PROGDI']); ?></option> <?php } ?>
                      </select>
                      <label>Nama Mahasiswa</label>
                      <input class="form-control" name="txtmname" id="txtmname" />
                      <label>Jenis Kelamin</label>
                      <select name="jk" class="form-control">
                      <option value="L">LAKI-LAKI</option>
                      <option value="P">PEREMPUAN</option>
                      </select>
                    <label>Email</label>
                      <input class="form-control" name="txtemail" id="txtemail" />
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                      
                      <button type="reset" class="btn btn-default">Reset</button>

                  </form>
              </div>
    </div>  
<?php
}
elseif($_GET[venus]=="mhsedit"){
  	$que = "select * from m_mhs a, m_progdi b where a.KD_PROGDI=b.KD_PROGDI and a.NPM='$_GET[id]'";
    $result=mysqli_query($GLOBALS,$que);  
    $row = mysqli_fetch_array($result);
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
               <svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"/></svg>Ubah Data Master Mahasiswa
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=mhs&act=edit"?>" method="post" enctype="multipart/form-data">
                      <label>NPM</label>
                      <input class="form-control" name="txtnpm" id="txtnpm" value="<?php echo($_GET[id]); ?>"/>
                      <label>Nama Progdi</label>
                      <select name="prog" class="form-control">
                      <option value="<?php if($_GET[venus]=="mhsedit"){ echo($row[KD_PROGDI]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="mhsedit"){ echo strtoupper($row[NM_PROGDI]); }else{echo 'Silahkan Pilih'; }?></option>
                      <?php 
$quer = "select * from m_progdi ";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_PROGDI']; ?>"><?php echo strtoupper($rot['NM_PROGDI']); ?></option> <?php } ?>
                      </select>
                      <label>Nama Mahasiswa</label>
                      <input class="form-control" name="txtnamam" id="txtnamam" value="<?php echo($row[NM_MHS]);?>" /> 
                      <label>Jenis Kelamin</label>
                      <select name="jk" class="form-control">                                            
                      <option value="<?php if($_GET[venus]=="mhsedit"){ echo($row[JK_MHS]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="mhsedit"){ echo($row[JK_MHS]); }else{echo 'Silahkan Pilih'; }?></option>
                      <option value="L">LAKI-LAKI</option>
                      <option value="P">PEREMPUAN</option>
                      </select>
                       <label>Email</label>
                      <input class="form-control" name="txtemail" id="txtemail" value="<?php echo($row[EMAIL_MHS]);?>" /> 
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-default">Ubah</button>
                    
                      <button type="reset" class="btn btn-primary">Reset</button>
                      </form>
              </div>
  </div>    
<?php
}
?>