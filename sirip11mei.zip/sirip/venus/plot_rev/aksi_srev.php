<?php session_start();

include "../../config/koneksi.php";
$module=$_GET['venus'];
$act=$_GET['act'];

$sid_lama = session_id();
	
session_regenerate_id();

$sid_baru = session_id();

if($module=='srev' AND $act=='input'){
$newID  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdlog'],ENT_QUOTES)));
$npt  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnpt1'],ENT_QUOTES))); 
  $kdthn    = $_POST['thn'];
  $aktif = $_POST['aktif'];
  $skim = $_POST['skim'];

$sql = "INSERT INTO set_reviewer (KD_SETR,NPT,KD_SUBKAT,KD_THN,AKTIF_REV) 
  VALUES 
 ('$newID','$npt','$skim','$kdthn','$aktif')";
//echo "masuk";
if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../srev.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}

}

elseif($module=='srev' AND $act=='edit'){

  $npte     = stripslashes(strip_tags(htmlspecialchars($_POST['txtnpt'],ENT_QUOTES))); 
  $nidne    = stripslashes(strip_tags(htmlspecialchars($_POST['txtnidn'],ENT_QUOTES))); 
  $namdose  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnamdos'],ENT_QUOTES)));
  $eme      = stripslashes(strip_tags(htmlspecialchars($_POST['txtemail'],ENT_QUOTES)));
	$jabe     = stripslashes(strip_tags(htmlspecialchars($_POST['txtjab'],ENT_QUOTES)));   
  $kdprg    = $_POST['prog'];
  $rumpun   = $_POST['rumpun'];
  $pakar    = $_POST['pakar'];
  $jk       = $_POST['jk'];
  $ados     = $_POST['aktifdosen'];
	$pend = $_POST['pend'];
   $sql=("UPDATE m_dosen SET NPT='$npte' , KD_PROGDI    = '$kdprg', KD_RUMPUN    = '$rumpun',KD_PAKAR = '$pakar', NIDN = '$nidne', NM_DOSEN = '$namdose', JK_DOSEN = '$jk', EMAIL_DOSEN = '$eme', JAB_AKADEMIK = '$jabe',PENDIDIKAN='$pend', AKTIF_DOSEN = '$ados' WHERE NPT   = '$npte'");
if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../dosen.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
}/*
elseif($module=='users' AND $act=='delete'){
    mysql_query("DELETE FROM fakultas WHERE kd_fakultas = '$_REQUEST[sid]'");
    header('location:../../dosen.html');
}*/
?>