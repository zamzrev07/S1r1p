<?php session_start();

include "../../config/koneksi.php";
$module=$_GET['venus'];
$act=$_GET['act'];

$sid_lama = session_id();
	
session_regenerate_id();

$sid_baru = session_id();

if($module=='plotrev' AND $act=='input'){
$newID  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdp'],ENT_QUOTES)));
$kprop  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdprop'],ENT_QUOTES))); 
$kdsetr = $_POST['ds1'];
$nprev2 = $_POST['ds2'];
$aktif  = $_POST['aktif'];
$kdthn  = $_POST['txtthn'];
$starev = "PLOT";

$sql = "INSERT INTO m_reviewer (KD_REVIEWER,KD_SETR,KD_LIT,AKTIF_REVIEWER,NPT_REVIEWER2,KD_THN,STA_REV) 
  VALUES 
 ('$newID','$kdsetr','$kprop','$aktif','$nprev2','$kdthn','$starev')";

// $sqlu="UPDATE prop_lit SET STATUS_PROPOSAL='PAPARAN' WHERE KD_LIT   = '$kprop'"; 
// mysqli_query($GLOBALS, $sqlu);
//echo "masuk";
if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../prev.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}

}

elseif($module=='srev' AND $act=='edit'){
$newID  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkd'],ENT_QUOTES)));
$npt  = stripslashes(strip_tags(htmlspecialchars($_POST['npt'],ENT_QUOTES))); 
  $kdthn    = $_POST['thn'];
  $aktif = $_POST['aktif'];
  $skim = $_POST['skim'];

$sql=("UPDATE set_reviewer SET NPT='$npt' , KD_SUBKAT    = '$skim', AKTIF_REV = '$aktif' WHERE KD_SETR   = '$newID'");
if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../srev.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
}/*
elseif($module=='users' AND $act=='delete'){
    mysql_query("DELETE FROM fakultas WHERE kd_fakultas = '$_REQUEST[sid]'");
    header('location:../../dosen.html');
}*/
?>