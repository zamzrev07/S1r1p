<?php
// panggil file koneksi.php
include "../../config/koneksi.php";
// buat koneksi ke database mysql


// tangkap variabel kd_mhs
$kd_m = $_POST['id'];

// query untuk menampilkan kd_mh
 $data = "select * from m_reviewer a, set_reviewer b, m_dosen c where a.KD_SETR=b.KD_SETR and b.NPT=c.NPT and a.KD_LIT='$kd_m'";
    $result=mysqli_query($GLOBALS,$data);  
    $row = mysqli_fetch_array($result);
	$rss =mysqli_num_rows($result);


// jika kd_m > 0 / form ubah data
if($rss > 0) { 
	$one = $row[NM_DOSEN];
	$two = $row[AKTIF_REVIEWER];

//form tambah data
} else {
 echo "error";
}

?>
<form class="form-horizontal" id="form-mahasiswa">
	
                      <label>NAMA REVIEWER 1</label>
                      <input type="text" class="form-control" name="txtpnls1" id="txtpnls1" readonly="readonly" value="<?php echo $one ?>" />
                      <label>STATUS REVIEWER</label>
                      <input type="text" class="form-control" name="txtpnls1" id="txtpnls1" readonly="readonly" value="<?php echo $two ?>" />
                      <label>TAHUN PENELITIAN</label>
                      <input type="text" class="form-control" name="txtpnls1" id="txtpnls1" readonly="readonly" value="<?php echo $ket_thn ?>" />
    <br />
</form>
<a class="popup-close" href="#closed">X</a>
<?php
// tutup koneksi ke database mysql

?>
