<?php session_start();

include "../../config/koneksi.php";
$module=$_GET['venus'];
$act=$_GET['act'];

$sid_lama = session_id();
	
session_regenerate_id();

$sid_baru = session_id();

if($module=='progdi' AND $act=='input'){
  $kdprogdi  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdlog'],ENT_QUOTES))); 
  $nmprogdi  = stripslashes(strip_tags(htmlspecialchars($_POST['txtusername'],ENT_QUOTES))); 
  $nipprogdi = stripslashes(strip_tags(htmlspecialchars($_POST['txtnipkaprogdi'],ENT_QUOTES))); 
  $kaprogdi  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnmkaprogdi'],ENT_QUOTES))); 
  $kdfak    = $_POST['fak']; 
  $aktiprogdi = $_POST['aktifprogdi']; 
  $jenjang = $_POST['jenjang']; 

  $sql =("INSERT INTO m_progdi
  (KD_FAK, KD_PROGDI,NM_PROGDI,AKTIF_PROGDI,KA_PROGDI,NIP_PROGDI,JENJANG_PROGDI) 
  VALUES  ('$kdfak','$kdprogdi','$nmprogdi','$aktiprogdi','$kaprogdi','$nipprogdi','$jenjang')");

 if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../progdi.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
  
 
}
elseif($module=='progdi' AND $act=='edit'){

  $kdprogdi  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdlog'],ENT_QUOTES))); 
  $nmprogdi  = stripslashes(strip_tags(htmlspecialchars($_POST['txtusername'],ENT_QUOTES))); 
  $nipprogdi = stripslashes(strip_tags(htmlspecialchars($_POST['txtnipkaprogdi'],ENT_QUOTES))); 
  $kaprogdi  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnmkaprogdi'],ENT_QUOTES))); 
  $kdfak    = $_POST['fak']; 
  $aktiprogdi = $_POST['aktifprogdi']; 
  $jenjang = $_POST['jenjang'];

   $sql=("UPDATE m_progdi SET KD_FAK='$kdfak' , NM_PROGDI    = '$nmprogdi', NIP_PROGDI    = '$nipprogdi',KA_PROGDI    = '$kaprogdi',
								 AKTIF_PROGDI = '$aktiprogdi',JENJANG_PROGDI='$jenjang',KD_FAK='$kdfak' WHERE KD_PROGDI   = '$kdprogdi'");
if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../progdi.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
}/*
elseif($module=='users' AND $act=='delete'){
    mysql_query("DELETE FROM fakultas WHERE kd_fakultas = '$_REQUEST[sid]'");
    header('location:../../fakultas.html');
}*/
?>