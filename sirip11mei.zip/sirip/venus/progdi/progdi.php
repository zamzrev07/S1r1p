<script>
function hapusdata(urltujuan){
		el=$(this);
		if(confirm("Do you want to delete the data ?."))
		{
            alert("Data Deleted!");
            
            window.location = (urltujuan);
        }
        else{
            alert("Failure to Delete");
        }
}
</script>
            
<?php
$aksi="venus/progdi/aksi_progdi.php";

  // Tampil Agenda
  if($_GET[venus] == "progdi"){
  $que = "select * from m_progdi a, m_fakultas b where a.KD_FAK=b.KD_FAK";
	$result=mysqli_query($GLOBALS,$que);
	$jumrows = mysqli_num_rows($result);
?>
    
	<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>Data Master Progdi</div>
					<div class="panel-body">
                    <a href="progdiadd.html" class="btn btn-primary">Tambah Program Studi</a>
					<table data-toggle="table" data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
        <thead>
            <tr>
                <th data-sortable="true">Fakultas</th>
                <th data-sortable="true">Kode Progdi</th>
                <th data-sortable="true"><u>Nama Progdi</u><br>Bidang</th>
                <th data-sortable="true">NIP Kaprogdi</th>
                <th data-sortable="true">Nama Kaprogdi</th>
                <th data-sortable="true">Status Aktif</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
		<?php
		$iCnt=0;
		if ($jumrows>0) { 
			while ($row = mysqli_fetch_array($result)) {
        $iCnt++;
		?>
        
		  <tr <?php if ($iCnt%2==0) {?>class="odd gradeX" <?php } else {?>class="even gradeC"<?php }?> >
      <td><?php echo strip_tags(strtoupper($row[NM_FAK])); ?></td>
			<td><?php echo strip_tags(strtoupper($row[KD_PROGDI])); ?></td>
      <td><u><?php echo strip_tags(strtoupper($row[NM_PROGDI])); ?></u><br><i>
      <?php 
      $bid = "select * from m_progdi a, m_bidang b where a.KD_BIDANG=b.KD_BIDANG and KD_PROGDI='$row[KD_PROGDI]'";
      $resbid=mysqli_query($GLOBALS,$bid);
      $rbid = mysqli_fetch_array($resbid);
      echo strip_tags(strtoupper($rbid[NM_BIDANG])); ?></i></td>
            <td><?php echo strip_tags(strtoupper($row[NIP_PROGDI])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[KA_PROGDI])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[AKTIF_PROGDI])); ?></td>
            <td><a data-toggle="tooltip" data-placement="top" title="edit" href="<?php echo("progdiedit-$row[KD_PROGDI].html")?>" class="btn btn-sm btn-warning">Edit</a></td>  
		  </tr>
		<?php
			}
		}else{
		?>
		<tr>
			<td colspan="6">Data tidak di temukan</td>
		</tr>
		<?php
		}
		?>
        </tbody>
	</table>
    </div>
    </div>
    </div>
    </div>
	<?php
  }
elseif($_GET[venus]=="progdiadd"){

 $query = "SELECT max(KD_PROGDI) as maxKode FROM m_progdi";
   $hasil = mysqli_query($GLOBALS,$query); 
  $data = mysqli_fetch_array($hasil); 
  $kodeBarang = $data['maxKode']; 
   $noUrut = (int) substr($kodeBarang, 1, 5); 
   $noUrut++; 
   $char="K";
    $newID = $char . sprintf("%05s", $noUrut);	
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
             <svg class="glyph stroked plus sign"><use xlink:href="#stroked-plus-sign"/></svg> Tambah Data Master Progdi
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=progdi&act=input"?>" method="post" enctype="multipart/form-data">
                   <label>Kode Progdi</label>
                      <input class="form-control" name="txtkdlog" id="txtkdlog" value="<?php echo $newID; ?>" readonly="readonly"/>
                      <label>Fakultas</label>
                      <select name="fak" class="form-control">
<?php 
$quer = "select * from m_fakultas ";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_FAK']; ?>"><?php echo strtoupper($rot['NM_FAK']); ?></option> <?php } ?>
                      </select>
                      <label>Nama Progdi</label>
                      <input class="form-control" name="txtusername" id="txtusername" />
                      <label>NIP Kaprogdi</label>
                      <input class="form-control" name="txtnipkaprogdi" id="txtnipkaprogdi" />
                      <label>Nama Kaprogdi</label>
                      <input class="form-control" name="txtnmkaprogdi" id="txtnmkaprogdi" />
                      <label>Jenjang Progdi</label>
                      <select name="jenjang" class="form-control">
                      <option value="D3">DIPLOMA 3</option>
                      <option value="D4">DIPLOMA 4</option>
                      <option value="S1">SARJANA</option>
                      <option value="S2">PASCA MAGISTER</option>
                      <option value="S3">PASCA DOKTOR</option>
                      </select>
                      <label>Status Progdi</label>
                      <select name="aktifprogdi" class="form-control">
                      <option value="YA">YA</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                      
                      <button type="reset" class="btn btn-default">Reset</button>

                  </form>
              </div>
    </div>  
<?php
}
elseif($_GET[venus]=="progdiedit"){
  	$que = "select * from m_progdi a, m_fakultas b where a.KD_FAK=b.KD_FAK and a.KD_PROGDI='$_GET[id]'";
    $result=mysqli_query($GLOBALS,$que);  
    $row = mysqli_fetch_array($result);
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
               <svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"/></svg>Ubah Data Master progdi
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=progdi&act=edit"?>" method="post" enctype="multipart/form-data">
                      <label>Kode progdi</label>
                      <input class="form-control" name="txtkdlog" id="txtkdlog" value="<?php echo($_GET[id]); ?>" readonly="readonly"/>
                      <label>Fakultas</label>
                      <select name="fak" class="form-control">
                      <option value="<?php if($_GET[venus]=="progdiedit"){ echo($row[KD_FAK]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="progdiedit"){ echo strtoupper($row[NM_FAK]); }else{echo 'Silahkan Pilih'; }?></option>
                      <?php 
$quer = "select * from m_fakultas ";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_FAK']; ?>"><?php echo strtoupper($rot['NM_FAK']); ?></option> <?php } ?>
                      </select>

                     <label>Nama Progdi</label>
                      <input class="form-control" name="txtusername" id="txtusername" value="<?php echo($row[NM_PROGDI]);?>" />
                      <label>NIP Kaprogdi</label>
                      <input class="form-control" name="txtnipkaprogdi" id="txtnipkaprogdi" value="<?php echo($row[NIP_PROGDI]);?>" />
                      <label>Nama Kaprogdi</label>
                      <input class="form-control" name="txtnmkaprogdi" id="txtnmkaprogdi" value="<?php echo($row[KA_PROGDI]);?>" />
                      <label>Jenjang Progdi</label>
                      <select name="jenjang" class="form-control">
                      <option value="<?php if($_GET[venus]=="progdiedit"){ echo($row[JENJANG_PROGDI]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="progdiedit"){ echo($row[JENJANG_PROGDI]); }else{echo 'Silahkan Pilih'; }?></option>
                      <option value="D3">DIPLOMA 3</option>
                      <option value="D4">DIPLOMA 4</option>
                      <option value="S1">SARJANA</option>
                      <option value="S2">PASCA MAGISTER</option>
                      <option value="S3">PASCA DOKTOR</option>
                      </select>
                      <label>Status progdi</label>
                      <select name="aktifprogdi" class="form-control">                                            
                      <option value="<?php if($_GET[venus]=="progdiedit"){ echo($row[AKTIF_PROGDI]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="progdiedit"){ echo($row[AKTIF_PROGDI]); }else{echo 'Silahkan Pilih'; }?></option>
                      <option value="YA">YA</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-default">Ubah</button>
                    
                      <button type="reset" class="btn btn-primary">Reset</button>
                      </form>
              </div>
  </div>    
<?php
}
?>