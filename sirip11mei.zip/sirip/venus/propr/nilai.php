<?php
$aksi="venus/bidang/aksi_kriteria.php";

if(isset($_POST['smp'])){
$jump  = $_POST['jumc'];

$npt1  = $_POST['npt1'];
$npt2  = $_SESSION['USER_LOG'];

$kdlit = $_POST['kdlit'];
$komen  = $_POST['komentar'];
$dana  = $_POST['txtdana'];
//$poin  = $_POST['poin'];
$skim = 'RISDA';

//var_dump($_POST);
//echo $jump;
$nil = 0;
for ($i=0;$i<$jump; $i++){

//autonumber masuk perulangan	
  $query = "SELECT max(KD_NILAI) as maxKode FROM mn_nilai";
  $hasil = mysqli_query($GLOBALS,$query); 
  $data = mysqli_fetch_array($hasil); 
  $kodeBarang = $data['maxKode']; 
  $noUrut = (int) substr($kodeBarang, 1, 9); 
  $noUrut++; 
  $char="N";
  $newID = $char . sprintf("%09s", $noUrut);


	$kdk   = $_POST['kdk'.$i];
	$bobot = $_POST['bobot'.$i];
	//echo $_POST['kdk'.$i];
	$poin = $_POST['poin'.$i];
	//echo $_POST['kdk'.$i];
	$nil = ($bobot * $poin)/100;

//var_dump($_POST); 

$ins =("INSERT into mn_nilai (KD_NILAI,KD_KRITERIA,KD_LIT,SKOR,KOMENTAR,KD_REVIEWER,TGL_NILAI,SKIM_NILAI,USULAN_DANA) 
 values ('$newID','$kdk','$kdlit','$nil','$komen','$npt2',NOW(),'$skim','$dana')");
 if (mysqli_query($GLOBALS, $ins)) {

    header('location:../../sirip/nilai-'.$kdlit.'.html');
} else {
    echo "Error: " . $ins . "<br>" . mysqli_error($GLOBALS);
}
  

//echo "insert into mn_nilai values ('$i','$kdk','$nil','$komen','$npt1',NOW(),'$skim','$dana')";
}
 /*echo "$nil[0]<br>$nil[1]<br>$nil[2]<br>$nil[3]<br>";
echo "$kdk[0]<br>$kdk[1]<br>$kdk[2]<br>$kdk[3]<br>";
echo "$jump<br>$npt1<br>$kdlit<br>$dana<br>$komen-$poin-$f";*/

}//exit;

  // Tampil 
  if($_GET[venus] == "nilai"){
    $id = $_GET['id'];
    $quer = "select * from prop_lit a, m_subkat b where a.KD_SUBKAT=b.KD_SUBKAT and a.KD_LIT='$id'";
    $resq = mysqli_query($GLOBALS,$quer);
    $rsq = mysqli_fetch_array($resq);
    
    $kdskim = $rsq['KD_SUBKAT'];
    $singkat = $rsq['NM_SINGKAT'];

   /* $sql2 = mysqli_query($GLOBALS,"select * from m_reviewer a, set_reviewer b where a.KD_SETR=b.KD_SETR and a.KD_LIT='$id'");
    $rsq2 = mysqli_fetch_array($sql2);

    $nptrev1 = $rsq2['KD_SETR'];
    $nptrev2 = $rsq2['NPT_REVIEWER2']; */

    $sql3 = mysqli_query($GLOBALS,"select * from set_reviewer where NPT='$nptku'");
    $rsq3 = mysqli_fetch_array($sql3);
    $nptrev1 = $rsq3['KD_SETR'];

   $que = "select * from mn_kriteria where SKIM_KRITERIA='$singkat'";
	 $result=mysqli_query($GLOBALS,$que);
	 $jumrows = mysqli_num_rows($result);
?>

	<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>Kriteria Penilaian <?php echo "$rsq[JDL_PROPOSAL] ($singkat)"; ?></div>
					<div class="panel-body">
         
          <div class="alert alert-info" align="center">
  <strong>PERHATIAN !!!</strong> Untuk mengisi Nilai ini Sifatnya Hanya SEKALI/SATU KALI Pengisian Nilai, Setelah <b>Reviewer</b> melakukan Klik Tombol SIMPAN Maka NILAI TIDAK AKAN BISA dirubah kembali. <br>
            Jika Ingin Merubah Bisa Langsung ke LPPM UPN V Jawa Timur
</div><br />
          <form action="" method="POST" enctype="multipart/form-data">
          
           <input type="hidden" name="npt1" id="npt1" value="<?php echo $nptrev1; ?>">
            <input type="hidden" name="kdlit" id="kdlit" value="<?php echo $rsq[KD_LIT]; ?>">
					<table data-toggle="table"> 
        <thead>
            <tr>
                <th data-sortable="true">Kode Kriteria</th>
                <th data-sortable="true">Kriteria</th>
              <!--  <th data-sortable="true">Skim</th> <th data-sortable="true">Nilai</th>-->
                <th data-sortable="true">Bobot</th>
                <th data-sortable="true">Poin</th>
            </tr>
        </thead>
       
		<?php
		$iCnt=0;
		if ($jumrows>0) { 
			while ($row = mysqli_fetch_array($result)) {
     
      $ex = explode('-',$row[NM_KRITERIA]);
      $exc = count($ex);
      
    ?>
    

    <tr <?php if ($iCnt%2==0) {?>class="odd gradeX" <?php } else {?>class="even gradeC"<?php }?> >
      <td>
        <input hidden="hidden" name="kdk<?php echo $iCnt; ?>" value="<?php echo $row[KD_KRITERIA]; ?>">
      <?php echo strip_tags(strtoupper($row[KD_KRITERIA])); ?></td>
      <td><b><?php echo strip_tags(strtoupper($row[SUB_KRITERIA]));?></b><br><?php
for($e=0;$e < $exc;$e++){
        echo "$ex[$e]<br>";
        //echo "beda bung<br>aa<br>--";
      }

            //echo strip_tags(strtoupper($row[NM_KRITERIA])); ?></td>
        <!--    <td><?php echo strip_tags(strtoupper($row[SKIM_KRITERIA])); ?></td> <td><input type="numeric" name="nilaix[$iCnt]" id="nilaix[$iCnt]" value="" size="2" onfocus="startCalculate()" onblur="stopCalc()"></td> <input type="numeric" name="poin[$iCnt]" id="poin[$iCnt]" value="" size="2" onfocus="startCalculate()" onblur="stopCalc()">-->
            <td><?php echo strip_tags(strtoupper($row[BOBOT_KRITERIA])); ?> %
            <input hidden="hidden" name="bobot<?php echo $iCnt; ?>" value="<?php echo $row[BOBOT_KRITERIA]; ?>" size="2" onfocus="startCalculate()" onblur="stopCalc()"></td>
            <td><select name="poin<?php echo $iCnt; ?>">
              <option value="--">- Poin Penilaian -</option>
              <option value="1">- 1 [SATU] -</option>
              <option value="2">- 2 [DUA]-</option>
              <option value="3">- 3 [TIGA]-</option>
              <option value="4">- 4 [EMPAT]-</option>
              <option value="5">- 5 [LIMA]-</option>
              <option value="6">- 6 [ENAM]-</option>
              <option value="7">- 7 [TUJUH]-</option>
            </select></td>            
		  </tr>
		<?php  $iCnt++; //$jumc = $iCnt-1;
			}  
     
      //echo $jumMhs; ?>

    <?php
		} else{
		?>
		<tr>
			<td colspan="6">Data tidak di temukan</td>
		</tr>
		<?php
		}  
		?>
    <tr ><td>Komentar <br>
    </td>
    <td><textarea name="komentar" cols="60" rows="6" required="required"></textarea></td>
    <td>
    <tr><td>Usulan Dana</td><td>
    <div class="form-group has-warning">
									
    <input type="text" name="txtdana" id="txtdana" class="form-control" required="required" onkeypress='return isNumberKeyTrue(event)' onPaste='false' onkeyup="document.getElementById('format').innerHTML = formatCurrency(this.value);"/><span  id="format"></span>
    </div></td></tr>
    <tr><td></td><td>
<div id='KS_Box'>
<div id='KS_Pernyataan'><input id="KS_Setuju" type='checkbox' onclick='KS_OKE();'/> Centang disamping Apabila sudah Yakin Untuk Menyimpan</div><br>
<span class='KS_ButtonGo'>
<input type="submit" name='smp' value="SIMPAN">
<input type="submit" name="preview" value="PREVIEW">
</div>  
</td><td></td>
<td><?php echo "<input type='text' size=1 name='jumc' value='$iCnt' readonly='yes'>"; ?></td></tr>
	</table>
  
  </form>
    </div>
    </div>
    </div>
    </div>
	<?php
  }
