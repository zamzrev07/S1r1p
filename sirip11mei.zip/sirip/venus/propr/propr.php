<script language="javascript" src="minerva/ezpl.js"></script>
<link rel="stylesheet" type="text/css" href="css/pop.css"/>  
<script>
function publishdata(urltujuan){
    el=$(this);
    if(confirm("Apakah Yakin Akan Mempublish Reviewer ?."))
    {
            alert("Berhasil Terpublish");
            
            window.location = (urltujuan);
        }
        else{
            alert("Gagal");
        }
}
</script>
            
<?php
include "../../config/koneksi.php";
$aksi="venus/propr/";

if($_GET['venus']=='publishx'){ //echo "aaa"; exit;
$pub = $_GET['id'];
$sid_baru = session_id();

$ambil = "Select * from m_reviewer where KD_REVIEWER='$pub'";
$result=mysqli_query($GLOBALS,$ambil);
$rww = mysqli_fetch_array($result); $kdlit = $rww['KD_LIT'];

$sqlp = "UPDATE m_reviewer SET STA_REV='PUBLISH' WHERE KD_REVIEWER='$pub'";

$sqlit = "UPDATE prop_lit SET STATUS_PROPOSAL='PAPARAN' WHERE KD_LIT='$kdlit'";

//echo "$sqlp - $sqlit"; exit;

$result=mysqli_query($GLOBALS,$sqlp);
$result2=mysqli_query($GLOBALS,$sqlit);
header('location:prev.html');
}

  // Tampil Agenda
  if($_GET[venus] == "propr"){
  $kdset  = "select * from  set_reviewer where NPT='$nptku'";
  $res    = mysqli_query($GLOBALS,$kdset);
  $rowset = mysqli_fetch_array($res);
  $kdsetr = $rowset['KD_SETR'];
  $numd = mysqli_num_rows($res);
  //echo $kdsetr;

if($kdsetr != 'empty'){ //echo "aaa"; 
  $que = "select * from prop_lit a, m_reviewer b, m_dosen c, set_reviewer d 
            where a.KD_LIT = b.KD_LIT and a.NPT = c.NPT and b.KD_SETR = d.KD_SETR and d.NPT = $nptku and a.STATUS_PROPOSAL='PAPARAN' and b.STA_REV='PUBLISH' ";
  $sqll = mysqli_query($GLOBALS,$que); 
  $num1 = mysqli_num_rows($sqll); 
  if($num1 == 0){ 
    $que = "select * from prop_lit a, m_reviewer b, m_dosen c, set_reviewer d 
            where a.KD_LIT = b.KD_LIT and a.NPT = c.NPT and b.NPT_REVIEWER2 = d.KD_SETR and d.NPT = $nptku and a.STATUS_PROPOSAL='PAPARAN' and b.STA_REV='PUBLISH' ";
    $sqll = mysqli_query($GLOBALS,$que);
  } 
} //echo $que;
 

/*  $que = "select prop_lit.KD_LIT, 
  prop_lit.NPT, 
  m_dosen.NM_DOSEN, 
  m_progdi.NM_PROGDI, 
  m_subkat.NM_SUBKAT, 
  prop_lit.JDL_PROPOSAL, 
  m_tahun.KD_THN,m_dosen.NIDN,prop_lit.STATUS_PROPOSAL,prop_lit.UNGGAH_PROPOSAL,prop_lit.BATCH_LIT,prop_lit.DANA_LIT
  from prop_lit inner join m_dosen on prop_lit.NPT=m_dosen.NPT inner join m_progdi on m_dosen.KD_PROGDI=m_progdi.KD_PROGDI inner join m_subkat on prop_lit.KD_SUBKAT=m_subkat.KD_SUBKAT inner join m_tahun on prop_lit.KD_THN=m_tahun.KD_THN where m_tahun.KD_THN='$kd_thn'"; 
  $result=mysqli_query($GLOBALS,$que);
  $jumrows = mysqli_num_rows($result);*/


?>
    
  <div class="row">
      <div class="col-lg-12">
        <div class="panel panel-default">
          <div class="panel-heading"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>Data Proposal</div>
          <div class="panel-body">
                    <?php 
    //        menampilkan pesan jika ada pesan
            if (($_SESSION['pesan']) && $_SESSION['pesan'] <> '') {
                echo '<div class="alert bg-danger" role="alert">'.$_SESSION['pesan'].'<button type="button" class="close" data-dismiss="alert">×</button></div>';
            }

    //        mengatur session pesan menjadi kosong
            $_SESSION['pesan'] = '';
            ?> 
          <div id="areaku"><i> (*) NOTE : <br><b>1 = Plotting Reviewer - 2 = Penilaian Proposal - <br>3 = Detail Proposal - 4 = Ubah Reviewer - <br>5 = Publish Reviewer ke Peserta </b></i></div>
          <table data-toggle="table" data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
        <thead>
            <tr>
                <th data-sortable="true">NO</th>
                <th data-sortable="true">DOSEN PENGUSUL</th>
                <th data-sortable="true">SKIM</th>
                <th data-sortable="true">JUDUL PROPOSAL</th>
        <th data-sortable="true">REVIEWER</th>
        <th data-sortable="true">STATUS</th>
                <!--<th data-sortable="true">UNDUH BERKAS</th>-->
                <th>Aksi (*)</th>
            </tr>
        </thead>
        <tbody>
    <?php
    $iCnt=0; //echo $kdsetr;echo "asa"; 
    if ($kdsetr != 'empty') { 
      while ($row = mysqli_fetch_array($sqll)) {
        $uu = "sirip/$row[UNGGAH_PROPOSAL]";
        $iCnt++; 
        
    ?>
        
      <tr <?php if ($iCnt%2==0) {?>class="odd gradeX" <?php } else {?>class="even gradeC"<?php }?> >
          <!--<td><?php echo strip_tags(strtoupper($row[0])); ?></td>-->
      <td><?php echo $iCnt; ?></td>
      <td>Penulis 1 <br> (<?php echo strip_tags(strtoupper($row[1])); ?> / <?php echo strip_tags(strtoupper($row[NIDN])); ?>)
      <?php echo strip_tags(strtoupper($row[2]));?><br>
Penulis 2 <br> <?php 
$que2 = "select prop_lit.KD_LIT, 
  prop_lit.NPT_ANGGOTA2, 
  m_dosen.NM_DOSEN, 
  m_progdi.NM_PROGDI, 
  m_subkat.NM_SUBKAT, 
  prop_lit.JDL_PROPOSAL, 
  m_tahun.KD_THN,m_dosen.NIDN,prop_lit.STATUS_PROPOSAL,prop_lit.BATCH_LIT,prop_lit.DANA_LIT
  from prop_lit inner join m_dosen on prop_lit.NPT_ANGGOTA2=m_dosen.NPT inner join m_progdi on m_dosen.KD_PROGDI=m_progdi.KD_PROGDI inner join m_subkat on prop_lit.KD_SUBKAT=m_subkat.KD_SUBKAT inner join m_tahun on prop_lit.KD_THN=m_tahun.KD_THN where m_tahun.KD_THN='$kd_thn' and prop_lit.KD_LIT='$row[0]'";
  $result2=mysqli_query($GLOBALS,$que2);
  $row2=mysqli_fetch_array($result2);?>
(<?php echo strip_tags(strtoupper($row2[1])); ?> / <?php echo strip_tags(strtoupper($row2[NIDN])); ?>) <?php echo strip_tags(strtoupper($row2[NM_DOSEN]));?><br>
Penulis 3 <br> <?php 
$que3 = "select prop_lit.KD_LIT 
  prop_lit.NPT_ANGGOTA3, 
  m_dosen.NM_DOSEN, 
  m_progdi.NM_PROGDI, 
  m_subkat.NM_SUBKAT, 
  prop_lit.JDL_PROPOSAL, 
  m_tahun.KD_THN,m_dosen.NIDN,prop_lit.STATUS_PROPOSAL,prop_lit.BATCH_LIT
  from prop_lit inner join m_dosen on prop_lit.NPT_ANGGOTA3=m_dosen.NPT inner join m_progdi on m_dosen.KD_PROGDI=m_progdi.KD_PROGDI inner join m_subkat on prop_lit.KD_SUBKAT=m_subkat.KD_SUBKAT inner join m_tahun on prop_lit.KD_THN=m_tahun.KD_THN where m_tahun.KD_THN='$kd_thn' and prop_lit.KD_LIT='$row[0]'";
  $result3=mysqli_query($GLOBALS,$que3);
  $row3=mysqli_fetch_array($result3); ?>
(<?php echo strip_tags(strtoupper($row3[1])); ?> / <?php echo strip_tags(strtoupper($row3[NIDN])); ?>)<?php echo strip_tags(strtoupper($row3[NM_DOSEN]));?></td>
            <td><?php echo strip_tags(strtoupper($row[4])); ?><br><?php echo strip_tags(strtoupper($row[BATCH_LIT])); ?><br><?php echo buatrp($row[DANA_LIT]); ?></td>
          <td><?php echo strip_tags(strtoupper($row[5])); ?></td> 
            <td><?php 
            $rev1 = "select * from m_reviewer a, prop_lit b, m_dosen c, set_reviewer d 
            where a.KD_SETR=d.KD_SETR and d.NPT=c.NPT and a.KD_LIT=b.KD_LIT and b.KD_LIT='$row[0]'";
  $res1=mysqli_query($GLOBALS,$rev1);
  $rw1=mysqli_fetch_array($res1);
  if($nptku == $rw1[NPT]){ 
            $warna = "<p style='background-color:yellow'>";
          } 
  echo "$warna <B><u>Reviwer 1</b></u><br> $rw1[NM_DOSEN] </p><br>";
             ?>
             <?php 
            $rev2 = "select * from m_reviewer a, prop_lit b, m_dosen c, set_reviewer d where a.NPT_REVIEWER2=d.KD_SETR and d.NPT = c.NPT and a.KD_LIT=b.KD_LIT and b.KD_LIT='$row[0]'"; 
  $res2=mysqli_query($GLOBALS,$rev2);
  $rw2=mysqli_fetch_array($res2);
   if($nptku == $rw2[NPT]){ 
            $warna2 = "<p style='background-color:yellow'>";
          }  
  echo "$warna2 <B><u>Reviwer 2</b></u><br> $rw2[NM_DOSEN]</p><br>Status Reviewer : $rw1[STA_REV]";
             ?></td>
<td><?php echo strip_tags(strtoupper($row[STATUS_PROPOSAL])); ?><br>
</td>
 <!-- <td><center><a href="#" onclick='window.open("sirip/<?php echo $uu ?>")' target='_blank'><img src="img/pdfdown.gif" width='40'></a></center></td>-->
           
            <td>
            <a data-toggle="tooltip" data-placement="top" title="edit" href="<?php echo("nilai-$row[KD_LIT].html")?>"><button class="btn btn-sm btn-info" title="PENILAIAN PROPOSAL">Nilai</button></a>
            </td>  
      </tr>
    <?php
//Note : 1 = Plotting, 2 = Penilaian, 3 = Detail , 4 = Ubah Reviewer, 5 = Publish Reviewer 
      }
    }else{
    ?>
    <tr>
      <td colspan="6"><div class="alert bg-danger" role="alert">
          <svg class="glyph stroked cancel"><use xlink:href="#stroked-cancel"></use></svg> Data Tidak Ditemukan !!! <a href="#" class="pull-right"><span class="glyphicon glyphicon-remove"></span></a>
        </div></td>
    </tr>
        
    <?php
    }
    ?>
        </tbody>
  </table>
  <div id="areaku"><i> (*) NOTE : <br><b>1 = Plotting Reviewer - 2 = Penilaian Proposal - <br>3 = Detail Proposal - 4 = Ubah Reviewer - <br>5 = Publish Reviewer ke Peserta </b></i></div>
     <!-- untuk detail pop up -->
  <div class="popup-wrapper" id="popup">
  <div class="popup-container">
   
    
    <a class="popup-close" href="#closed">X</a>
  </div>
</div> <!-- end pop up detail -->
    </div>
    </div>
    </div>
    </div>
  <?php
  }
elseif($_GET[venus]=="plotrev"){
$query = "SELECT max(KD_REVIEWER) as maxKode FROM m_reviewer";
   $hasil = mysqli_query($GLOBALS,$query); 
  $data = mysqli_fetch_array($hasil); 
  $kodeBarang = $data['maxKode']; 
   $noUrut = (int) substr($kodeBarang, 2, 5); 
   $noUrut++; 
   $char="PL";
    $newID = $char . sprintf("%05s", $noUrut);
  
$que = "select * from prop_lit a, m_dosen b, m_progdi c, m_subkat d, m_tahun e where a.NPT=b.NPT and b.KD_PROGDI=c.KD_PROGDI and a.KD_SUBKAT=d.KD_SUBKAT and a.KD_THN=e.KD_THN and a.KD_LIT='$_GET[id]'";
    $result=mysqli_query($GLOBALS,$que);  
    $row = mysqli_fetch_array($result);
  $xx= "$row[KD_SUBKAT]";
  $ketua    = $row['NPT'];
  $anggota1 = $row['NPT_ANGGOTA2'];
  $anggota2 = $row['NPT_ANGGOTA3'];
?>
  
  <div class="panel panel-default">
          <div class="panel-heading">
             <svg class="glyph stroked plus sign"><use xlink:href="#stroked-plus-sign"/></svg> Ploting Reviewer Skim <?php echo "$row[NM_SUBKAT]"; ?>
          </div>
              <div class="panel-body">
                <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=plotrev&act=input"?>" method="post" enctype="multipart/form-data">
                   <label>KD PLOTING</label>
                      <input class="form-control" name="txtkdp" id="txtkdp" value="<?php echo $newID; ?>" readonly/>
                     <input class="form-control" name="txtthn" type="hidden" value="<?php echo $kd_thn; ?>" readonly/>
                  <label>KD PROPOSAL</label>
                      <input class="form-control" name="txtkdprop" id="txtkdprop" value="<?php echo ($_GET[id]); ?>" readonly />
                       <label>JUDUL PROPOSAL</label>
                      <input class="form-control" name="txtjdlp" id="txtjdlp" value="<?php echo($row[JDL_PROPOSAL]); ?>" readonly />
                    <label>DOSEN REVIEWER 1</label>
          <select name="ds1" class="form-control" >
                    <?php 
$quer = "select * from set_reviewer a, m_dosen b, m_subkat c where a.NPT=b.NPT and a.KD_SUBKAT=c.KD_SUBKAT and a.KD_SUBKAT='$row[KD_SUBKAT]' and a.NPT !='$ketua' and a.NPT !='$anggota1' and a.NPT !='$anggota2'";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                    <option value="<?php echo $rot['KD_SETR']; ?>"><?php echo strtoupper($rot['NM_DOSEN']); ?></option> <?php } ?>
          </select>
                   <label>DOSEN REVIEWER 2</label>
          <select name="ds2" class="form-control" >
                    <?php 
                    
$quer = "select * from set_reviewer a, m_dosen b, m_subkat c where a.NPT=b.NPT and a.KD_SUBKAT=c.KD_SUBKAT and a.KD_SUBKAT='$row[KD_SUBKAT]' and a.NPT !='$ketua' and a.NPT !='$anggota1' and a.NPT !='$anggota2'";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                    <option value="<?php echo $rot['KD_SETR']; ?>"><?php echo strtoupper($rot['NM_DOSEN']); ?></option> <?php } ?>
          </select>

                     
                     <label>Aktif Reviewer</label>
                      <select name="aktif" class="form-control">
                      <option value="AKTIF">AKTIF</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>
                      
         
                     
                  <p>&nbsp;</p>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                      
                      <button type="reset" class="btn btn-default">Reset</button> 
                      <a href="prev.html" title="Kembali"> [ Kembali ] </a> 

                  </form>
              </div>
    </div>  
<?php
}
elseif($_GET[venus]=="dosenedit"){
    $que = "select * from m_dosen a, m_progdi b, m_rumpun c,m_kepakaran d, m_jafa e where a.KD_JAFA=e.KD_JAFA and a.KD_PROGDI=b.KD_PROGDI and a.KD_RUMPUN=c.KD_RUMPUN and a.KD_PAKAR=d.KD_PAKAR and a.NPT='$_GET[id]'";
    $result=mysqli_query($GLOBALS,$que);  
    $row = mysqli_fetch_array($result);
?>
  
  <div class="panel panel-default">
          <div class="panel-heading">
               <svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"/></svg>Ubah Data Master Dosen
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=dosen&act=edit"?>" method="post" enctype="multipart/form-data">
                      <label>NPT</label>
                      <input class="form-control" name="txtnpt" id="txtnpt" value="<?php echo($_GET[id]); ?>"/>
                      <label>Progdi</label>
                      <select name="prog" class="form-control">
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[KD_PROGDI]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo strtoupper($row[NM_PROGDI]); }else{echo 'Silahkan Pilih'; }?></option>
                      <?php 
$quer = "select * from m_progdi ";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_PROGDI']; ?>"><?php echo strtoupper($rot['NM_PROGDI']); ?></option> <?php } ?>
                      </select>

                      <label>Jabatan Fungsional</label>
                      <select name="jafa" class="form-control">
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[KD_JAFA]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo strtoupper($row[NM_JAFA]); }else{echo 'Silahkan Pilih'; }?></option>
                      <?php 
$quer = "select * from m_jafa ";
$resultt=mysqli_query($GLOBALS,$quer);
while ($rot = mysqli_fetch_array($resultt)) { ?>                      
                      <option value="<?php echo $rot['KD_JAFA']; ?>"><?php echo strtoupper($rot['NM_JAFA']); ?></option> <?php } ?>
                      </select>

                     <label>Rumpun</label>
                      <select name="rumpun" class="form-control">
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[KD_RUMPUN]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo strtoupper($row[NM_RUMPUN]); }else{echo 'Silahkan Pilih'; }?></option>
                      <?php 
$querp = "select * from m_rumpun ";
$resultp=mysqli_query($GLOBALS,$querp);
while ($rotp = mysqli_fetch_array($resultp)) { ?>                      
                      <option value="<?php echo $rotp['KD_RUMPUN']; ?>"><?php echo strtoupper($rotp['NM_RUMPUN']); ?></option> <?php } ?>
                      </select>
                      <label>Pakar</label>
                      <select name="pakar" class="form-control">
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[KD_PAKAR]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo strtoupper($row[NM_PAKAR]); }else{echo 'Silahkan Pilih'; }?></option>
                      <?php 
$querpk = "select * from m_kepakaran ";
$resultpk=mysqli_query($GLOBALS,$querpk);
while ($rotpk = mysqli_fetch_array($resultpk)) { ?>                      
                      <option value="<?php echo $rotpk['KD_PAKAR']; ?>"><?php echo strtoupper($rotpk['NM_PAKAR']); ?></option> <?php } ?>
                      </select>
                      <label>NIDN</label>
                      <input class="form-control" name="txtnidn" id="txtnidn" value="<?php echo($row[NIDN]);?>" />
                       <label>Nama Dosen</label>
                      <input class="form-control" name="txtnamdos" id="txtnamdos" value="<?php echo($row[NM_DOSEN]);?>" />
                      
                      <label>Jenis Kelamin</label>
                      <select name="jk" class="form-control">
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[JK_DOSEN]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo($row[JK_DOSEN]); }else{echo 'Silahkan Pilih'; }?></option>
                      <option value="L">Laki-Laki</option>
                      <option value="P">Perempuan</option>
                      </select>

<label>Pendidikan</label>
                      <select name="pend" class="form-control">
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[PENDIDIKAN]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo($row[PENDIDIKAN]); }else{echo 'Silahkan Pilih'; }?></option>
                      <option value="S-1">S1 (SARJANA)</option>
                      <option value="S-2">S2 (PASCA SARJANA MAGISTER)</option>
<option value="S-3">S3 (PASCA SARJANA DOKTOR)</option>
                      </select>

                       <label>Email</label>
                      <input class="form-control" name="txtemail" id="txtemail" value="<?php echo($row[EMAIL_DOSEN]);?>" />
                       <label>Jabatan Akademik</label>
                      <input class="form-control" name="txtjab" id="txtjab" value="<?php echo($row[JAB_AKADEMIK]);?>" />
                      <label>Status Dosen</label>
                      <select name="aktifdosen" class="form-control">                                            
                      <option value="<?php if($_GET[venus]=="dosenedit"){ echo($row[AKTIF_DOSEN]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="dosenedit"){ echo($row[AKTIF_DOSEN]); }else{echo 'Silahkan Pilih'; }?></option>
                      <option value="YA">YA</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-default">Ubah</button>
                    
                      <button type="reset" class="btn btn-primary">Reset</button>
                      </form>
              </div>
  </div>    
<?php
}
?>