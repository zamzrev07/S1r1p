<?php session_start();
include "../../config/koneksi.php"; 
  $stat = $_SESSION['STA_LOG'];
  $nptku = $_SESSION['USER_LOG'];

$dos 	= "select * from m_dosen a, m_progdi b where a.KD_PROGDI=b.KD_PROGDI and a.NPT = '$nptku' ";
$resdos = mysqli_query($GLOBALS,$dos);
$rod 	= mysqli_fetch_array($resdos);

$kdbidang = $rod['KD_BIDANG'];

//OR KD_BIDANG='BD00004'
$wew=$_POST['id'];
if ($_GET['cmd'] == "cek") {
if($stat == '1'){
$que = "select KD_SUBKAT,NM_SUBKAT,NM_SKIM,NM_SINGKAT from m_subkat where KD_KAT='$wew'";}
elseif($stat == '2'){ 
if($wew == 'KK0001'){
$que = "select KD_SUBKAT,NM_SUBKAT,NM_SKIM,NM_SINGKAT from m_subkat where KD_KAT='$wew' and KD_BIDANG = '$kdbidang'"; }
if($wew == 'KK0002'){
$que = "select KD_SUBKAT,NM_SUBKAT,NM_SKIM,NM_SINGKAT from m_subkat where KD_KAT='$wew' AND KD_BIDANG='BD00004'"; }
}
$sql = mysqli_query($GLOBALS,$que);
if($stat == '1'){
echo "<option value=>--Silahkan Pilih Skim--</option>";
while($r =mysqli_fetch_array($sql)){
echo "<option value=$r[0]>$r[1]</option>";
	}; }

if($stat == '2'){
echo "<option value=>--Silahkan Pilih Skim--</option>";
while($r =mysqli_fetch_array($sql)){
echo "<option value=$r[0]>$r[2]</option>";
	}; }
}
?>