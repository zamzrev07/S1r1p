<?php
// panggil file koneksi.php
include "../../config/koneksi.php";
// buat koneksi ke database mysql


// tangkap variabel kd_mhs
$kd_m = $_POST['id'];

// query untuk menampilkan kd_mh
 $data = "select * from prop_lit a, m_tahun b where a.KD_THN=b.KD_THN and a.KD_LIT='$kd_m'";
    $result=mysqli_query($GLOBALS,$data);  
    $row = mysqli_fetch_array($result);
	$rss =mysqli_num_rows($result);


// jika kd_m > 0 / form ubah data
if($rss > 0) { 
	$one = $row[JDL_PROPOSAL];
	$two = $row[ABSTRAK_TEXT];
	$three = $row[NM_TAHUN];
	$four = $row[KET_THN];
	$jod = $three.$four;

//form tambah data
} else {
 echo "error";
}

?>
<form class="form-horizontal" id="form-mahasiswa">
	 <div class="form-group">
									<label>JUDUL PENELITIAN</label>
									<textarea name="txtjdlp" class="form-control" rows="3" required="required"><?php echo $one ?></textarea>
                      </div>
     <div class="form-group">
									<label>ABSTRAK</label>
									<textarea name="txtjdlp" class="form-control" rows="3" required="required"><?php echo $two ?></textarea>
                      </div>
                      <label>TAHUN PENELITIAN</label>
                      <input type="text" class="form-control" name="txtpnls1" id="txtpnls1" readonly="readonly" value="<?php echo $jod ?>" />
    <br />
</form>
<a class="popup-close" href="#closed">X</a>
<?php
// tutup koneksi ke database mysql

?>
