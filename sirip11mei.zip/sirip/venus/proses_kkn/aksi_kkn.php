<?php session_start();

include "../../config/koneksi.php";
$module=$_GET['venus'];
$act=$_GET['act'];

$sid_lama = session_id();
	
session_regenerate_id();

$sid_baru = session_id();
$tanggal = date("Y-m-d");

if($module=='kkn' AND $act=='input'){
  $kdkn  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdkn'],ENT_QUOTES))); 
  $npm  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnpm'],ENT_QUOTES))); 
  

  $sql =("INSERT INTO prop_kkn
  (KD_KKN,NPM,WKT_KKN) 
  VALUES  ('$kdkn','$npm','$tanggal')");

 if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../dftrkkn.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
  
 
}
elseif($module=='fakultas' AND $act=='edit'){

  $kdfak  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdlog'],ENT_QUOTES))); 
  $nmfak  = stripslashes(strip_tags(htmlspecialchars($_POST['txtusername'],ENT_QUOTES))); 
  $nipdekan = stripslashes(strip_tags(htmlspecialchars($_POST['txtnipdekan'],ENT_QUOTES))); 
  $nmdekan  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnmdekan'],ENT_QUOTES))); 
  $aktifak = $_POST['aktifak']; 

   $sql=("UPDATE m_fakultas SET NM_FAK    = '$nmfak', NIP_DEKAN    = '$nipdekan',NM_DEKAN    = '$nmdekan',
								 AKTIF_FAK = '$aktifak' WHERE KD_FAK   = '$kdfak'");
if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../fakultas.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
}/*
elseif($module=='users' AND $act=='delete'){
    mysql_query("DELETE FROM fakultas WHERE kd_fakultas = '$_REQUEST[sid]'");
    header('location:../../fakultas.html');
}*/
?>