<?php  
header('content-type:text/xml');   
if($_SERVER["SERVER_PROTOCOL"]=="HTTP/1.0")  
    header("Pragma: no-cache");  
else  
    header("Cache-Control: no-cache, must-revalidate");  
$kode   =$_GET['kode'];  
$jumlah =$_GET['jumlah'];  
session_start();

include "../../config/koneksi.php"; 


$que ="select m_mhs.NPM,
m_mhs.NM_MHS,
m_progdi.KD_PROGDI,
m_progdi.NM_PROGDI from m_mhs inner join m_progdi on m_mhs.kd_progdi=m_progdi.kd_progdi where m_mhs.npm='$kode'";
$sql = mysqli_query($GLOBALS,$que);
$r =mysqli_fetch_array($sql);
/*********=---Proses--=***********/  
//Disini anda bisa mencari data dari mysql, untuk source code  
//silahkan anda kembangkan sendiri. OK.  
//$nama   = "Namaku";  
//$alamat = "Alamatku";  
//$kota   = "Kotaku";  
//$tanggal= "Tanggal"; 

$mhsn = $r[1]; 
$jurs  = $r[3];  
/********************************************************/  
echo"  
     <data>  
         <mhsname>".$mhsn."</mhsname>  
         <jur>".$jurs."</jur>  
     </data>  
";  
?>  
