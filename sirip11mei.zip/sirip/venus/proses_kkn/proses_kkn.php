<script src="minerva/ajaxkk.js"></script>   
<?php

$aksi="venus/proses_kkn/aksi_kkn.php";

  // Tampil Agenda
  if($_GET[venus] == "dftrkkn"){
    $que = "select prop_kkn.KD_KKN, 
	prop_kkn.NPM, 
	m_mhs.NM_MHS,
	 m_progdi.NM_PROGDI, 
	 m_fakultas.NM_FAK 
	from prop_kkn inner join m_mhs on prop_kkn.NPM=m_mhs.NPM 
	inner join m_progdi on m_mhs.KD_PROGDI=m_progdi.KD_PROGDI 
	inner join m_fakultas on m_progdi.KD_FAK=m_fakultas.KD_FAK";
	$result=mysqli_query($GLOBALS,$que);
	$jumrows = mysqli_num_rows($result);
?>
<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>Data Peserta KKN</div>
					<div class="panel-body">
                    <?php 
    //        menampilkan pesan jika ada pesan
            if (($_SESSION['pesan']) && $_SESSION['pesan'] <> '') {
                echo '<div class="alert bg-danger" role="alert">'.$_SESSION['pesan'].'<button type="button" class="close" data-dismiss="alert">×</button></div>';
            }

    //        mengatur session pesan menjadi kosong
            $_SESSION['pesan'] = '';
            ?> 
                    <a href="kknadd.html" class="btn btn-primary">Tambah Data Peserta KKN</a>
					<table data-toggle="table" data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
        <thead>
            <tr>
                <th hidden="true">KD_KKN</th>
                <th data-sortable="true">NPM</th>
                <th data-sortable="true">NAMA MAHASISWA</th>
                <th data-sortable="true">JURUSAN</th>
                <th data-sortable="true">FAKULTAS</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
		<?php
		$iCnt=0;
		if ($jumrows>0) { 
			while ($row = mysqli_fetch_array($result)) {
        $iCnt++;
		?>
        
		  <tr <?php if ($iCnt%2==0) {?>class="odd gradeX" <?php } else {?>class="even gradeC"<?php }?> >
      <td hidden="true"><?php echo strip_tags(strtoupper($row[0])); ?></td>
		
            <td><?php echo strip_tags(strtoupper($row[1])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[2])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[3])); ?></td>
            <td><?php echo strip_tags(strtoupper($row[4])); ?></td>
     
            <td><a data-toggle="tooltip" data-placement="top" title="edit" href="<?php echo("kknedit-$row[0].html")?>" class="btn btn-sm btn-warning">Edit</a></td>  
		  </tr>
		<?php
			}
		}else{
		?>
		<tr>
			<td><div class="alert alert-danger" role="alert">
					<svg class="glyph stroked cancel"><use xlink:href="#stroked-cancel"></use></svg> <strong>Data</strong> Tidak Ditemukan !!! <a href="#" class="pull-right"><span class="glyphicon glyphicon-remove"></span></a>
				</div></td>
		</tr>
        
		<?php
		}
		?>
        </tbody>
	</table>
    </div>
    </div>
    </div>
    </div>
	<?php
  }
elseif($_GET[venus]=="kknadd"){
	 $query = "SELECT max(KD_KKN) as maxKode FROM prop_kkn";
   $hasil = mysqli_query($GLOBALS,$query); 
  $data = mysqli_fetch_array($hasil); 
  $kodeBarang = $data['maxKode']; 
   $noUrut = (int) substr($kodeBarang, 1, 5); 
   $noUrut++; 
   $char="KKN";
    $newID = $char . sprintf("%05s", $noUrut);	

?>
 <div class="panel panel-default">
          <div class="panel-heading">
             <svg class="glyph stroked plus sign"><use xlink:href="#stroked-plus-sign"/></svg> Tambah Data Peserta KKN
          </div>
              <div class="panel-body">
                  <form name="myForm" id="mainform" action="<?php echo"$aksi?venus=kkn&act=input"?>" method="post" enctype="multipart/form-data">
                   <label>KD_KKN</label>
                      <input class="form-control" name="txtkdkn" id="txtkdkn" value="<?php echo $newID ?>" readonly="readonly"/>
                   <label>NPM</label>
                      <input type="text" class="form-control" name="txtnpm" id="txtnpm" 
                      onkeyup     ="tampilkan_data(this.value,mainform.txtnpm.value);"/>
                     
                      
                    
                      <label>Nama Mahasiswa</label>
                      <input type="text" class="form-control" name="txtmhsname" id="txtmhsname" readonly="readonly" />
                     
                    <label>Jurusan</label>
                      <input type="text" class="form-control" name="txtjur" id="txtjur"  readonly="readonly"/>
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                      
                      <button type="reset" class="btn btn-default">Reset</button>

                  </form>
              </div>
    </div>  

<?php
  };
  ?>