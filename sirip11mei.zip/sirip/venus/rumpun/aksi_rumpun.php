<?php session_start();

include "../../config/koneksi.php";
$module=$_GET['venus'];
$act=$_GET['act'];

$sid_lama = session_id();
	
session_regenerate_id();

$sid_baru = session_id();

if($module=='rumpun' AND $act=='input'){
  $kdkel  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdlog'],ENT_QUOTES))); 
  $nmkel  = stripslashes(strip_tags(htmlspecialchars($_POST['txtusername'],ENT_QUOTES))); 

  $sql =("INSERT INTO m_rumpun
  (KD_RUMPUN, NM_RUMPUN) 
  VALUES  ('$kdkel','$nmkel')");

 if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../rumpun.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
  
 
}
elseif($module=='rumpun' AND $act=='edit'){

  $kdkel  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdlog'],ENT_QUOTES))); 
  $nmkel  = stripslashes(strip_tags(htmlspecialchars($_POST['txtusername'],ENT_QUOTES))); 

   $sql=("UPDATE m_rumpun SET NM_RUMPUN    = '$nmkel' WHERE KD_RUMPUN   = '$kdkel'");
if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../rumpun.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
}/*
elseif($module=='users' AND $act=='delete'){
    mysql_query("DELETE FROM fakultas WHERE kd_fakultas = '$_REQUEST[sid]'");
    header('location:../../fakultas.html');
}*/
?>