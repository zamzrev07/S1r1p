<?php session_start();

include "../../config/koneksi.php";
$module=$_GET['venus'];
$act=$_GET['act'];

$sid_lama = session_id();
	
session_regenerate_id();

$sid_baru = session_id();

if($module=='skat' AND $act=='input'){
  $kdprogdi  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdlog'],ENT_QUOTES))); 
  $nmprogdi  = stripslashes(strip_tags(htmlspecialchars($_POST['txtusername'],ENT_QUOTES))); 
  $kdfak    = $_POST['fak']; 
  $aktiprogdi = $_POST['aktifprogdi']; 

  $sql =("INSERT INTO m_subkat
  (KD_KAT, KD_SUBKAT,NM_SUBKAT,AKTIF_SUBKAT) 
  VALUES  ('$kdfak','$kdprogdi','$nmprogdi','$aktiprogdi')");

 if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../skat.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
  
 
}
elseif($module=='skat' AND $act=='edit'){

  $kdprogdi  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdlog'],ENT_QUOTES))); 
  $nmprogdi  = stripslashes(strip_tags(htmlspecialchars($_POST['txtusername'],ENT_QUOTES))); 
  $kdfak    = $_POST['fak']; 
  $aktiprogdi = $_POST['aktifprogdi']; 

   $sql=("UPDATE m_subkat SET KD_KAT='$kdfak' , NM_SUBKAT    = '$nmprogdi',
								 AKTIF_SUBKAT = '$aktiprogdi',KD_KAT='$kdfak' WHERE KD_SUBKAT   = '$kdprogdi'");
if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../skat.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
}/*
elseif($module=='users' AND $act=='delete'){
    mysql_query("DELETE FROM fakultas WHERE KD_KATultas = '$_REQUEST[sid]'");
    header('location:../../fakultas.html');
}*/
?>