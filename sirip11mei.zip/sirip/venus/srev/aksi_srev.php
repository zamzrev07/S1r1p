<?php session_start();

include "../../config/koneksi.php";
$module=$_GET['venus'];
$act=$_GET['act'];

$sid_lama = session_id();
	
session_regenerate_id();

$sid_baru = session_id();

if($module=='srev' AND $act=='input'){
$newID  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdlog'],ENT_QUOTES)));
$npt  = stripslashes(strip_tags(htmlspecialchars($_POST['txtnpt1'],ENT_QUOTES))); 
  $kdthn    = $_POST['thn'];
  $aktif = $_POST['aktif'];
  $skim = $_POST['skim'];

$sql = "INSERT INTO set_reviewer (KD_SETR,NPT,KD_SUBKAT,KD_THN,AKTIF_REV) 
  VALUES 
 ('$newID','$npt','$skim','$kdthn','$aktif')";
//echo "masuk";
if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../srev.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}

}

elseif($module=='srev' AND $act=='edit'){
$newID  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkd'],ENT_QUOTES)));
$npt  = stripslashes(strip_tags(htmlspecialchars($_POST['npt'],ENT_QUOTES))); 
  $kdthn    = $_POST['thn'];
  $aktif = $_POST['aktif'];
  $skim = $_POST['skim'];

$sql=("UPDATE set_reviewer SET NPT='$npt' , KD_SUBKAT    = '$skim', AKTIF_REV = '$aktif' WHERE KD_SETR   = '$newID'");
if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../srev.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
}/*
elseif($module=='users' AND $act=='delete'){
    mysql_query("DELETE FROM fakultas WHERE kd_fakultas = '$_REQUEST[sid]'");
    header('location:../../dosen.html');
}*/
?>