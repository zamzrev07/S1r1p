 <?php session_start();

include "../../config/koneksi.php";
$module=$_GET['venus'];
$act=$_GET['act'];

$sid_lama = session_id();
	
session_regenerate_id();

$sid_baru = session_id();

if($module=='ta' AND $act=='input'){
  $kdkel  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdlog'],ENT_QUOTES))); 
  $nmkel  = stripslashes(strip_tags(htmlspecialchars($_POST['txtusername'],ENT_QUOTES))); 
  $kethnta = stripslashes(strip_tags(htmlspecialchars($_POST['txthnta'],ENT_QUOTES))); 
  $aktifta = $_POST['aktifta']; 

  $sql =("INSERT INTO m_tahun (KD_THN, NM_THN,KET_THN,AKTIF_TA) 
  VALUES  ('$kdkel','$nmkel','$kethnta','$aktifta')");

 if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../ta.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
  
 
}
elseif($module=='ta' AND $act=='edit'){

  $kdkel  = stripslashes(strip_tags(htmlspecialchars($_POST['txtkdlog'],ENT_QUOTES))); 
  $nmkel  = stripslashes(strip_tags(htmlspecialchars($_POST['txtusername'],ENT_QUOTES))); 
  $kethnta = stripslashes(strip_tags(htmlspecialchars($_POST['txthnta'],ENT_QUOTES))); 
  $aktifta = $_POST['aktifta']; 

   $sql=("UPDATE m_tahun SET KD_THN='$kdkel' , NM_THN    = '$nmkel', KET_THN    = '$kethnta', AKTIF_THN='$aktifta' WHERE KD_THN   = '$kdkel'");
if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../ta.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
}/*
elseif($module=='users' AND $act=='delete'){
    mysql_query("DELETE FROM fakultas WHERE kd_fakultas = '$_REQUEST[sid]'");
    header('location:../../fakultas.html');
}*/
?>