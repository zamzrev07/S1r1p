<script>
function hapusdata(urltujuan){
		el=$(this);
		if(confirm("Do you want to delete the data ?."))
		{
            alert("Data Deleted!");
            
            window.location = (urltujuan);
        }
        else{
            alert("Failure to Delete");
        }
}
</script>
            
<?php
$aksi="venus/ta/aksi_ta.php";

  // Tampil Agenda
  if($_GET[venus] == "ta"){
    $que = "select * from m_tahun ";
	$result=mysqli_query($GLOBALS,$que);
	$jumrows = mysqli_num_rows($result);
?>
 	<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>Data Tahun Ajaran</div>
					<div class="panel-body">
                    <a href="keladd.html" class="btn btn-primary">Tambah Tahun Ajaran</a><br><br>
					<b><i>Pada Tahun Ajaran ini HARUS ADA 1 (SATU) yang Statusnya AKTIF</i></b>
          <table data-toggle="table" data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
        <thead>
            <tr>
                <th data-sortable="true">Kode Thn Ajaran</th>
                <th data-sortable="true">Nama Thn Ajaran</th>
                <th data-sortable="true">Status Aktif</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
		<?php
		$iCnt=0;
		if ($jumrows>0) { 
			while ($row = mysqli_fetch_array($result)) {
        $iCnt++;
		?>
        
		  <tr <?php if ($iCnt%2==0) {?>class="odd gradeX" <?php } else {?>class="even gradeC"<?php }?> >
      <td><?php echo strip_tags(strtoupper($row[KD_THN])); ?></td>
			<td><?php echo strip_tags(strtoupper($row[NM_THN])); echo " / $row[KET_THN]"; ?></td>
            <td><?php echo strip_tags(strtoupper($row[AKTIF_THN])); ?></td>
            <td><a data-toggle="tooltip" data-placement="top" title="edit" href="<?php echo("taedit-$row[KD_THN].html")?>" class="btn btn-sm btn-warning">Edit</a></td>  
		  </tr>
		<?php
			}
		}else{
		?>
		<tr>
			<td colspan="6">Data tidak di temukan</td>
		</tr>
		<?php
		}
		?>
        </tbody>
	</table>
    </div>
    </div>
    </div>
    </div>
	<?php
  }
elseif($_GET[venus]=="taadd"){

 $query = "SELECT max(KD_THN) as maxKode FROM m_tahun";
   $hasil = mysqli_query($GLOBALS,$query); 
  $data = mysqli_fetch_array($hasil); 
  $kodeBarang = $data['maxKode']; 
   $noUrut = (int) substr($kodeBarang, 2, 5); 
   $noUrut++; 
   $char="TA";
    $newID = $char . sprintf("%05s", $noUrut);	
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
             <svg class="glyph stroked plus sign"><use xlink:href="#stroked-plus-sign"/></svg> Tambah Data Master Tahun Ajaran
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=ta&act=input"?>" method="post" enctype="multipart/form-data">
                   <label>Kode Thn Ajaran</label>
                      <input class="form-control" name="txtkdlog" id="txtkdlog" value="<?php echo $newID; ?>" readonly="readonly"/>
                      <label>Nama Thn Ajaran</label>
                      <input class="form-control" name="txtusername" id="txtusername" />
                      <label>Keterangan Thn Ajaran</label>
                      <input class="form-control" type="number" name="txthnta" id="txthnta" />
                      <label>Status Thn Ajaran</label>
                      <select name="aktifta" class="form-control">
                      <option value="YA">YA</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                      
                      <button type="reset" class="btn btn-default">Reset</button>

                  </form>
              </div>
    </div>  
<?php
}
elseif($_GET[venus]=="taedit"){
  	$que = "select * from m_tahun where KD_THN='$_GET[id]'";
    $result=mysqli_query($GLOBALS,$que);  
    $row = mysqli_fetch_array($result);
?>
	
  <div class="panel panel-default">
          <div class="panel-heading">
               <svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"/></svg>Ubah Data Master Tahun Ajaran
          </div>
              <div class="panel-body">
                  <form name="mainform" id="mainform" action="<?php echo"$aksi?venus=ta&act=edit"?>" method="post" enctype="multipart/form-data">
                      <label>Kode Thn Ajaran</label>
                      <input class="form-control" name="txtkdlog" id="txtkdlog" value="<?php echo($_GET[id]); ?>" readonly="readonly"/>
                      <label>Nama Thn Ajaran</label>
                      <input class="form-control" name="txtusername" id="txtusername" value="<?php echo($row[NM_THN]);?>" />
                      <label>Keterangan Thn Ajaran</label>
                      <input class="form-control" type="text" name="txthnta" id="txthnta" value="<?php echo($row[KET_THN]);?>" />
                       <label>Status Thn Ajaran</label>
                      <select name="aktifta" class="form-control">
                      <option value="<?php if($_GET[venus]=="taedit"){ echo($row[AKTIF_THN]); }else{echo '--'; }?>">
                      <?php if($_GET[venus]=="taedit"){ echo($row[AKTIF_THN]); }else{echo 'Silahkan Pilih'; }?></option>
                      <option value="YA">YA</option>
                      <option value="TIDAK">TIDAK</option>
                      </select>
                      <p>&nbsp;</p>
                      <button type="submit" class="btn btn-default">Ubah</button>
                    
                      <button type="reset" class="btn btn-primary">Reset</button>
                      </form>
              </div>
  </div>    
<?php
}
?>