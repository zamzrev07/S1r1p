<?php
session_start();
include "../../config/koneksi.php";
$module=$_GET['venus'];
$act=$_GET['act'];

$sid_lama = session_id();
	
session_regenerate_id();

$sid_baru = session_id();

if($module=='users' AND $act=='input'){
  $ps         = md5($_POST['txtpassword']);
  $aktifuser  = $_POST['aktifuser']; 
  $hak        = $_POST['hakakses']; 

  $sql =("INSERT INTO m_login
  (KD_LOG,USER_LOG,PASS_LOG,ID_SESSION,STA_LOG,AKTIF_LOG) 
  VALUES 
 ('$_POST[txtkdlog]','$_POST[txtusername]','$ps','$sid_baru','$hak','$aktifuser')");
 if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../users.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
  
 
}
elseif($module=='users' AND $act=='edit'){
     $passdefault=md5($_POST['txtpass']);
  $aktifuser  = $_POST['aktifuser']; 
  $hak        = $_POST['hakakses']; 
   $sql=("UPDATE m_login SET KD_LOG     = '$_POST[txtkdlog2]',STA_LOG='$hak', AKTIF_LOG='$aktifuser', USER_LOG    = '$_POST[txtuname]',
								 PASS_LOG = '$passdefault', ID_SESSION   = '$sid'
                           WHERE ID_SESSION   = '$_POST[sid]'");
if (mysqli_query($GLOBALS, $sql)) {
    header('location:../../users.html');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($GLOBALS);
}
}
elseif($module=='users' AND $act=='delete'){
    mysql_query("DELETE FROM user WHERE ID_SESSION = '$_REQUEST[sid]'");
    header('location:../../users.html');
}
?>