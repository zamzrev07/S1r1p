<footer>
				<div class="wrapper">
					<div class="pad1">
						<div class="pad_left1">
							<div class="wrapper">
								<article class="col_1">
									<h3>Address:</h3>
									<p class="col_address"><strong>Country:<br>
											City:<br>
											Address:<br>
											</strong></p>
											<p>INDONESIA<br>
											SURABAYA<br>
											Jln. Raya Rungkut Madya, Gunung Anyar (Gedung Techno Park - Kampus UPN V Jatim)<br>
											<strong>Email : </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="mailto:">lppm@upnjatim.ac.id</a></p>
								</article>
								<article class="col_2 pad_left2">
									<h3>Join In:</h3>
									<ul class="list2">
										<li><a href="#">Sign Up</a></li>
										<li><a href="#">Forums</a></li>
										<li><a href="#">Promotions</a></li>
										<li><a href="#">Lorem</a></li>
									</ul>
								</article>
								<article class="col_3 pad_left2">
									<h3></h3>
									<ul class="list2">
										<li><a href="#"> </a></li>
										
									</ul>
								</article>
								<article class="col_4 pad_left2">
									<h3>Newsletter:</h3>
									<form id="newsletter" method="post">
										<div class="wrapper">
											<div class="bg"><input type="text"></div>
										</div>
										<a href="#" class="button" onclick="document.getElementById('newsletter').submit()"><span><span><strong>Subscribe</strong></span></span></a>
									</form>
								</article>
							</div><div class="wrapper">
								<article class="call">
									<span class="call1">Call Us Now: </span><span class="call2">+62 (031) 878 1400</span>
								</article>
								<article class="col_4 pad_left2">
									Website Template by <a href="http://www.templatemonster.com/" target="_blank" rel="nofollow">www.templatemonster.com</a><br>
									3D Models provided by <a href="http://www.templates.com/product/3d-models/" target="_blank" rel="nofollow">www.templates.com</a><br>
									Modified by <a href="http://www.soegie.xyz" target="_blank" rel="nofollow">soegi</a> </article>
							</div>
							</div>
					</div>
				</div>