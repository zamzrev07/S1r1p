<ul class="banners">
					<li><a href="#"><img src="images/banner1.jpg" alt=""></a></li>
					<li><a href="#"><img src="images/banner2.jpg" alt=""></a></li>
					<li><a href="#"><img src="images/banner3.jpg" alt=""></a></li>
				</ul>