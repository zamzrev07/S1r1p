<?php 
include "../config/koneksi.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Home :: SIRIP UPN "Veteran" Jatim </title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.5.2.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Molengo_400.font.js"></script>
<script type="text/javascript" src="js/Expletus_Sans_400.font.js"></script>
<!--[if lt IE 9]>
<script type="text/javascript" src="js/html5.js"></script>
<style type="text/css">
	.bg, .box2 {behavior:url(js/PIE.htc)}
</style>
<![endif]-->
<!--[if lt IE 7]>
	<div style=' clear: both; text-align:center; position: relative;'>
		<a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode">
		<img src="http://www.theie6countdown.com/images/upgrade.jpg" border="0"  alt="" /></a>
	</div>
<![endif]-->
</head>

<body id="page1">
	<div class="body1">
		<div class="main">
<!-- header -->
			<header>
				<?php 
include "menu.php";
include "head1.php";
				?>
				
			</header>
<!-- / header -->
		</div>
	</div>
	<div class="body2">
		<div class="main">
<!-- content -->
			<section id="content">
				<div class="wrapper">
					<div class="pad1 pad_top1">
						<article class="cols marg_right1">
							<figure><a href="#"><img src="images/page1_img1.jpg" alt=""></a></figure>
							<span class="font1">Our Mission Statement</span>
						</article>
						<article class="cols marg_right1">
							<figure><a href="#"><img src="images/page1_img2.jpg" alt=""></a></figure>
							<span class="font1">Performance Report</span>
						</article>
						<article class="cols">
							<figure><a href="#"><img src="images/page1_img3.jpg" alt=""></a></figure>
							<span class="font1">Prospective Parents</span>
						</article>
					</div>
				</div>
				<div class="box1">
					<div class="wrapper">
						<article class="col1">
							<div class="pad_left1">
								<h2>Selamat Datang</h2>
								<p><strong>Download Panduan LITABMAS Terbaru >> <a href="https://drive.google.com</open?id=0B6t2cGd7rc9yaDNKamlqUGlkalk" target="_blank">Unduh</a><br>
								Download Panduan SIMLITABMAS (DRPM) Terbaru >> <a href="https://drive.google.com/open?id=0B6t2cGd7rc9yTTRCNHZxal9tYjg" target="_blank">Unduh</a><br><br>Peneltian Mandiri yang diselenggarakan LPPM UPN Veteran Jawa Timur saat ini akan membuka beberapa SKIM Mandiri</strong> diantaranya :
								<ul><li>
<?php  $no = 0;
	$que = "select distinct (NM_SKIM) from m_subkat a, m_kategori b where a.KD_KAT=b.KD_KAT";
	$result=mysqli_query($GLOBALS,$que); 
	while ($row = mysqli_fetch_array($result)) { $no++; ?>
	<li>
<?php echo "$no. &nbsp"; echo $row['NM_SKIM'];?>
<?php } ?><br>
								</p>
							</div>
							<a href="#" class="button"><span><span>Read More</span></span></a>
							<!--<div class="pad_left1">
								<h2>Individual Approach to Education!</h2>
							</div>
							<div class="wrapper">
								<figure class="left marg_right1"><img src="images/page1_img4.jpg" alt=""></figure>
								<p class="pad_bot1 pad_top2"><strong>Lorem ipsum dolor sit amet, consectetur adipisicing eiusmod tempor incididunt ut labore.</strong></p>
								<p>
										Learn Center Template goes with two packages – with PSD source files and without them. PSD source files are available for free for the registered members of Templates.com. The basic package (without PSD source is available for anyone without registration).</p>
							</div>
							<div class="pad_top2">
								<a href="#" class="button"><span><span>Read More</span></span></a>
							</div>-->
						</article>
						<article class="col2 pad_left2">
							<div class="pad_left1">
								<h2>Login</h2>
							</div>
							<ul class="list1">
								<li><a href="../dosen/" target="_blank">Pengusul Dosen</a></li>
							</ul>
							<ul class="list1">
								<li><a href="#" target="_blank">Pengusul Mahasiswa</a></li>
							</ul>
							
							<ul class="list1">
								<li><a href="../reviewer/" target="_blank">Reviewer</a></li>
							</ul>
							
							<div class="pad_left1">
								<h2>Link</h2>
							</div>
							<ul class="list1">
								<li><a href="http://lppm.upnjatim.ac.id/" target="_blank">LPPM UPN V Jatim</a></li>
							</ul>
							<ul class="list1">
								<li><a href="http://www.upnjatim.ac.id" target="_blank">UPN V Jawa Timur</a></li>
							</ul>
							<ul class="list1">
								<li><a href="http://simlitabmas.dikti.go.id/" target="_blank">Simlitabmas Dikti</a></li>
							</ul>
							<ul class="list1">
								<li><a href="http://www.kemenegpdt.go.id/" target="_blank">KPDT</a></li>
							</ul>
							<ul class="list1">
								<li><a href="http://www.dikti.go.id/" target="_blank">DIKTI</a></li>
							</ul>
							
							<div class="pad_left1">
								<h2>Latest News</h2>
							</div>
							<div class="wrapper">
								<span class="date">27</span>
								<p class="pad_top2"><a href="#">April, 2011</a><br>
										Sed utirspiciatis unde omnis iste natus error sit...</p>
							</div>
							<div class="wrapper">
								<span class="date">25</span>
								<p class="pad_top2"><a href="#">April, 2011</a><br>
										Voluptatem accusan dolore mque laudantium...</p>
							</div>
							<div class="pad_top2">
								<a href="#" class="button"><span><span>Read More</span></span></a>
							</div>
						</article>
					</div>
				</div>
			</section>
<!-- content -->
<!-- footer -->
			
							<?php include "foot.php"; ?>
						
			</footer>
<!-- / footer -->
		</div>
	</div>
<script type="text/javascript"> Cufon.now(); </script>
</body>
</html>