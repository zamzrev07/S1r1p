<div class="wrapper">
					<nav>
						<ul id="menu">
							<li><a href=".">Home</a></li>
							<li><a href="#">Penelitian</a></li>
							<li><a href="#">Abmas</a></li>
							<li><a href="#">Panduan</a></li>
							<li class="end"><a href="Contacts.php">Contacts</a></li>
						</ul>
					</nav>
					<ul id="icon">
						<li><a href="#"><img src="images/icon1.jpg" alt=""></a></li>
						<li><a href="#"><img src="images/icon2.jpg" alt=""></a></li>
						<li><a href="#"><img src="images/icon3.jpg" alt=""></a></li>
					</ul>
				</div>
				<div class="wrapper">
					<h1><a href="index.html" id="logo"></a></h1>
				</div>
				<div id="slogan">
					We Will Open The World<span>of knowledge for you!</span>
				</div>
				